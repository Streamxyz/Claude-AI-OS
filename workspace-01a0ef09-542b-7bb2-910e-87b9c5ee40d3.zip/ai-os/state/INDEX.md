# state/ — the OS disk

| Path | What | Load policy |
|---|---|---|
| `primer.md` | re-entry context after compaction (≤60 lines) | PostCompact |
| `ledger.jsonl` | append-only: events, tokens, cost, verdicts | query only |
| `tasks/<id>.json` | task record: spec, tier, slices, gates, attempts | on demand |
| `notes/<topic>.md` | structured notes: Status/Decisions/Open/Evidence | JIT |
| `index/{repo,skills,tools}.md` | compact maps — read these, not the tree | on demand |
| `traces/<task>/<gate>.log` | gate evidence (the chat gets the verdict) | on failure |
| `approvals/pending.json` | the human queue | on escalation |
| `digest/<date>.md` | daily human digest | daily |
| `bus/<agent>.jsonl` | inter-agent mailbox (≤200 tokens/msg) | on demand |

**Nothing here is hand-written except notes.** Indexes are generated; the ledger is append-only;
task records are written by `bin/aios` and agents through `scripts/ledger.py`.
