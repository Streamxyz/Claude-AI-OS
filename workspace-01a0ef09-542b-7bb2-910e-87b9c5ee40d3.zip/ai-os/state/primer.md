# AI OS primer (generated)

You are operating AI OS. State on disk beats state in chat. Evidence beats assertion.
generated: 2026-09-29T20:53:58Z

## Open tasks
- T-000: Add per-IP rate limiting to the public API [tier M, status GATE_PASS] gates: typecheck,lint,unit,build

## Pointers (read on demand, never preload)
- repo map: state/index/repo.md
- skills:   state/index/skills.md
- tools:    state/index/tools.md
- history:  state/ledger.jsonl
- notes:    state/notes/<topic>.md
- gates:    bin/aios verify <task-id>

## Non-negotiables
- no raw output > 200 lines · agent returns are JSON ≤ 2000 tokens
- no protected-path edits without approval · no force push · no destructive SQL
- ledger before recompute: scripts/ledger.py query --similar "<task>"

