# Skill index (generated)

Metadata only. Run `Read .claude/skills/<name>/SKILL.md` to load the body.

- `aios-audit` — Repo-wide multi-agent audit via dynamic workflow — security, dead code, dependencies, docs drift, each cross-checked by independent verifier agents. U
- `aios-boot` — Validate and initialize the AI OS installation — layout, toolchain, hooks, permissions, budgets, indexes. Use when a repo was just cloned, after editi
- `aios-context` — Reclaim context — checkpoint state to disk, compact, and re-inject the primer. Use when PostToolBatch reports >60% context, when output quality drops,
- `aios-cost` — Report token and dollar spend by task, agent, model, and tier, plus the top three concrete optimizations. Use nightly, after large runs, or when spend
- `aios-implement` — Implement one approved slice inside a worktree, running gates after every meaningful change. Use when a plan slice exists and ownership is assigned.
- `aios-incident` — Triage an alert or incident — correlate the stack trace with recent commits, draft a fix in a worktree, and open a PR with a root-cause note. Use from
- `aios-learn` — Harvest corrections, gate failures, and recurring patterns into rule and skill improvement proposals. Use at SessionEnd and nightly; never left in cha
- `aios-orchestrate` — Run the full AI OS pipeline on an intent — spec, plan, dispatch, implement, verify, learn. Use when the user gives a feature, bug, or refactor to deli
- `aios-plan` — Produce an implementation plan with slices, file-ownership map, and per-slice gates. Use for tier M and above, and whenever more than one agent will t
- `aios-release` — Cut a release — version bump, changelog from merged task records, tag, migration dry-run, and rollback note. Use when merging to main or shipping an e
- `aios-review` — Adversarial multi-agent review — correctness, security, and test-quality angles run in parallel and merged into one ranked finding list. Use before me
- `aios-spec` — Turn a vague intent into a testable spec with acceptance criteria and non-goals. Use when a request is ambiguous, when the user says "you decide", or 
- `aios-verify` — Run the Definition-of-Done gate set and report a machine verdict with evidence paths. Use at the end of every task, and whenever a Stop hook blocks th
- `api-endpoint` — Use when adding or changing an HTTP endpoint, route handler, RPC method, or webhook receiver. Do not use for client-side data fetching or internal fun
- `ci-pipeline` — Use when creating or editing CI configuration, build stages, caching, or release automation. Do not use for changing what tests assert.
- `db-migration` — Use when changing a database schema, adding or editing a migration, backfilling data, or editing an ORM schema file. Do not use for query optimisation
- `debug` — Use when a test, build, or runtime failure needs a root cause. Do not use for speculative cleanups or when a gate failure is already understood.
- `deploy` — Use when deploying an environment, promoting a build, or changing deployment configuration. Never for local dev servers.
- `deps-upgrade` — Use when bumping dependencies, resolving vulnerabilities, or reviewing a lockfile change. Do not use for adding a new dependency (that needs an archit
- `docs-sync` — Use when a public API, CLI flag, config key, or schema changed and documentation may now be wrong. Also for the nightly docs-drift routine.
- `e2e-test` — Use when writing or fixing browser-level tests, or when a change must be proven against the running application rather than mocks.
- `observability` — Use when adding metrics, logs, traces, or alerts, or when a change cannot be verified in production without telemetry.
- `perf-profile` — Use when something is slow, a latency or bundle-size budget is at risk, or before optimising. Measure first; never optimise on intuition.
- `security-review` — Use when a change touches authentication, authorization, payments, PII, untrusted input, secrets, or a new dependency. Also use for release-time audit
- `ui-component` — Use when building or changing a UI component, page, or design-system primitive. Do not use for styling-only tweaks that a formatter or token change co
