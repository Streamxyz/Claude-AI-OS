# Repo index (generated)

Format: `path [size] purpose`. Read this before exploring.

ARCHITECTURE.md  [27989B]  AI OS — Architecture **A Claude Code–based operating system for autonomous full-stack engi
README.md  [4936B]  AI OS **A Claude Code–based operating system for autonomous full-stack engineering.** Huma
TOKEN-ECONOMY.md  [8626B]  Token Economy **Every token in context is a decision the model can no longer make freely.*
OPERATIONS.md  [7238B]  Operations Manual How AI OS runs unattended, when it stops to ask, and what you do at 9am.
ROADMAP.md  [3925B]  Roadmap — maturity ladder Ship levels in order. Each level is independently useful and pay
CLAUDE.md  [4174B]  CLAUDE.md — AI OS constitution You are operating **AI OS**: a repository-shaped control pl
bin/aios  [18054B]  
scripts/gate.py  [3754B]  The gate runner — one command, one verdict, evidence on disk. gate.py list gate.py run uni
scripts/router.py  [4550B]  Intent router: classify a task into a tier and emit the execution profile. router.py "add 
scripts/index.py  [6000B]  Build compact indexes so the model reads a map, never the territory. index.py --all # repo
scripts/primer.py  [2960B]  Assemble the minimal re-entry context after compaction or a cold start. primer.py --build 
scripts/cost_report.py  [3151B]  Cost and token telemetry with the Pareto question: what is the cheapest configuration that
scripts/worktree.py  [2340B]  Task worktrees — one isolated checkout per worker so parallel agents never collide. worktr
scripts/promote.py  [3010B]  Turn repeated evidence into rules, skills, or scripts. promote.py --scan # candidates with
scripts/digest.py  [1600B]  Daily human digest: shipped, blocked, spend, proposals. Two minutes to read.
scripts/contract.py  [361B]  Thin entry point — delegates to scripts/lib/contract.py. Kept at scripts/ so skills, agent
scripts/gates/typecheck.sh  [615B]  !/usr/bin/env bash # Type gate. Exits 0 when no project is detected yet (bootstrap-friendl
scripts/gates/lint.sh  [438B]  !/usr/bin/env bash set -uo pipefail cd "${CLAUDE_PROJECT_DIR:-$(pwd)}" ran=0; rc=0 [ -f pa
scripts/gates/unit.sh  [520B]  !/usr/bin/env bash set -uo pipefail cd "${CLAUDE_PROJECT_DIR:-$(pwd)}" ran=0; rc=0 [ -f pa
scripts/gates/build.sh  [399B]  !/usr/bin/env bash set -uo pipefail cd "${CLAUDE_PROJECT_DIR:-$(pwd)}" ran=0; rc=0 [ -f pa
scripts/gates/e2e.sh  [482B]  !/usr/bin/env bash # Browser-level proof. Requires a running app: bin/aios run --serve fir
scripts/gates/sec.sh  [1285B]  !/usr/bin/env bash # Security gate: secret scan + dependency audit. Advisory tools are bes
scripts/gates/migrate.sh  [713B]  !/usr/bin/env bash # Migration gate. --dry-run is the default; --up/--down require an appr
scripts/lib/common.py  [2951B]  Shared helpers for AI OS syscalls. Every syscall follows the same contract: * deterministi
scripts/lib/ledger.py  [4519B]  state/ledger.jsonl — append-only ground truth for events, tokens, and cost. Usage: ledger.
scripts/lib/budget.py  [1615B]  Context budget estimator and compaction trigger. Returns a JSON verdict usable by hooks: {
scripts/lib/contract.py  [3047B]  Validate agent output contracts and task plans. contract.py --agent implementer --file res
scripts/mcp_exec/tools.py  [3811B]  Tool search over the MCP registry — find a tool WITHOUT loading its schema. Implements the
scripts/mcp_exec/exec.py  [3432B]  Execute code against MCP servers so intermediate results never enter context. This is the 
scripts/mcp_exec/bridge.py  [2071B]  Expose configured MCP servers to sandbox code as importable modules. Sandbox programs do: 
os/kernel/README.md  [1039B]  Kernel The kernel is the smallest set of things that must be true for the OS to be safe an
os/kernel/invariants.md  [1171B]  Invariants Break one of these and the OS degrades into an expensive chatbot with write acc
os/kernel/routing.md  [980B]  Routing `scripts/router.py` classifies every intent into a tier; the tier decides model, e
os/memory/README.md  [1012B]  Memory tiers Four tiers, cheapest first. Read up the ladder, never down. | Tier | Location
os/bus/README.md  [895B]  Bus Inter-process communication for agents that must not share a context window. | Channel
os/registry/README.md  [502B]  Registry Machine-readable contracts that make agent collaboration deterministic. | File | 
os/registry/routing.json  [1389B]  
os/registry/contracts/classifier.json  [712B]  
os/registry/contracts/explorer.json  [513B]  
os/registry/contracts/planner.json  [585B]  
os/registry/contracts/implementer.json  [610B]  
os/registry/contracts/testsmith.json  [500B]  
os/registry/contracts/reviewer.json  [387B]  
os/registry/contracts/security-auditor.json  [405B]  
os/registry/contracts/verifier.json  [532B]  
os/registry/contracts/scribe.json  [343B]  
os/registry/contracts/resolver.json  [629B]  
os/registry/contracts/migrator.json  [441B]  
os/registry/contracts/cost-optimizer.json  [486B]  
os/sandbox/README.md  [907B]  Sandbox Two sandboxes, one goal: nothing dangerous and nothing bulky reaches the model. ##
os/observability/README.md  [732B]  Observability What you cannot measure you cannot make cheaper, safer, or faster. | Signal 
specs/intent/README.md  [693B]  Intent specs — the only thing a human writes Write **intent**, not instructions. The OS fi
products/README.md  [1064B]  products/ One directory per delivered application. Generated, owned, and verified by the O
evals/README.md  [1023B]  Evals Regression tests for **agent behaviour**, not just product code. If a prompt, skill,
evals/routing.jsonl  [581B]  
evals/hooks-destructive.jsonl  [719B]  
evals/run.py  [2444B]  Eval harness — regression tests for agent behaviour, not just product code. evals/run.py #
docs/README.md  [582B]  docs/ Long-form references. **This directory is never auto-loaded.** Anything here is reac
docs/onboarding.md  [1375B]  Onboarding — 30 minutes to a running AI OS ## 1. Install (5 min) ```bash cd your-repo cp -
docs/mcp-exec.md  [1549B]  Code execution with MCP ## Why Presenting N MCP tools as N context entries can consume 15k
docs/hooks-reference.md  [1520B]  Hooks reference (AI OS subset) Full event list: https://code.claude.com/docs/en/hooks ## E
docs/agent-contracts.md  [1360B]  Agent output contracts Every agent returns **one JSON object**, ≤ 2000 tokens, validated o
docs/adding-a-skill.md  [1236B]  Adding a skill ``` .claude/skills/<name>/ ├── SKILL.md # ≤120 lines: trigger, steps, bound
docs/token-playbook.md  [1491B]  Token playbook — concrete moves | Move | How | Typical saving | |---|---|---| | Read the i
diagrams/architecture.svg  [14224B]  
