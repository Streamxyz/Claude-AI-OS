# Tool index (generated)

## Syscalls (scripts/ and bin/)
- `bin/aios` — 
- `scripts/gate.py` — The gate runner — one command, one verdict, evidence on disk. gate.py list gate.py run uni
- `scripts/router.py` — Intent router: classify a task into a tier and emit the execution profile. router.py "add 
- `scripts/index.py` — Build compact indexes so the model reads a map, never the territory. index.py --all # repo
- `scripts/cost_report.py` — Cost and token telemetry with the Pareto question: what is the cheapest configuration that
- `scripts/primer.py` — Assemble the minimal re-entry context after compaction or a cold start. primer.py --build 
- `scripts/worktree.py` — Task worktrees — one isolated checkout per worker so parallel agents never collide. worktr
- `scripts/promote.py` — Turn repeated evidence into rules, skills, or scripts. promote.py --scan # candidates with
- `scripts/digest.py` — Daily human digest: shipped, blocked, spend, proposals. Two minutes to read.

## MCP drivers (.mcp.json)
- `filesystem` — schemas deferred (tool search)
- `github` — schemas deferred (tool search)
- `postgres` — schemas deferred (tool search)
- `sentry` — schemas deferred (tool search)
- `playwright` — schemas deferred (tool search)
- `context7` — schemas deferred (tool search)

## mcp_exec shim
- `aios-mcp-tools search <query>` — find a tool without loading schemas
- `aios-mcp-exec <file.py>` — run code against MCP; only the return enters context
