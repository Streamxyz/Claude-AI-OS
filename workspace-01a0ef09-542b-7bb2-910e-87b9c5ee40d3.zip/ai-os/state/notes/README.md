# Notes — structured memory, JIT-loaded

Shape:
```markdown
# <topic>
## Status
## Decisions
## Open
## Evidence paths
```

Rules: facts and pointers only · split at 120 lines · never a transcript ·
never delete evidence · every claim names a file, log, or PR.
