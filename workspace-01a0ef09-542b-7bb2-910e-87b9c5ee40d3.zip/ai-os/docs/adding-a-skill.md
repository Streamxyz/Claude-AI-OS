# Adding a skill

```
.claude/skills/<name>/
├── SKILL.md            # ≤120 lines: trigger, steps, boundaries, Verify
├── references/         # long material, read by path only
├── scripts/            # deterministic steps the model *executes*, not re-derives
└── templates/          # scaffolds
```

## Frontmatter
```yaml
---
name: my-skill
description: Use when <trigger>. Do not use for <near-miss>.
argument-hint: "<arg>"
allowed-tools: Read, Write, Edit, Bash
---
```
The description is the routing layer — it is in context every turn, so make it a **trigger
condition**, not a summary. Negative cases matter as much as positive ones.

## Checklist
- [ ] `SKILL.md` fits on one screen; anything longer moves to `references/`
- [ ] every deterministic step is a script in `scripts/`
- [ ] ends with `## Verify` naming a command that exits 0/1
- [ ] references bundled files by path (use `${CLAUDE_SKILL_DIR}`)
- [ ] no trigger overlap with an existing skill
- [ ] `bin/aios doctor` passes, and `bin/aios index --skills` refreshed

## Then measure
`bin/aios cost --since 7d` — if the skill does not move cost, pass rate, or interventions, it is
documentation, not a capability. Rewrite or delete it.
