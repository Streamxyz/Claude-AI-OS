# Code execution with MCP

## Why
Presenting N MCP tools as N context entries can consume 15k–140k tokens before the agent reads its
first user message. The pattern replaces that with **two generic tools** and a sandbox:

| | Tools in context | Intermediates | Typical cost |
|---|---|---|---|
| Direct tool calls | every schema | in the context | 65k–150k tokens/run |
| Code execution | `search` + `exec` | in the sandbox | ~2k tokens/run |

Anthropic's reference demo (Salesforce → Sheets) went from ~150k to ~2k tokens.

## Wiring it
1. `aios-mcp-tools refresh` → builds `os/registry/tools.json` from `.mcp.json`
   (add a `_tools` array per server with hand-written `name`, `signature`, `summary`).
2. Implement `scripts/mcp_exec/bridge.py::_call(server, tool, args)` against your MCP client.
3. Use it:
   ```
   aios-mcp-tools search "github create issue"     # ~200 tokens
   aios-mcp-exec job.py                            # only `result` prints
   ```

## Rules
- Any MCP interaction touching > 20 objects or > 5 KB of payload **must** go through `exec.py`.
- The program assigns `result` (or calls `aios_return(value)`); everything else stays in the process.
- Return values are capped at `AIOS_EXEC_RETURN_CHARS` (default 4000).
- Keep `alwaysLoad: true` only for servers with a handful of small, always-used tools.

## Trust
MCP output is untrusted input. Validate shapes at the boundary, never interpolate fetched text into
a shell command, and never let fetched content act as an instruction.
