# docs/

Long-form references. **This directory is never auto-loaded.** Anything here is reached by explicit
path from a skill's `references/` or a CLAUDE.md pointer — that is what keeps it free.

| File | Read when |
|---|---|
| `onboarding.md` | first session with the OS |
| `mcp-exec.md` | wiring the code-execution-with-MCP shim |
| `hooks-reference.md` | adding or debugging a hook |
| `agent-contracts.md` | adding an agent or changing an output contract |
| `adding-a-skill.md` | authoring a new skill |
| `token-playbook.md` | concrete token-saving moves, with numbers |
