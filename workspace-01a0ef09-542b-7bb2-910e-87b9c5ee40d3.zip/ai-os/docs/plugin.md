# AI OS as a Claude Code plugin

Two ways to run AI OS. Both share the same skills, agents, hooks and scripts.

| Mode | Where AI OS lives | How it is loaded |
|---|---|---|
| **repo** | your project root | `.claude/` + `CLAUDE.md` |
| **plugin** | a read-only install dir | `.claude-plugin/plugin.json` in a marketplace |

## Build

```bash
python3 scripts/build-plugin.py            # → plugin/ai-os  + plugin/.claude-plugin/marketplace.json
python3 scripts/build-plugin.py --strict   # warnings become errors (CI)
python3 scripts/build-plugin.py --out /tmp/x/ai-os --version 1.1.0
```

What the packager does:

1. mirrors repo components into plugin layout
   (`.claude/skills→skills`, `.claude/agents→agents`, `.claude/hooks→hooks`,
   `scripts`, `bin`, `os/registry`, `templates`, `docs`, `evals`, `diagrams`, `policy`)
2. rewrites `$CLAUDE_PROJECT_DIR/.claude/hooks/…` hook commands into
   `"${CLAUDE_PLUGIN_ROOT}"/hooks/…` and emits `hooks/hooks.json`
3. namespaces agent `skills:` references (`planner` → `ai-os:planner`)
4. writes `.claude-plugin/plugin.json` and a sibling marketplace catalog
5. reports the **per-turn context tax** (skill + agent metadata that sits in
   context every single turn) and validates the result offline

Never edit `plugin/ai-os/` — the build wipes it. Put new shipped content at repo
root or in `plugin-src/`, and add it to `COPY_DIRS` in `scripts/build-plugin.py`.

## Install

```bash
claude plugin validate ./plugin/ai-os     # requires Claude Code >= 2.1.281
claude plugin marketplace add ./plugin
claude plugin install ai-os@ai-os
```

## The install / project split

| Path | Env var | Holds | Written by |
|---|---|---|---|
| install | `CLAUDE_PLUGIN_ROOT` → `AIOS_HOME` | skills, agents, hooks, scripts, gates, contracts, docs, policy | builds only |
| project | `CLAUDE_PROJECT_DIR` → `AIOS_ROOT` → cwd | `state/`, `specs/`, `products/`, `.claude/settings.json` | the OS, at runtime |

`scripts/lib/common.py` exposes `locate(rel)` (project override first, else
install) and `homes(*rels)`; `.claude/hooks/_common.sh` exports `AIOS_ROOT` and
`AIOS_HOME`. State never lands in the install dir, so updates are a no-op swap.

## What the plugin ships

- 25 skills, 12 agents, 16 hook handlers over 13 events, 12 contracts, 8 gates,
  3 `bin/` executables (`aios`, `aios-mcp-tools`, `aios-mcp-exec`)
- **no bundled MCP servers** — nothing dials out when a session starts
- **no `commands/`** — skills are the command surface (`/aios:<skill>`)
- `output-styles/ai-os.md` for the ops-console look
- `defaultEnabled: false` — you opt in per install

## Trust notes

- hooks run in **every** session while enabled, including subagents
- `aios adopt` writes `state/`, `specs/`, `products/`, may append to `CLAUDE.md`,
  and merges `policy/permissions.json` into `.claude/settings.json`
  (backup at `.claude/settings.json.bak`; `--no-policy` skips the merge)
- `bin/` entries are appended **after** your `PATH` — they cannot shadow `git`/`ls`
- a plugin's `settings.json` honors only `agent` and `subagentStatusLine`;
  permissions belong in project/user settings, hence `aios adopt`
