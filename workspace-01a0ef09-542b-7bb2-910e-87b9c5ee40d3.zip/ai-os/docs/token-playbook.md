# Token playbook — concrete moves

| Move | How | Typical saving |
|---|---|---|
| Read the index | `state/index/repo.md` before any exploration | ~95% vs walking the tree |
| Defer MCP schemas | tool search + `alwaysLoad: false` | 90–99% |
| Bulk through exec | `aios-mcp-exec` for > 20 objects | 95%+ |
| Cap command output | `bashOutputMaxChars: 8000` + truncate hook | 80–95% |
| JSON contracts | `hooks/contract.py`, ≤2000 tokens | 70–90% per delegation |
| Path-scoped rules | `.claude/rules/*.md` with `paths:` | 60–80% of rule tokens |
| Gates, not conversations | `bin/aios verify` returns a verdict | 80–95% |
| Subagent isolation | heavy work in a worker's window | keeps the main window clean |
| Cheap model, low effort | haiku/low for classify & extract | 5–20× on those calls |
| Parallel batches | parallel tool calls + workflows | wall-clock, not tokens |
| Stable prefix | freeze `CLAUDE.md`/tools mid-run | ~90% on the cached prefix |
| Ledger before recompute | `bin/aios ledger query --similar` | up to 100% on repeats |

## Budget guardrails in `settings.json`
`autoCompactWindow: 400000` · `bashOutputMaxChars: 8000` · `subagentPromptCacheTtl: 1h`
and `AIOS_BUDGET_WARN_PCT=60` / `AIOS_BUDGET_FORCE_PCT=80` in `env`.

## Weekly ritual
`bin/aios cost --since 7d --by model,agent,tier` → pick the top line → fix the routing table or add
a script. Do not tune prompts before you have tuned routing; routing is where the multiples are.
