# Hooks reference (AI OS subset)

Full event list: https://code.claude.com/docs/en/hooks

## Events and semantics
| Event | Can block | AI OS use |
|---|---|---|
| `SessionStart` | no | boot, dirs, ≤25-line digest |
| `UserPromptSubmit` | yes | classify tier, inject primer + index lines |
| `PreToolUse` | **yes (exit 2)** | guard Bash, guard paths, guard MCP |
| `PermissionRequest` | yes | (reserved) |
| `PostToolUse` | no | truncate output, format, ledger |
| `PostToolBatch` | no | budget warn/force |
| `SubagentStart` / `SubagentStop` | no | contract enforcement |
| `TaskCreated` / `TaskCompleted` | yes | TaskCompleted verifies gates |
| `Stop` / `StopFailure` | **yes (exit 2)** | DoD gate; capped at `AIOS_GATE_MAX_BLOCKS` |
| `PreCompact` / `PostCompact` | no | checkpoint / re-prime |
| `FileChanged` | no | reindex on structural changes |
| `Notification` | no | digest |
| `SessionEnd` | no | cost report + promotion scan |

## Writing a hook
- `source .claude/hooks/_common.sh` for `deny`, `emit_context`, `quiet`.
- Read JSON from stdin; write JSON to stdout only when you *want* context.
- Deny with **exit 2** plus a `reason`. Non-zero-other is a soft error shown to the user.
- Fast: guards < 1s, gates are allowed minutes and have timeouts in `settings.json`.
- Idempotent, and never dependent on the model's cooperation.

## Debugging
`claude --debug` shows hook loading and skipped files. A hook that fails to parse is skipped
silently — **always run `bin/aios doctor` after editing hooks.**
