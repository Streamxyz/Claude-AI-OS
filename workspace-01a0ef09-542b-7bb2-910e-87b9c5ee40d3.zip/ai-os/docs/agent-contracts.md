# Agent output contracts

Every agent returns **one JSON object**, ≤ 2000 tokens, validated on `SubagentStop`.

## Why this is the biggest saving in the OS
A subagent may burn 50k tokens doing useful work. Without a contract, it returns a narrative summary
that costs another 5–30k tokens of *your* window. With a contract, it returns ≤ 2k tokens of
structure — a 70–90% cut on every delegation, and the return is machine-checkable.

## Schema format (`os/registry/contracts/<agent>.json`)
```json
{
  "agent": "implementer",
  "format": "single JSON object, no markdown fences, no prose",
  "max_return_tokens": 2000,
  "required": ["task_id", "files_changed", "gates", "confidence"],
  "properties": { "confidence": { "type": "number" }, "gates": { "type": "array" } }
}
```

## Adding an agent
1. `.claude/agents/<name>.md` — one-line `description` (context cost per session), `model`, `effort`,
   `tools` (least privilege), `isolation: worktree` if it mutates files.
2. `os/registry/contracts/<name>.json` — required keys + types.
3. An `## Output contract` section in the agent body repeating the shape.
4. `bin/aios doctor` (schema parses) + an eval fixture in `evals/contracts/`.

## Failure modes the hook catches
- prose instead of JSON (logged to `state/.contract_blocks`)
- malformed JSON
- missing required keys
- over the token cap
