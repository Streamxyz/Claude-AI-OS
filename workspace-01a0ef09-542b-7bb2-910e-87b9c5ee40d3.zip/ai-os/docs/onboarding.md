# Onboarding — 30 minutes to a running AI OS

## 1. Install (5 min)
```bash
cd your-repo
cp -r /path/to/ai-os/.claude .claude
cp -r /path/to/ai-os/{bin,scripts,os,state,specs} .
bin/aios boot
bin/aios doctor --all      # fix every FAIL before running autonomous work
```

## 2. Read three files (10 min)
- `CLAUDE.md` — the constitution (≤150 lines; everything else is a pointer)
- `TOKEN-ECONOMY.md` §3 — the fourteen mechanics
- `OPERATIONS.md` §2 — what escalates to you

## 3. Run one real task (15 min)
```bash
bin/aios spec T-142          # write Goal + Acceptance criteria
bin/aios run T-142           # see the dispatch plan and tier
bin/aios verify T-142        # gates
bin/aios cost T-142          # what it cost
```

## The mental model in four sentences
1. The human writes intent in `specs/intent/`. Nothing else.
2. Hooks decide what is allowed; the model cannot negotiate with a hook.
3. State lives in `state/`, so sessions can be compacted, resumed, or handed over.
4. Nothing is done until a gate says so and the evidence is on disk.

## Common first-week mistakes
- Writing a long `CLAUDE.md` instead of a rule or a skill.
- Letting agents return prose (the contract hook exists for exactly this).
- Reading the file tree instead of `state/index/repo.md`.
- Granting `bypassPermissions` because prompts are annoying. Fix the allowlist instead.
