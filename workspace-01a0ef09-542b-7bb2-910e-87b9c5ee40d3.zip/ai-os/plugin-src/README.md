# AI OS

**A Claude Code control plane for autonomous full-stack engineering.**
You write intent. AI OS plans, implements, verifies, and learns — while hooks hold the line.

```
specs/intent/T-142.md  ──►  aios run T-142  ──►  shipped, gate-green, ledgered
```

## Install

```bash
claude plugin marketplace add ./plugin     # or: /plugin marketplace add <repo-url>
claude plugin install ai-os@ai-os          # or: /plugin install ai-os@ai-os
```

Then, **in the project you want to run**:

```bash
aios adopt          # creates state/, specs/, products/ and merges the policy
aios doctor --all   # health check — fix every FAIL before autonomous work
```

## What you get

| Capability | Mechanism |
|---|---|
| Full-stack delivery (FE, BE, DB, infra, CI/CD) | 12 typed agents + 25 skills + worktree isolation |
| Autonomous long runs | dynamic workflows, routines, Stop-hook gates, `/goal` |
| Parallel work without collisions | `isolation: worktree` + file-ownership maps |
| Hard control | `PreToolUse` hooks — denied even when a subagent is the caller |
| 10–100× context savings | deferred MCP schemas, code-execution-with-MCP, truncation, JSON contracts |
| Zero-amnesia sessions | `state/` is the record; compaction protocol re-primes from `state/primer.md` |
| Verifiable output | gates + adversarial verifier agents + evidence on disk |
| Compounding quality | nightly cost/eval report → automatic rule and skill promotion |

## Commands (`aios` is on `PATH` while the plugin is enabled)

```bash
aios boot                     validate + rebuild indexes
aios doctor [--all]           health: policy, skills, agents, contracts, ledger, indexes
aios adopt                    make an existing project an AI OS project
aios spec   <id>              scaffold/validate an intent spec
aios plan   <id>              validate a plan (disjoint file ownership)
aios run    <id>              classify → dispatch (tier S/M/L/XL)
aios verify <id> [--gate g]   run the Definition-of-Done gates
aios gates                    list gates
aios review <id>              adversarial review fan-out
aios audit  [--scope s]       repo-wide dynamic workflow
aios cost   [--since 7d]      spend by task / agent / model
aios learn  [--dry-run]       promotion candidates (rule of three)
aios context [--check]        checkpoint → /compact → re-prime
aios ledger query --task T-1  the append-only event ledger
aios digest                   today's human digest
aios wt  <new|list|clean> <id>
```

Skills are namespaced: `/ai-os:aios-orchestrate`, `/ai-os:api-endpoint`, `/ai-os:security-review`, …
Agents: `@agent-ai-os:planner`, `@agent-ai-os:implementer`, `@agent-ai-os:verifier`, …

## The split that matters

| Root | Env var | Holds |
|---|---|---|
| **Install** | `CLAUDE_PLUGIN_ROOT` | skills, agents, hooks, scripts, gates, contracts — never write state here (updates wipe it) |
| **Project** | `CLAUDE_PROJECT_DIR` | `state/`, `specs/`, `products/`, `.claude/settings.json` |

## Autonomy in one table

| Tier | Scope | Human involvement | Gates |
|---|---|---|---|
| **S** | one file | none | typecheck, unit |
| **M** | 2–5 files | none | + lint, build |
| **L** | feature slice | plan approval | + e2e, review |
| **XL** | repo-wide | plan approval + budget cap | + workflow cross-check, security |

Escalation (3 gate failures · budget ×1.5 · protected path · ambiguity · payments/auth/PII/schema)
→ `state/approvals/pending.json`. The session keeps working instead of stalling.

## Trust notes — read before installing

- **Hooks fire in every session while the plugin is enabled**, including inside subagents.
  They are read-only guards, formatters, budget checks and gate runners. Review `hooks/hooks.json`
  and the scripts in `hooks/` before enabling.
- **`aios adopt` writes to your project**: it creates `state/`, `specs/`, `products/`, may append
  an AI OS section to `CLAUDE.md`, and merges the allow/ask/deny policy into `.claude/settings.json`
  (backing it up to `.claude/settings.json.bak` first). Use `aios adopt --no-policy` to skip the
  settings merge.
- **No MCP servers are bundled.** The plugin ships zero MCP servers so nothing tries to connect at
  startup. Add drivers yourself with `claude mcp add`, and route bulk operations through
  `aios-mcp-exec` so intermediate data never enters context.
- **No network access is required** by the OS itself; gates, ledger, and indexes are local.
- Binaries: `bin/aios`, `bin/aios-mcp-tools`, `bin/aios-mcp-exec` are added to the Bash tool's
  `PATH` after your own entries, so they cannot shadow `git`, `ls`, or other system commands.
- Enable per project (project scope) rather than globally if you only run AI OS on some repos.

## Requirements

Claude Code ≥ 2.1.281 · Python 3.11+ · git 2.40+.
Dynamic workflows need ≥ 2.1.154 (on by default on paid plans; enable in `/config` on Pro).
Agent teams are experimental: `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`.

## Uninstall

```bash
claude plugin uninstall ai-os@ai-os     # removes the install dir
# state/, specs/ and products/ in your projects are yours and are kept
```

---

MIT licensed. Manual: `docs/` inside the plugin (never auto-loaded).
