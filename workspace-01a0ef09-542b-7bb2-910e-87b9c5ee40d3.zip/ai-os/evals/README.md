# Evals

Regression tests for **agent behaviour**, not just product code. If a prompt, skill, rule, or
contract changes and nothing here breaks, the change was probably cosmetic.

| Scenario | Assertion |
|---|---|
| `routing.jsonl` | 20 intents → expected tier (S/M/L/XL) |
| `hooks/destructive.jsonl` | each blocked command exits 2 with a reason |
| `hooks/protected-paths.jsonl` | writes to `.env`, migrations, infra are denied |
| `contracts/<agent>.jsonl` | each fixture return validates and is ≤ 2000 tokens |
| `skills/<skill>.jsonl` | trigger prompts load the right skill; near-misses do not |
| `gates/<gate>.jsonl` | each gate exits 0 on a green fixture, 1 on a red one |

## Rules
- Every rule in `.claude/rules/` has at least one eval — a rule without a test is a wish.
- Every hook guard has at least one positive (allowed) and one negative (denied) case.
- Run on every PR touching `.claude/`, `scripts/`, or `bin/`.
- Track pass rate **and** cost per eval — a cheaper config that passes is the goal.
