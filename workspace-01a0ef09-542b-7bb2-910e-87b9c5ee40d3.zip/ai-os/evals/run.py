#!/usr/bin/env python3
"""Eval harness — regression tests for agent behaviour, not just product code.

  evals/run.py             # run every suite
  evals/run.py routing     # one suite

Adding a suite: drop <name>.jsonl next to this file and implement check_<name>(rows).
A rule without an eval is a wish.
"""
from __future__ import annotations
import json, os, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EVALS = os.path.join(ROOT, "evals")
PY = sys.executable

def check_routing(rows) -> list[tuple[bool, str]]:
    out = []
    for r in rows:
        p = subprocess.run([PY, os.path.join(ROOT, "scripts", "router.py"), r["intent"]],
                           capture_output=True, text=True)
        got = dict(kv.split("=", 1) for kv in p.stdout.split() if "=" in kv).get("tier")
        out.append((got == r["expect_tier"], f"{r['intent'][:48]:<50} expect {r['expect_tier']} got {got}"))
    return out

def check_hooks_destructive(rows) -> list[tuple[bool, str]]:
    out = []
    hook = os.path.join(ROOT, ".claude", "hooks", "guard-bash.sh")
    env = dict(os.environ, CLAUDE_PROJECT_DIR=ROOT)
    for r in rows:
        payload = json.dumps({"tool_input": {"command": r["command"]}})
        p = subprocess.run([hook], input=payload, capture_output=True, text=True, env=env)
        denied = p.returncode == 2
        good = denied if r["expect"] == "deny" else not denied
        out.append((good, f"{r['command'][:44]:<46} expect {r['expect']} got "
                          f"{'deny' if denied else 'allow'}"))
    return out

SUITES = {"routing": check_routing, "hooks-destructive": check_hooks_destructive}

def main() -> int:
    want = sys.argv[1:] or list(SUITES)
    total = passed = 0
    for name in want:
        path = os.path.join(EVALS, f"{name}.jsonl")
        if not os.path.exists(path) or name not in SUITES:
            print(f"{name}: no suite"); continue
        rows = [json.loads(l) for l in open(path) if l.strip()]
        results = SUITES[name](rows)
        ok = sum(1 for g, _ in results if g)
        total += len(results); passed += ok
        print(f"\n{name}: {ok}/{len(results)}")
        for good, line in results:
            print(f"  {'ok  ' if good else 'FAIL'} {line}")
    print(f"\nTOTAL: {passed}/{total}  " + ("PASS" if passed == total else "FAIL"))
    return 0 if passed == total else 1

if __name__ == "__main__":
    raise SystemExit(main())
