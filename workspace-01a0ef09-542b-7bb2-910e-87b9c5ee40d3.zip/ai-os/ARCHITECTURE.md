# AI OS — Architecture

**A Claude Code–based operating system for autonomous full-stack engineering.**

> Design goal: *maximum autonomy per human message, minimum tokens per unit of shipped software, total control over what the model can see and do.*

- Version: `1.0.0` · Target runtime: Claude Code ≥ `2.1.281` · Models: Opus 5.5 / Sonnet 5.5 / Haiku 4.5 / Fable 5.1
- Companion docs: [`README.md`](README.md) · [`TOKEN-ECONOMY.md`](TOKEN-ECONOMY.md) · [`OPERATIONS.md`](OPERATIONS.md) · [`ROADMAP.md`](ROADMAP.md)

---

## 0. What "AI OS" means here

Claude Code is a *loop*. An OS is what you build **around** a loop: policy, memory, processes, drivers, scheduler, filesystem, telemetry, and a package manager. AI OS is a **repository-shaped control plane** that turns a single Claude Code session into a supervised, self-verifying engineering organization.

| OS concept | AI OS implementation | Claude Code primitive |
|---|---|---|
| Bootloader | `bin/aios boot` → validate + prime | `SessionStart` hook |
| Kernel | context governor + policy engine | `CLAUDE.md`, `.claude/rules/*`, `settings.json`, hooks |
| Kernel mode / syscalls | deterministic scripts, capped output | `scripts/*`, `bin/aios`, `PostToolUse` truncators |
| Processes | isolated workers w/ own context | subagents, `isolation: worktree` |
| Threads / pools | dozens–hundreds of workers | **dynamic workflows** (script-held plan) |
| Supervisor teams | lead + peers + shared task list | **agent teams** (experimental) |
| Cron / daemons | nightly unattended runs | **routines** (schedule / API / GitHub triggers) |
| Device drivers | external systems | MCP servers (+ **tool search**, deferred loading) |
| Code intelligence driver | symbol navigation, live diagnostics | LSP plugin |
| Filesystem & memory | layered, JIT-loaded state | `state/`, auto memory, notes |
| IPC / mailbox | append-only JSONL + task files | `state/bus/*.jsonl`, cross-session messaging |
| Package manager | installable capability bundles | **plugins** + marketplaces |
| Scheduler | fan-out orchestration | workflows, `/tasks`, background agents |
| Observability | token ledger, traces, cost, evals | `state/ledger.jsonl`, `scripts/cost_report.py` |
| Security policy | enforced, non-negotiable | `PreToolUse` hooks (exit 2 = deny) + `permissions.deny` |
| Shell / UI | human surfaces | `specs/intent/*.md`, `state/approvals/`, artifact digest |

The **human writes intent, not instructions.** Everything else is system.

---

## 1. Layer model (L0 → L6)

```
┌──────────────────────────────────────────────────────────────────────────┐
│ L6  LEARNING      evals · skill-rot detector · promote.py · cost optimizer│
├──────────────────────────────────────────────────────────────────────────┤
│ L5  VERIFICATION  gates · Stop-hook DoD · verifier agents · /goal         │
├──────────────────────────────────────────────────────────────────────────┤
│ L4  MEMORY        auto memory · state/ notes · indexes · compaction       │
├──────────────────────────────────────────────────────────────────────────┤
│ L3  PROCESSES     subagents · agent teams · workflows · routines          │
├──────────────────────────────────────────────────────────────────────────┤
│ L2  CAPABILITY    skills (3-level) · scripts · MCP · LSP · tool search    │
├──────────────────────────────────────────────────────────────────────────┤
│ L1  KERNEL        CLAUDE.md · rules · settings.json · hooks · router      │
├──────────────────────────────────────────────────────────────────────────┤
│ L0  SUBSTRATE     repo · git worktrees · sandbox · secrets · runtimes     │
└──────────────────────────────────────────────────────────────────────────┘
        ↕  enforced by hooks (deterministic) — not by model goodwill
```

### L0 — Substrate
`git` + worktree isolation, a locked toolchain (`mise`/`asdf`), a sandboxed exec runtime for the code-execution-with-MCP shim, secrets via env only (never in files), and immutable protected paths. Every product lives in `products/<app>/`, every task gets a worktree, nothing touches `main` without a green gate.

### L1 — Kernel (context governor + policy)
- **`CLAUDE.md`** — the constitution. ≤ 150 lines. Facts only; procedures are exiled to skills.
- **`.claude/rules/*.md`** — path-scoped rules loaded *only* when matching files are touched (`paths:` frontmatter).
- **`settings.json`** — permissions, model, effort, hooks wiring, env. Enforced whether or not the model agrees.
- **Hooks** — policy-as-code. A rule that matters is a script, not a sentence.
- **Router** — `scripts/router.py` classifies each incoming intent into a **tier** (S/M/L/XL) which determines model, effort, parallelism, and gate depth.

### L2 — Capability
- **Skills** — 3-level progressive disclosure: metadata always in context (~150 tok), `SKILL.md` on match, bundled `references/` + `scripts/` on demand. Bundled size is effectively unbounded because nothing is read unless named [1](https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills).
- **Syscalls** — `scripts/` + `bin/aios`. Deterministic, versioned, output-capped. The model calls one command and reads 20 lines instead of reading 20 files.
- **MCP drivers** — connected through `.mcp.json`, schemas **deferred by default** and loaded on demand via tool search. `alwaysLoad: true` only for tiny hot servers.
- **Code-execution-with-MCP shim** (`scripts/mcp_exec/`) — two generic tools (`tools.search`, `exec.run`) instead of N schemas; intermediate data stays in the sandbox. Anthropic's own Salesforce→Sheets demo collapsed ~150k tokens to ~2k [2](https://aiforanything.io/blog/claude-mcp-code-execution-token-efficient-agents-2026); community reproductions report 95%+ cuts on bulk operations [3](https://www.reddit.com/r/ClaudeCode/comments/1qmv7ww/an_experiment_to_test_the_benefits_of_code).
- **LSP** — go-to-definition and live diagnostics instead of grep-and-guess.

### L3 — Processes
| Mechanism | Holds the plan | Scale | Use in AI OS |
|---|---|---|---|
| Subagent | Claude, turn by turn | a few per turn | typed workers: explorer, implementer, testsmith, reviewer |
| Agent team | Lead agent | handful of peers | long feature slices with file ownership |
| Dynamic workflow | **A script** | dozens–hundreds | repo-wide audits, migrations, cross-checked research |
| Routine | Cloud scheduler | unattended | nightly maintenance, PR review, alert triage |

Dynamic workflows are the scale lever: the orchestration lives in a JavaScript script, so intermediate results live in **script variables, not context** — the runtime supports up to 16 concurrent agents and 1,000 total per run [4](https://aipractitioner.substack.com/p/claude-dynamic-workflows-scaling). Requires v2.1.154+; on Pro, enable in `/config`.

### L4 — Memory & state
Four tiers, cheapest first:
1. **Auto memory** — Claude's own cross-session notes (`memory: project` on agents).
2. **`state/index/*.md`** — hand-maintained compact maps (repo, skills, tools). Read the map, not the territory.
3. **`state/notes/<topic>.md`** — structured notes written at milestones, re-injected JIT.
4. **`state/ledger.jsonl`** — append-only ground truth for events, tokens, costs, gate verdicts.

Compaction is a *protocol*, not an event: `PreCompact` checkpoints structured notes → `/compact` → `PostCompact` re-injects `state/primer.md`. Anthropic's guidance for long-horizon work is exactly this trio: compaction, structured note-taking, sub-agent architectures [5](https://agentic-ai.readthedocs.io/en/latest/ContextEngineering/anthropic/).

### L5 — Verification
Nothing is "done" because the model said so. Four independent mechanisms, escalating in strength:
1. **Gates** (`scripts/gate.py run <name>`) — typecheck, lint, unit, build, e2e, security. Machine verdict, JSON out.
2. **`Stop` hook** — the turn cannot end while the DoD gate fails (with a consecutive-block cap so it can't deadlock).
3. **`/goal` condition** — a separate evaluator re-checks after every turn and keeps Claude working until the goal resolves.
4. **Verifier agents / adversarial workflow** — a fresh model tries to refute the result. The builder is never the grader.

Rule: **evidence, not assertions.** Paste the test output, the exit code, the screenshot.

### L6 — Telemetry & learning
Every event hits the ledger. Nightly, `scripts/cost_report.py` + `scripts/promote.py` surface:
- cost per shipped task, per tier, per model
- gate failure histograms (which gate burns the most retries → new rule candidate)
- skill-rot signals (skill invoked but not followed / frequently patched) → rewrite proposal
- repeated corrections → promoted into `.claude/rules/` or a skill (never left in chat)

---

## 2. The main pipeline: intent → shipped

```
specs/intent/ID.md
   │
   ▼  UserPromptSubmit hook → scripts/router.py  (classify, ≤ 200 tok, haiku)
┌──────────────────────────────────────────────────────────────────────┐
│ TIER S  single file, known fix      → implementer(sonnet) → gate:unit │
│ TIER M  1–5 files, clear scope      → planner → implementer → gates   │
│ TIER L  feature slice, cross-cut    → plan → agent team (worktrees)   │
│ TIER XL repo-wide / research        → dynamic workflow (script plan)  │
└──────────────────────────────────────────────────────────────────────┘
   │                                                    │
   ▼ state/tasks/ID.json (spec, plan, owners, gates)    ▼ verifier + gates
   │                                                    │
   ▼ worktree per worker ──────── merge ────► release ──┘
                                                │
                                                ▼
                              ledger + eval + promote (L6)
```

**Context flow is the product.** At every arrow, the amount of text crossing the boundary is capped by a script, not by hope.

---

## 3. Repository layout

```
ai-os/
├── CLAUDE.md                  # constitution (≤150 lines, pointers only)
├── README.md                  # operator quickstart
├── ARCHITECTURE.md            # this file
├── TOKEN-ECONOMY.md           # budget model, routing, savings mechanics
├── OPERATIONS.md              # autonomy ladder, escalation, on-call
├── ROADMAP.md                 # maturity ladder L0→L5
│
├── .claude/
│   ├── settings.json          # permissions, model, effort, hooks
│   ├── settings.local.json    # personal overrides (gitignored)
│   ├── rules/                 # path-scoped rules (load on match only)
│   ├── agents/                # typed worker definitions
│   ├── skills/                # capability packages (SKILL.md + refs + scripts)
│   ├── hooks/                 # policy-as-code
│   ├── workflows/             # saved dynamic workflows
│   ├── output-styles/         # response contracts
│   └── plugins/               # pinned plugin set
│
├── bin/aios                   # CLI: boot/run/spec/plan/verify/cost/learn/gc
├── scripts/                   # syscalls (deterministic, output-capped)
│   ├── gates/                 # typecheck.sh lint.sh test.sh build.sh e2e.sh sec.sh
│   ├── mcp_exec/              # code-execution-with-MCP shim
│   └── lib/                   # ledger.py budget.py contract.py common.py
│
├── os/                        # runtime packages
│   ├── kernel/                # loop policy, routing table, invariants
│   ├── memory/                # primer, notes, compaction protocol
│   ├── bus/                   # event bus + mailbox (JSONL)
│   ├── registry/              # tool/skill/agent registry + search index
│   ├── sandbox/               # exec policy for mcp_exec
│   └── observability/         # traces, metrics, dashboards
│
├── state/                     # runtime state (the OS "disk")
│   ├── primer.md  INDEX.md  ledger.jsonl
│   ├── tasks/<id>.json        # one record per unit of work
│   ├── notes/<topic>.md       # structured notes (JIT)
│   ├── approvals/pending.json # the human queue
│   ├── index/{repo,skills,tools}.md
│   └── traces/                # per-run traces
│
├── specs/intent/              # ← the ONLY thing a human writes
├── products/                  # generated full-stack apps
├── evals/                     # eval harness + scenarios
├── docs/                      # long-form references (never auto-loaded)
└── diagrams/                  # rendered architecture
```

**Why this shape:** every directory has exactly one load policy. `docs/` is never loaded. `state/index/` is loaded on demand. `.claude/rules/` loads on path match. `CLAUDE.md` loads always — so it must stay tiny. The layout *is* the token policy.

---

## 4. Skills — the capability set

Skill metadata is the only part permanently in context, so descriptions are written as **trigger conditions**, not summaries. Format: `Use when …`. Do not ….

### 4.1 System skills (the OS itself)

| Skill | Invocation | Purpose | Bundled files |
|---|---|---|---|
| `aios-boot` | `/aios-boot`, auto on fresh clone | validate OS, rebuild indexes, print digest | `scripts/check.sh` |
| `aios-orchestrate` | `/aios-orchestrate <intent>` | the full pipeline: spec→plan→dispatch→verify→learn | `references/tiers.md`, `references/dod.md` |
| `aios-spec` | auto on vague intent | turn intent into a testable spec (`specs/intent/`) | `templates/spec.md` |
| `aios-plan` | `/aios-plan <task>` | implementation plan + **file-ownership map** | `templates/plan.md` |
| `aios-implement` | auto in worktree | implement one slice against a plan | `references/patch-contract.md` |
| `aios-verify` | `/aios-verify`, Stop hook | run the DoD gate set, return JSON verdict | `scripts/gate.py` |
| `aios-review` | `/aios-review` | adversarial multi-agent review (3 angles) | `references/rubric.md` |
| `aios-context` | `/aios-context`, auto at 60% | checkpoint → compact → re-prime | — |
| `aios-cost` | `/aios-cost` | token/cost report + top-3 optimizations | `scripts/cost_report.py` |
| `aios-learn` | auto at SessionEnd | harvest corrections → rule/skill proposals | `scripts/promote.py` |
| `aios-audit` | `/aios-audit` | repo-wide dynamic workflow (audit/verify/synthesize) | — |
| `aios-release` | `/aios-release` | version, changelog, tag, migrate check | `templates/changelog.md` |
| `aios-incident` | routine (API trigger) | alert triage → root cause → draft PR | `references/triage.md` |

### 4.2 Engineering skills (domain, loaded on demand)

| Skill | Loads when | Bundled |
|---|---|---|
| `api-endpoint` | adding/changing an HTTP route | `references/contract-style.md`, `scripts/scaffold.py` |
| `db-migration` | schema change | `references/safety.md`, `scripts/migrate.sh` |
| `ui-component` | building/changing UI | `references/design-tokens.md`, `scripts/scaffold.py` |
| `e2e-test` | browser-level verification | `references/selectors.md` |
| `ci-pipeline` | CI config change | `templates/pipeline.yml` |
| `deploy` | shipping an environment | `references/environments.md`, `scripts/deploy.sh` |
| `security-review` | auth, payments, PII, or `/security-review` | `references/owasp-top.md` |
| `perf-profile` | "slow", latency budgets | `scripts/profile.sh` |
| `observability` | adding metrics/traces/logs | `references/naming.md` |
| `docs-sync` | public API changed | `scripts/docs_drift.py` |
| `deps-upgrade` | dependency bumps | `scripts/upgrade.sh` |
| `debug` | test/build failure investigation | `references/triage-tree.md` |

**Skill authoring rules (enforced by `bin/aios doctor`):**
1. `SKILL.md` body ≤ 1 screen (~120 lines). Everything else goes to `references/`.
2. Description starts with `Use when …` and names at least one negative case.
3. Any deterministic step is a script in the skill's `scripts/`, never prose steps.
4. Every skill ends with a **Verify** section naming a command that exits 0/1.
5. No skill duplicates another's trigger. Overlap is a routing bug.

---

## 5. Agents — the worker set

Agents are typed processes. Each has a **model, an effort, a tool budget, and an output contract**. Subagent descriptions cost context every session (Claude Code warns above 15k tokens combined), so descriptions are one line each.

| Agent | Model | Effort | Tools | Isolation | Output contract |
|---|---|---|---|---|---|
| `classifier` | haiku | low | Read, Glob, Grep | — | `{tier, skills[], risk, reason}` ≤ 80 tok |
| `explorer` | haiku | low | Read, Grep, Glob | — | compact file map ≤ 1.5k tok |
| `planner` | opus | high | read-only + Bash(ro) | — | plan + ownership map ≤ 3k tok |
| `implementer` | sonnet | medium/high | full | `worktree` | diff summary + gate results ≤ 1k tok |
| `testsmith` | sonnet | medium | full | `worktree` | test list + pass/fail ≤ 800 tok |
| `reviewer` | sonnet | medium | read-only | — | findings JSON (severity, file, line) ≤ 1.5k tok |
| `security-auditor` | opus | high | read-only | — | findings JSON ≤ 1.5k tok |
| `verifier` | haiku/sonnet | low | Bash, Read | `worktree` | `{pass: bool, evidence[], refutations[]}` ≤ 1k tok |
| `scribe` | haiku | low | Read, Write, Edit | — | updated notes; no prose in return |
| `resolver` | sonnet | medium | full | `worktree` | fix summary ≤ 800 tok |
| `migrator` | sonnet | medium | full | `worktree` | per-file result table |
| `cost-optimizer` | haiku | low | Read, Bash(ro) | — | top-3 savings with numbers |

Contracts are validated by `scripts/contract.py` on `SubagentStop` — oversized or malformed returns are rejected and the agent is re-prompted with the schema. **This is the single biggest context firewall in the system.**

---

## 6. Hooks — policy-as-code

Hooks are where "full control" actually lives: they run whether or not the model feels like cooperating, and they cost zero context unless they return text.

| Event | Handler | Behaviour | Context cost |
|---|---|---|---|
| `SessionStart` | `hooks/session-start.sh` | ensure dirs, verify toolchain, print ≤ 25-line digest | ~250 tok |
| `UserPromptSubmit` | `hooks/route.py` | classify tier, inject primer + relevant index lines | ~400 tok |
| `PreToolUse:Bash` | `hooks/guard-bash.sh` | **deny** destructive/net/secret commands (exit 2) | 0 |
| `PreToolUse:Write\|Edit` | `hooks/guard-paths.sh` | protect `.env`, migrations, infra, `main`-only files | 0 |
| `PostToolUse:Bash` | `hooks/truncate.py` | cap stdout to 200 lines / 8 KB + tail marker | saves 10–100× |
| `PostToolUse:Write\|Edit` | `hooks/on-edit.sh` | formatter + append to ledger | 0 |
| `PostToolBatch` | `hooks/budget.py` | estimate context; at 60% → hint `/aios-context`, at 80% → force | ~60 tok |
| `Stop` | `hooks/stop-gate.sh` | run DoD; exit 2 blocks the turn ending (capped) | 0 |
| `SubagentStop` | `hooks/contract.py` | enforce JSON schema + size limits | 0 |
| `PreCompact` | `hooks/checkpoint.py` | persist structured notes + open tasks | 0 |
| `PostCompact` | `hooks/reprime.py` | re-inject `state/primer.md` | ~600 tok |
| `TaskCompleted` | `hooks/task-gate.py` | verify gate passed before marking done | 0 |
| `FileChanged` | `hooks/reindex.py` | on `package.json`, schema, `.mcp.json`, `CLAUDE.md` | 0 |
| `Notification` | `hooks/digest.py` | append to daily digest | 0 |
| `SessionEnd` | `hooks/learn.py` | cost report + promotion proposals | 0 |

Golden rule: **if a rule matters, it is a hook.** `CLAUDE.md` is guidance; a hook is law.

---

## 7. Scripts — syscalls

| Script | Contract |
|---|---|
| `bin/aios` | subcommands: `boot · doctor · spec · plan · run · verify · cost · learn · gc · wt` |
| `scripts/router.py` | `intent → {tier, model, effort, parallelism, gates[]}` (deterministic heuristics, optional haiku tiebreak) |
| `scripts/gate.py` | `run <gate>` → `{"gate","pass","duration_ms","evidence_path"}`; gates in `scripts/gates/` |
| `scripts/ledger.py` | `append`/`query` append-only JSONL: task, agent, model, tokens, cache hit, cost, verdict |
| `scripts/budget.py` | context estimator + compaction trigger thresholds |
| `scripts/index.py` | build `state/index/repo.md`: path → one-line purpose, exports, size |
| `scripts/contract.py` | JSON-schema + size validation for agent returns |
| `scripts/primer.py` | assemble minimal re-entry context from `state/` |
| `scripts/cost_report.py` | per-task/agent/model cost, Pareto frontier, savings suggestions |
| `scripts/promote.py` | turn ≥3 repeated corrections into a rule/PR proposal |
| `scripts/worktree.py` | create/claim/clean task worktrees |
| `scripts/mcp_exec/tools.py` | `search(query)` over MCP tool registry → trimmed signatures |
| `scripts/mcp_exec/exec.py` | run code against MCP servers; only the return value enters context |
| `scripts/digest.py` | daily human digest (markdown → artifact) |

Output discipline: every syscall prints a **bounded summary** (default 40 lines). Verbose output goes to a file; the model gets the path plus the first lines.

---

## 8. MCP & integrations

- `.mcp.json` declares the project driver set: `github`, `postgres`, `sentry`, `linear`, `playwright`, `filesystem`, `context7`(docs).
- **Tool schemas are deferred by default** and loaded on demand by tool search; `alwaysLoad: true` is reserved for servers with < 8 small tools that are used every session.
- Heavy bulk work (many rows, many API objects) goes through `scripts/mcp_exec/` so intermediate payloads never enter context.
- MCP servers are also **channels**: an inbound alert can push a message into a live session, which is how `aios-incident` starts without a human.
- Trust model: only pinned, reviewed servers; every server is a prompt-injection surface and is treated as untrusted input.

---

## 9. State machine for a task

```
NEW → SPEC → PLAN → DISPATCH → IMPLEMENT → GATE → REVIEW → MERGE → LEARN
                ↑         ↓          ↓         ↓
             (blocked)  (worktree) (fail→RESOLVER, max 3)
                                        ↓ (3rd fail)
                                   ESCALATE → state/approvals/
```

`state/tasks/<id>.json` is the record:

```json
{
  "id": "T-142",
  "spec": "specs/intent/T-142.md",
  "tier": "M",
  "model_plan": ["opus:planner", "sonnet:implementer", "haiku:verifier"],
  "files_owned": {"implementer": ["products/app/src/api/*"]},
  "gates": ["typecheck", "lint", "unit", "build"],
  "attempts": 1,
  "tokens": {"in": 0, "out": 0, "cache_read": 0},
  "status": "IMPLEMENT",
  "evidence": ["state/traces/T-142/gate-unit.log"]
}
```

Nothing about a task lives in a chat transcript. If it isn't in `state/`, it doesn't exist — which is what makes compaction, resume, and handover safe.

---

## 10. Autonomy & safety

Full autonomy without full control is a liability. AI OS separates them:

- **Autonomy** is granted per *tier*: S/M run unattended; L runs unattended behind gates and file ownership; XL needs plan approval.
- **Control** is absolute and non-negotiable: `permissions.deny` + `PreToolUse` hooks hard-block destructive shell, secret reads, force-push, prod deploy, and writes to protected paths — regardless of permission mode.
- **Escalation ladder** (see [`OPERATIONS.md`](OPERATIONS.md)): 3 gate failures, budget overrun, ambiguity > threshold, or any protected-path touch → item lands in `state/approvals/pending.json` and the session continues on other work instead of blocking.
- **Economy guard**: `budget.py` enforces a per-task token ceiling; exceeding it pauses the task and escalates rather than silently burning credits.

---

## 11. Invariants (break these and the OS degrades)

1. `CLAUDE.md` never exceeds 150 lines; growth is redirected to rules, skills, or `docs/`.
2. No agent returns prose. Every return is a validated JSON contract.
3. No raw command output over 200 lines enters context.
4. No task state lives only in a transcript.
5. No merge without a green gate and evidence on disk.
6. No skill without a `Verify` command; no rule without a hook or a test.
7. Every token spend is ledgered; every night produces a cost report.
8. A correction repeated three times becomes a rule or a script — never a fourth explanation.

---

## 12. Packaging as a plugin

`scripts/build-plugin.py` mirrors the repo into the official plugin layout and
writes `.claude-plugin/plugin.json` + a marketplace catalog. The one structural
change it encodes is the **install / project split**:

| Path | Env var | Holds | Written by |
|---|---|---|---|
| install (`HOME`) | `CLAUDE_PLUGIN_ROOT` → `AIOS_HOME` | skills, agents, hooks, scripts, gates, contracts, docs, policy | builds only |
| project (`ROOT`) | `CLAUDE_PROJECT_DIR` → `AIOS_ROOT` → cwd | `state/`, `specs/`, `products/`, `.claude/settings.json` | the OS, at runtime |

`locate(rel)` resolves project-override-first, else install; `homes(*rels)`
returns every existing base. Every script went from a single `ROOT` to this
pair — that is what lets an install be swapped without touching project state.

Plugin-specific constraints the packager enforces: hook commands become
`"${CLAUDE_PLUGIN_ROOT}"/hooks/…`; agent `skills:` references are namespaced
`ai-os:<skill>`; no root `CLAUDE.md`; no `commands/` (skills are the command
surface); no bundled MCP servers; `defaultEnabled: false`. Permissions cannot
ship in a plugin's `settings.json`, so `aios adopt` merges `policy/permissions.json`
into the project's `.claude/settings.json`.

Build output: 137 files — 25 skills, 12 agents, 16 hook handlers over 13 events,
12 contracts. Per-turn context tax ≈ **1165 tokens** (skills ≈835 + agents ≈330).

## 13. Sources

Anthropic engineering & docs used as the design basis:

- Agent Skills and progressive disclosure — https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills [1](https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills)
- Effective context engineering (compaction, structured notes, sub-agents) — https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents [5](https://agentic-ai.readthedocs.io/en/latest/ContextEngineering/anthropic/)
- Advanced tool use: Tool Search, Programmatic Tool Calling, Tool Use Examples — https://www.anthropic.com/engineering/advanced-tool-use [6](https://www.anthropic.com/engineering/advanced-tool-use)
- Code execution with MCP (token savings) — https://www.anthropic.com/engineering/code-execution-with-mcp [2](https://aiforanything.io/blog/claude-mcp-code-execution-token-efficient-agents-2026)
- Claude Code: extension overview & context costs — https://code.claude.com/docs/en/features-overview
- Claude Code: best practices — https://code.claude.com/docs/en/best-practices
- Claude Code: hooks reference — https://code.claude.com/docs/en/hooks
- Claude Code: subagents — https://code.claude.com/docs/en/sub-agents
- Claude Code: skills — https://code.claude.com/docs/en/skills
- Claude Code: dynamic workflows — https://code.claude.com/docs/en/workflows [4](https://aipractitioner.substack.com/p/claude-dynamic-workflows-scaling)
- Claude Code: memory (CLAUDE.md + auto memory) — https://code.claude.com/docs/en/memory
- Claude Code: routines — https://code.claude.com/docs/en/routines
- Models overview (Opus 5.5 / Sonnet 5.5 / Haiku 4.5 / Fable 5.1) — https://platform.claude.com/docs/en/models/overview
- Claude Cookbooks — https://github.com/anthropics/anthropic-cookbook
- Official plugin marketplace — https://github.com/anthropics/claude-plugins-official
