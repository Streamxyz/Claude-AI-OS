# Token Economy

**Every token in context is a decision the model can no longer make freely.**
This document is the budget model for AI OS. It is enforced by scripts, not by discipline.

---

## 1. The attention budget

Context is a finite attention budget with a *performance gradient*, not a hard cliff: recall and long-range reasoning degrade as token count climbs, long before the window is full [1](https://agentic-ai.readthedocs.io/en/latest/ContextEngineering/anthropic/). So the operating target is **not** "use the whole window" — it is *"keep the smallest high-signal set that produces the desired behaviour"*, and reserve headroom deliberately.

**AI OS target: never exceed 55% of the window in steady state.** Above 60% → checkpoint. Above 80% → forced compaction. That reserve is what lets a task finish instead of thrashing.

---

## 2. Budget allocation (200k window reference)

| Segment | Target | Hard cap | Owner |
|---|---|---|---|
| System prompt + built-in tools | ~8k | — | Claude Code |
| `CLAUDE.md` + loaded rules | 2.5k | 6k | `hooks/budget.py` |
| Skill metadata (≈35 skills × ~150) | 5k | 8k | `bin/aios doctor` |
| Agent descriptions (≈12 × ~60) | 1k | 15k (official warn) | `bin/aios doctor` |
| Hot tool definitions (MCP `alwaysLoad`, LSP) | 2k | 4k | `.mcp.json` |
| Session primer + index lines | 1.5k | 3k | `scripts/primer.py` |
| Working set (files, diffs, command output) | ≤ 45k | 60k | `hooks/truncate.py` |
| Conversation + agent returns | ≤ 10k | 20k | `hooks/contract.py` |
| **Reserve** | **≥ 90k** | — | `hooks/budget.py` |

The reserve is not waste. It is what makes compaction rare, prompts cacheable, and long tasks survivable.

---

## 3. The fourteen mechanics

### 3.1 Progressive disclosure (3 levels)
Level 1 metadata (name + description) is always in context — this is the routing layer and it costs ~150 tokens per skill. Level 2 (`SKILL.md`) loads only on match. Level 3 (`references/`, `scripts/`) is read by path only when named. Because the agent has a filesystem and code execution, the bundle size is effectively unbounded [2](https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills).

**Consequence:** put the knowledge in files, not in the prompt. A 5,000-line reference costs 0 tokens until the agent opens it.

### 3.2 Path-scoped rules
`.claude/rules/*.md` with `paths:` frontmatter load only when matching files are touched. A monorepo with 12 conventions pays for one, not twelve.

### 3.3 Deferred tool schemas (Tool Search)
MCP tools are deferred by default; Claude searches, then expands only what it needs [3](https://www.anthropic.com/engineering/advanced-tool-use). Reserve `alwaysLoad: true` for servers with few, small, always-used tools.

### 3.4 Code execution with MCP
Two generic tools (`tools.search`, `exec.run`) replace N schemas, and intermediate results stay in the sandbox — only the return value enters context. Anthropic's reference demo: ~150k tokens → ~2k [4](https://aiforanything.io/blog/claude-mcp-code-execution-token-efficient-agents-2026); independent reproductions report 95%+ on bulk operations [5](https://www.reddit.com/r/ClaudeCode/comments/1qmv7ww/an_experiment_to_test_the_benefits_of_code).

**Rule:** any MCP interaction touching > 20 objects or > 5 KB of payload goes through `scripts/mcp_exec/exec.py`.

### 3.5 Output truncation firewall
`PostToolUse:Bash` → `hooks/truncate.py` caps stdout at 200 lines / 8 KB, keeping head + tail + a `… N lines omitted, full: <path>` marker. Test logs, build output, and search results are the single largest source of accidental context bloat.

### 3.6 JSON contracts for agent returns
Every subagent returns validated JSON under a size cap (see `os/registry/contracts/*.json`), enforced on `SubagentStop`. Specialists return condensed 1–2k token summaries instead of dumping their whole window [1](https://agentic-ai.readthedocs.io/en/latest/ContextEngineering/anthropic/). Oversized → rejected and re-prompted with the schema.

### 3.7 Subagent isolation
Recon, test runs, and audits happen inside workers whose window is thrown away. Explore runs read-only and never floods the main session.

### 3.8 Deterministic gates
A gate is a script that exits 0/1 and writes evidence to disk. The conversation carries the verdict, not the 3,000-line test log.

### 3.9 Structured note-taking + compaction protocol
`PreCompact` → persist notes, tasks, decisions to `state/` → `/compact` → `PostCompact` → re-inject `state/primer.md` (~600 tokens). State lives on disk, so a compacted session loses nothing that mattered [1](https://agentic-ai.readthedocs.io/en/latest/ContextEngineering/anthropic/).

### 3.10 Indexes instead of exploration
`state/index/repo.md` is a compact map (path → one-line purpose → exports). Reading the map costs ~1/30 of walking the tree. Rebuilt by `scripts/index.py` on `FileChanged`.

### 3.11 Scripts over prose (syscalls)
Anything deterministic is a script. `bin/aios doctor` replaces 40 tool calls and ~15k tokens of reasoning with one command and 25 lines of output.

### 3.12 Prompt caching discipline
Cache read is ~90% cheaper than fresh input. Therefore: keep the stable prefix stable. `CLAUDE.md`, settings, tool definitions, and the primer must not churn mid-session; agent `experimental.cacheTtl: 1h` for long-lived workers; avoid mid-session model switches (they invalidate the cache).

### 3.13 Model & effort routing
| Work | Model | Effort |
|---|---|---|
| classify, extract, lint-triage, contract checks | `haiku` | `low` |
| implement, test, review | `sonnet` | `medium` |
| architecture, planning, hard debugging | `opus` | `high` |
| plans that must be right first time | `opus` | `xhigh` |
| frontier reasoning only (rare, gated) | `fable` | `high` |
| repo-wide swarms (workflows) | `haiku`/`sonnet` mix | `low`/`medium` |

Reference pricing: Haiku 4.5 $1/$5 · Sonnet 5.5 $2/$10 · Opus 5.5 $4/$20 · Fable 5.1 $10/$50 (per MTok) — https://platform.claude.com/docs/en/models/overview.
Effort is a first-class lever: `low` on Haiku for a classifier is cheaper *and* better-tempered than `high` on Opus.

### 3.14 Parallelism
Parallel tool calls in one block, parallel subagents, and workflows for fan-out cut wall-clock by up to ~90% on research-shaped work [1](https://agentic-ai.readthedocs.io/en/latest/ContextEngineering/anthropic/) — and, crucially, each parallel worker pays for its own context instead of sharing one.

---

## 4. Where the money goes (and what each fix is worth)

| Leak | Typical cost | Fix | Saving |
|---|---|---|---|
| All MCP schemas preloaded | 15k–140k per session | Tool Search + `mcp_exec` | 90–99% |
| Raw test/build output in chat | 5k–50k per run | `truncate.py` + gates | 80–95% |
| Agent returns prose dumps | 5k–30k per delegation | JSON contracts ≤ 2k | 70–90% |
| Re-reading the repo each task | 10k–40k | `state/index/repo.md` | ~95% |
| Long CLAUDE.md loaded every turn | 3k–10k × turns | ≤150 lines + path-scoped rules | 60–80% |
| Re-solving solved problems | full task cost | ledger-first: check `state/ledger.jsonl` + notes | up to 100% |
| Serial tool calls | wall-clock, not tokens | parallel batches + workflows | — |
| Cache-busting mid-session edits | ~10× on the prefix | freeze `CLAUDE.md`/tools during a run | ~90% on prefix |

---

## 5. Enforcement

| Control | Script | Trigger |
|---|---|---|
| Context estimate + compaction hint/force | `scripts/budget.py` | `PostToolBatch` @ 60% / 80% |
| Output cap | `hooks/truncate.py` | every `Bash` result |
| Contract size/schema | `hooks/contract.py` | `SubagentStop` |
| Skill metadata budget | `bin/aios doctor` | manual + CI |
| Per-task spend ceiling | `scripts/ledger.py` | before each dispatch |
| Cost Pareto report | `scripts/cost_report.py` | nightly routine |

**Ledger-first rule:** before solving a problem, query `state/ledger.jsonl` and `state/notes/`. If a materially similar task was solved before, reuse the artifact. The cheapest token is the one not spent.

---

## 6. Anti-patterns (banned in this repo)

1. Giant `CLAUDE.md` used as a documentation dump.
2. Reading a directory tree to "understand the project" (use `state/index/repo.md`).
3. Subagents returning narrative reports.
4. `cat`-ing a log with more than 200 lines.
5. `alwaysLoad: true` on a large MCP server.
6. Re-running a full test suite whose result is already in the ledger (unless inputs changed).
7. Editing `CLAUDE.md` mid-run (cache invalidation + behaviour drift).
8. Using Opus for classification or Haiku for architecture.
