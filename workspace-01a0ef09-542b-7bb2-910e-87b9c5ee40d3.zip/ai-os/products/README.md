# products/

One directory per delivered application. Generated, owned, and verified by the OS; a human owns the
intent in `specs/intent/`.

```
products/<app>/
├── app/ or src/        # application code
├── tests/              # colocated or here, depending on the stack
├── package.json        # scripts: dev, build, test, typecheck, lint
├── .claude/            # per-product skills (e.g. run-<app>, verify) recorded by /run-skill-generator
└── README.md           # how to run it — the OS reads this before building
```

## Rules
- Every product keeps a **recipe**: run `/run-skill-generator` once so `/run` and `/verify` know how
  to build and launch it. Without a recipe, agents rediscover the build every session — pure waste.
- Gates are per product: `scripts/gates/*` discovers `products/*/` automatically.
- Work happens in a worktree (`bin/aios wt new T-142`); `main` only ever receives merged, gate-green
  commits.
- Shared conventions live in `.claude/rules/` (api.md, ui.md, database.md, testing.md) — not here.
