# CLAUDE.md

<!-- Project instructions live above this line. AI OS section below — keep it short. -->

## AI OS

This project runs on **AI OS** (installed as a Claude Code plugin). It is a control plane:
the human writes intent in `specs/intent/`, hooks hold the line, state lives on disk,
and gates decide what "done" means.

```bash
aios boot                 # validate + rebuild indexes
aios doctor --all         # health: policy, skills, agents, contracts, ledger
aios spec T-142           # scaffold an intent spec
aios run T-142            # classify → dispatch (tier S/M/L/XL)
aios verify T-142         # run the Definition-of-Done gates
aios cost --since 7d      # spend by task / agent / model
aios context              # checkpoint → /compact → re-prime
```

### Non-negotiables
- **State on disk beats state in chat.** Tasks: `state/tasks/<id>.json`. History: `state/ledger.jsonl`.
- **Evidence beats assertion.** No success claim without a command, its exit code, and output on disk.
- **Deterministic beats generative.** Call `aios …`; do not re-derive.
- **No raw output > 200 lines** in context. Logs go to `state/traces/`.
- **Agent returns are JSON**, ≤ 2000 tokens, validated on `SubagentStop`.
- **Never** touch `.env`, `migrations/`, `infra/`, or CI without an approval item (hooks deny these).

### Pointers (read on demand, never preload)
repo map `state/index/repo.md` · skills `state/index/skills.md` · tools `state/index/tools.md` ·
notes `state/notes/<topic>.md` · approvals `state/approvals/pending.json`

Full manual: `docs/` inside the plugin — never auto-loaded.
