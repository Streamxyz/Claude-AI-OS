#!/usr/bin/env python3
"""Validate agent output contracts and task plans.

  contract.py --agent implementer --file result.json
  contract.py --validate-plan state/tasks/T-1.json    # file ownership must be disjoint
  contract.py --check-schemas
"""
from __future__ import annotations
import argparse, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import locate  # noqa: E402

CONTRACTS = locate("os/registry/contracts")
MAX_TOKENS = int(os.environ.get("AIOS_MAX_AGENT_RETURN_TOKENS", "2000"))

def approx_tokens(text: str) -> int:
    return max(1, len(text) // 4)

def validate(agent: str, obj: dict) -> list[str]:
    errs: list[str] = []
    path = os.path.join(CONTRACTS, f"{agent}.json")
    if not os.path.exists(path):
        return [f"no contract registered for agent '{agent}' (expected {path})"]
    schema = json.load(open(path))
    for key in schema.get("required", []):
        if key not in obj:
            errs.append(f"missing required key: {key}")
    for key, spec in (schema.get("properties") or {}).items():
        if key in obj and spec.get("type") == "array" and not isinstance(obj[key], list):
            errs.append(f"{key} must be an array")
        if key in obj and spec.get("type") == "number" and not isinstance(obj[key], (int, float)):
            errs.append(f"{key} must be a number")
    n = approx_tokens(json.dumps(obj))
    if n > MAX_TOKENS:
        errs.append(f"return is ~{n} tokens, cap is {MAX_TOKENS}")
    return errs

def validate_plan(path: str) -> list[str]:
    task = json.load(open(path))
    errs: list[str] = []
    seen: dict[str, str] = {}
    for sl in task.get("slices", []):
        owner = sl.get("owner", "?")
        for f in sl.get("files", []):
            if f in seen and seen[f] != owner:
                errs.append(f"file {f} owned by both {seen[f]} and {owner}")
            seen[f] = owner
    if not task.get("dod_gates"):
        errs.append("no dod_gates declared")
    return errs

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--agent", default="")
    ap.add_argument("--file", default="")
    ap.add_argument("--validate-plan", dest="plan", default="")
    ap.add_argument("--check-schemas", action="store_true")
    a = ap.parse_args()

    if a.check_schemas:
        n = 0
        for fn in sorted(os.listdir(CONTRACTS)) if os.path.isdir(CONTRACTS) else []:
            if fn.endswith(".json"):
                json.load(open(os.path.join(CONTRACTS, fn)))
                n += 1
        print(json.dumps({"schemas_ok": n}))
        return 0

    if a.plan:
        errs = validate_plan(a.plan)
        print(json.dumps({"plan": a.plan, "errors": errs}))
        return 1 if errs else 0

    if a.agent and a.file:
        obj = json.load(open(a.file))
        errs = validate(a.agent, obj)
        print(json.dumps({"agent": a.agent, "errors": errs}))
        return 1 if errs else 0

    ap.print_help()
    return 2
if __name__ == "__main__":
    raise SystemExit(main())
