#!/usr/bin/env python3
"""Context budget estimator and compaction trigger.

Returns a JSON verdict usable by hooks: {"used_pct": n, "action": "ok|warn|force"}.
"""
from __future__ import annotations
import argparse, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ROOT  # noqa: E402

DEFAULT_WINDOW = 1_000_000  # current models: 1M (Haiku 4.5: 200k)
WARN = int(os.environ.get("AIOS_BUDGET_WARN_PCT", "60"))
FORCE = int(os.environ.get("AIOS_BUDGET_FORCE_PCT", "80"))

def estimate(tokens: int, window: int = DEFAULT_WINDOW) -> dict:
    pct = round(100.0 * tokens / max(1, window), 1)
    action = "ok"
    if pct >= FORCE:
        action = "force"
    elif pct >= WARN:
        action = "warn"
    hint = {
        "ok": "",
        "warn": "Checkpoint to state/notes and state/tasks, then continue or run /aios-context.",
        "force": "Run /aios-context now: checkpoint, /compact, re-prime. Do not push through.",
    }[action]
    return {"used_pct": pct, "window": window, "action": action, "hint": hint,
            "reserve_tokens": max(0, window - tokens)}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tokens", type=int, default=0, help="estimated tokens currently in context")
    ap.add_argument("--window", type=int, default=DEFAULT_WINDOW)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    v = estimate(a.tokens, a.window)
    print(json.dumps(v) if a.json else f"{v['used_pct']}% — {v['action']} {v['hint']}".strip())
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
