"""Shared helpers for AI OS syscalls.

Every syscall follows the same contract:
  * deterministic, idempotent, safe to re-run
  * bounded stdout (default 40 lines) — verbose output goes to a file
  * machine-readable mode with --json for hooks and other scripts
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

# ---------------------------------------------------------------------------
# Two roots. Getting this wrong is the classic packaging bug: writing project
# state into the plugin's install directory (which is wiped on update).
#
#   HOME = where AI OS itself is installed  (this repo checkout, or the plugin dir)
#   ROOT = the project being operated on    (state/, specs/, products/ live here)
# ---------------------------------------------------------------------------
def _detect_home() -> str:
    for k in ("CLAUDE_PLUGIN_ROOT", "AIOS_HOME"):
        v = os.environ.get(k)
        if v:
            return v
    # <home>/scripts/lib/common.py -> <home>
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def _detect_root() -> str:
    for k in ("CLAUDE_PROJECT_DIR", "AIOS_ROOT"):
        v = os.environ.get(k)
        if v:
            return v
    return os.getcwd()

HOME = _detect_home()
ROOT = _detect_root()

STATE = os.path.join(ROOT, "state")
LEDGER = os.path.join(STATE, "ledger.jsonl")
TASKS = os.path.join(STATE, "tasks")
TRACES = os.path.join(STATE, "traces")
NOTES = os.path.join(STATE, "notes")
INDEX = os.path.join(STATE, "index")
APPROVALS = os.path.join(STATE, "approvals", "pending.json")
PRICING = {  # USD per MTok — verify against platform.claude.com/docs/en/models/overview
    "claude-opus-5-5": (4.0, 20.0),
    "claude-sonnet-5-5": (2.0, 10.0),
    "claude-fable-5-1": (10.0, 50.0),
    "claude-haiku-4-5": (1.0, 5.0),
}

def locate(rel: str) -> str:
    """Find an AI OS resource: project override first, then the installation."""
    p = os.path.join(ROOT, rel)
    if os.path.exists(p):
        return p
    return os.path.join(HOME, rel)

def homes(*rels: str) -> list[str]:
    """All existing locations for a resource (project first, then install)."""
    out = []
    for rel in rels:
        for base in (ROOT, HOME):
            p = os.path.join(base, rel)
            if os.path.isdir(p) and p not in out:
                out.append(p)
    return out

def ensure_dirs() -> None:
    for d in (STATE, TASKS, TRACES, NOTES, INDEX, os.path.join(STATE, "approvals"),
              os.path.join(STATE, "digest"), os.path.join(STATE, "bus"),
              os.path.join(ROOT, "specs", "intent"), os.path.join(ROOT, "products")):
        os.makedirs(d, exist_ok=True)

def now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

def ensure_dirs() -> None:
    for d in (STATE, TASKS, TRACES, NOTES, INDEX, os.path.join(STATE, "approvals"),
              os.path.join(STATE, "digest"), os.path.join(ROOT, "specs", "intent"),
              os.path.join(ROOT, "products")):
        os.makedirs(d, exist_ok=True)

def run(cmd: list[str], cwd: str | None = None, timeout: int = 600) -> tuple[int, str]:
    try:
        p = subprocess.run(cmd, cwd=cwd or ROOT, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except FileNotFoundError:
        return 127, f"command not found: {cmd[0]}"
    except subprocess.TimeoutExpired:
        return 124, f"timeout after {timeout}s: {' '.join(cmd)}"

def head(text: str, limit: int = 40) -> str:
    lines = (text or "").splitlines()
    if len(lines) <= limit:
        return "\n".join(lines)
    return "\n".join(lines[:limit]) + f"\n… {len(lines) - limit} more lines omitted"

def read_json(path: str, default=None):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default

def write_json(path: str, obj) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)

def cost_usd(model: str, tin: int, tout: int, cache_read: int = 0, cache_write: int = 0) -> float:
    tin_p, tout_p = PRICING.get(model, (3.0, 15.0))
    # cache reads bill at 0.1x input; cache writes at 1.25x input (Anthropic prompt caching)
    return round((max(0, tin - cache_read) * tin_p + cache_read * tin_p * 0.1
                  + cache_write * tin_p * 1.25 + tout * tout_p) / 1_000_000, 6)

def die(msg: str, code: int = 1) -> "NoReturn":  # type: ignore[valid-type]
    print(msg, file=sys.stderr)
    sys.exit(code)
