#!/usr/bin/env python3
"""state/ledger.jsonl — append-only ground truth for events, tokens, and cost.

Usage:
  ledger.py append --task T-1 --agent implementer --model claude-sonnet-5-5 \
                   --tokens-in 12000 --tokens-out 1800 --cache-read 9000 --gate unit --pass 1
  ledger.py query --task T-1 [--json]
  ledger.py query --similar "rate limiting"      # reuse before recompute
  ledger.py validate
"""
from __future__ import annotations
import argparse, json, os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import LEDGER, ROOT, cost_usd, ensure_dirs, now  # noqa: E402

def rows():
    if not os.path.exists(LEDGER):
        return []
    out = []
    with open(LEDGER) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                out.append({"__invalid__": line})
    return out

def append(rec: dict) -> dict:
    ensure_dirs()
    rec.setdefault("ts", now())
    rec.setdefault("tokens_in", 0)
    rec.setdefault("tokens_out", 0)
    rec.setdefault("cache_read", 0)
    rec.setdefault("cache_write", 0)
    rec["cost_usd"] = cost_usd(rec.get("model", "claude-sonnet-5-5"), rec["tokens_in"],
                               rec["tokens_out"], rec["cache_read"], rec["cache_write"])
    with open(LEDGER, "a") as f:
        f.write(json.dumps(rec) + "\n")
    return rec

def similar(query: str, limit: int = 5):
    toks = {t.lower() for t in query.split() if len(t) > 3}
    scored = []
    for r in rows():
        blob = json.dumps(r).lower()
        score = sum(1 for t in toks if t in blob)
        if score:
            scored.append((score, r))
    scored.sort(key=lambda x: -x[0])
    return [r for _, r in scored[:limit]]

def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("append")
    for k in ("task", "agent", "model", "event", "gate", "note"):
        a.add_argument("--" + k, default="")
    for k in ("tokens-in", "tokens-out", "cache-read", "cache-write"):
        a.add_argument("--" + k, type=int, default=0)
    a.add_argument("--pass", dest="passed", type=int, default=-1)
    a.add_argument("--json", action="store_true")

    q = sub.add_parser("query")
    q.add_argument("--task", default="")
    q.add_argument("--agent", default="")
    q.add_argument("--similar", default="")
    q.add_argument("--since", default="")
    q.add_argument("--limit", type=int, default=40)
    q.add_argument("--json", action="store_true")

    sub.add_parser("validate")

    args = ap.parse_args()

    if args.cmd == "append":
        rec = append({"task": args.task, "agent": args.agent, "model": args.model,
                      "event": args.event or "step", "gate": args.gate,
                      "pass": None if args.passed < 0 else bool(args.passed),
                      "note": args.note, "tokens_in": args.tokens_in,
                      "tokens_out": args.tokens_out, "cache_read": args.cache_read,
                      "cache_write": args.cache_write})
        print(json.dumps(rec) if args.json else
              f"{rec['ts']}  {rec['task'] or '-'}  {rec['agent'] or '-'}  "
              f"{rec['tokens_in']}in/{rec['tokens_out']}out  ${rec['cost_usd']:.4f}")
        return 0

    if args.cmd == "query":
        out = rows()
        if args.task:
            out = [r for r in out if r.get("task") == args.task]
        if args.agent:
            out = [r for r in out if r.get("agent") == args.agent]
        if args.since:
            out = [r for r in out if str(r.get("ts", "")) >= args.since]
        if args.similar:
            out = similar(args.similar, args.limit)
        else:
            out = out[-args.limit:]
        if args.json:
            print(json.dumps(out, indent=2))
        else:
            for r in out:
                print(f"{r.get('ts','?')}  {r.get('task') or '-':<8} {r.get('agent') or '-':<16} "
                      f"{r.get('event') or r.get('gate') or '':<12} "
                      f"{r.get('tokens_in',0)}in/{r.get('tokens_out',0)}out  ${r.get('cost_usd',0):.4f}")
        return 0

    if args.cmd == "validate":
        bad = [r for r in rows() if "__invalid__" in r]
        print(json.dumps({"rows": len(rows()), "invalid": len(bad)}))
        return 1 if bad else 0
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
