#!/usr/bin/env python3
"""Intent router: classify a task into a tier and emit the execution profile.

  router.py "add rate limiting to the API"            # text in
  router.py --task T-142                              # from spec file
  router.py "..." --json

Deterministic heuristics first. Ambiguity is reported, never guessed away silently:
the router says which signal fired so a human can correct the rule, not the output.
"""
from __future__ import annotations
import argparse, json, os, re, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib"))
from common import ROOT, TASKS, read_json  # noqa: E402

PROFILES = {
    "S":  {"model": "claude-sonnet-5-5", "effort": "medium", "parallelism": 1,
           "gates": ["typecheck", "unit"], "plan": False, "token_budget": "AIOS_TASK_TOKENS_S"},
    "M":  {"model": "claude-sonnet-5-5", "effort": "medium", "parallelism": 2,
           "gates": ["typecheck", "lint", "unit", "build"], "plan": True, "token_budget": "AIOS_TASK_TOKENS_M"},
    "L":  {"model": "claude-opus-5-5", "effort": "high", "parallelism": 4,
           "gates": ["typecheck", "lint", "unit", "build", "e2e"], "plan": True, "token_budget": "AIOS_TASK_TOKENS_L"},
    "XL": {"model": "claude-opus-5-5", "effort": "high", "parallelism": 16,
           "gates": ["typecheck", "lint", "unit", "build", "e2e", "sec"], "plan": True,
           "token_budget": "AIOS_TASK_TOKENS_XL"},
}
SKILL_HINTS = [
    (r"\b(endpoint|route|api|handler|webhook)\b", "api-endpoint"),
    (r"\b(schema|migration|column|table|index|prisma|sql)\b", "db-migration"),
    (r"\b(component|page|ui|button|form|layout|design)\b", "ui-component"),
    (r"\b(e2e|browser|playwright|user journey)\b", "e2e-test"),
    (r"\b(ci|pipeline|workflow|github action)\b", "ci-pipeline"),
    (r"\b(deploy|release|promote|rollout)\b", "deploy"),
    (r"\b(oauth|auth|security|permission|pii|payment|stripe|billing|inject\w*|xss|csrf|secret\w*|vulnerab\w+)", "security-review"),
    (r"\b(slow|latency|performance|memory|bundle size)\b", "perf-profile"),
    (r"\b(metric|log|trace|alert|dashboard|observab\w+)\b", "observability"),
    (r"\b(docs|readme|documentation)\b", "docs-sync"),
    (r"\b(dependenc\w+|upgrade|bump|cve)\b", "deps-upgrade"),
    (r"\b(fail\w*|error|bug|broken|regression)\b", "debug"),
]

def classify(text: str) -> dict:
    t = (text or "").lower()
    signals = []
    tier = "M"
    if re.search(r"\b(every|all files|across the (repo|codebase)|repo-wide|audit|migrat\w+ all|whole)\b", t):
        tier, _ = "XL", signals.append("repo-wide scope")
    if re.search(r"\b(oauth|auth|authn|authz|payment|stripe|billing|pii|schema|migration|infra|deploy|security)\b", t):
        tier = max(tier, "L", key=lambda x: ["S", "M", "L", "XL"].index(x))
        signals.append("high-risk domain")
    if re.search(r"\b(feature|flow|system|integration|refactor|across|throughout|module|package)\b", t):
        tier = max(tier, "M", key=lambda x: ["S", "M", "L", "XL"].index(x))
        signals.append("multi-file feature")
    # Single-file fix: short, no cross-file signal, no risky domain.
    if (tier == "M" and len(t.split()) <= 10
            and re.search(r"\b(fix|rename|typo|bump|tweak|remove)\b", t)
            and not re.search(r"\b(across|throughout|module|package|directory|folder|every|all)\b", t)):
        tier, _ = "S", signals.append("single-file fix")
    skills = sorted({s for pat, s in SKILL_HINTS if re.search(pat, t)})
    return {"tier": tier, "signals": signals, "skills": skills,
            "escalate": tier in ("L", "XL")}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("intent", nargs="*", help="the task text")
    ap.add_argument("--task", default="")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    text = " ".join(a.intent)
    if a.task:
        task = read_json(os.path.join(TASKS, f"{a.task}.json"), {})
        text = text or task.get("goal") or task.get("title") or ""
    if not text:
        print(json.dumps({"error": "no intent provided"}))
        return 2

    res = classify(text)
    res.update(PROFILES[res["tier"]])
    res["intent"] = text[:200]
    res["task"] = a.task or None
    print(json.dumps(res, indent=2) if a.json else
          f"tier={res['tier']} model={res['model']} effort={res['effort']} "
          f"parallelism={res['parallelism']} skills={','.join(res['skills']) or '-'} "
          f"escalate={res['escalate']}")
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
