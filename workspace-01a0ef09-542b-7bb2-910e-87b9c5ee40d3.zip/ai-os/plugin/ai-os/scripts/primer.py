#!/usr/bin/env python3
"""Assemble the minimal re-entry context after compaction or a cold start.

  primer.py --build          # -> state/primer.md (≤ 60 lines)
  primer.py --print          # emit it (PostCompact hook uses this)

Contains only: identity, current task, gates, open approvals, index pointers.
"""
from __future__ import annotations
import argparse, json, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib"))
from common import ROOT, STATE, TASKS, APPROVALS, INDEX, read_json  # noqa: E402

MAX_LINES = 60

def build() -> str:
    L = ["# AI OS primer (generated)", "",
         "You are operating AI OS. State on disk beats state in chat. Evidence beats assertion.",
         f"generated: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}", ""]

    tasks = []
    if os.path.isdir(TASKS):
        for fn in sorted(os.listdir(TASKS)):
            if fn.endswith(".json"):
                t = read_json(os.path.join(TASKS, fn), {})
                tasks.append((fn[:-5], t))
    open_tasks = [(i, t) for i, t in tasks if t.get("status") not in ("MERGED", "DONE")]
    if open_tasks:
        L += ["## Open tasks"]
        for i, t in open_tasks[:8]:
            L.append(f"- {i}: {t.get('goal') or t.get('title') or '?'} "
                     f"[tier {t.get('tier','?')}, status {t.get('status','?')}] "
                     f"gates: {','.join(t.get('dod_gates') or t.get('gates') or []) or '-'}")
        L.append("")

    appr = read_json(APPROVALS, [])
    if appr:
        L += ["## Waiting on a human"]
        for a in appr[:5]:
            L.append(f"- {a.get('id','?')}: {str(a.get('question',''))[:120]}")
        L.append("")

    L += ["## Pointers (read on demand, never preload)",
          "- repo map: state/index/repo.md",
          "- skills:   state/index/skills.md",
          "- tools:    state/index/tools.md",
          "- history:  state/ledger.jsonl",
          "- notes:    state/notes/<topic>.md",
          "- gates:    bin/aios verify <task-id>",
          "",
          "## Non-negotiables",
          "- no raw output > 200 lines · agent returns are JSON ≤ 2000 tokens",
          "- no protected-path edits without approval · no force push · no destructive SQL",
          "- ledger before recompute: scripts/ledger.py query --similar \"<task>\"",
          ""]
    return "\n".join(L[:MAX_LINES]) + "\n"

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--build", action="store_true")
    ap.add_argument("--print", action="store_true")
    a = ap.parse_args()
    text = build()
    if a.build or not a.print:
        os.makedirs(STATE, exist_ok=True)
        with open(os.path.join(STATE, "primer.md"), "w") as f:
            f.write(text)
        print(f"wrote state/primer.md ({len(text.splitlines())} lines)")
    if a.print:
        sys.stdout.write(text)
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
