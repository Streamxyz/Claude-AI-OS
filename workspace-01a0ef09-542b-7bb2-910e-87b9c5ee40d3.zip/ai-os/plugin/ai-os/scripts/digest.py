#!/usr/bin/env python3
"""Daily human digest: shipped, blocked, spend, proposals. Two minutes to read."""
from __future__ import annotations
import argparse, json, os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib"))
from common import ROOT, TASKS, APPROVALS, read_json  # noqa: E402

def build() -> str:
    today = time.strftime("%Y-%m-%d", time.gmtime())
    L = [f"# AI OS digest — {today}", "", "## Waiting on you"]
    appr = read_json(APPROVALS, [])
    if appr:
        for a in appr:
            L.append(f"- **{a.get('id')}** ({a.get('reason')}): {a.get('question')}")
            L.append(f"  options: {', '.join(a.get('options', []))} · recommended: {a.get('recommended')}")
    else:
        L.append("- nothing")
    L += ["", "## Tasks"]
    if os.path.isdir(TASKS):
        for fn in sorted(os.listdir(TASKS)):
            if fn.endswith(".json"):
                t = read_json(os.path.join(TASKS, fn), {})
                L.append(f"- {fn[:-5]} [{t.get('status','?')}] {t.get('goal') or t.get('title') or ''}")
    L += ["", "## Spend", "```", "bin/aios cost --since 1d", "```"]
    return "\n".join(L) + "\n"

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "state", "digest"))
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    text = build()
    p = os.path.join(a.out, time.strftime("%Y-%m-%d", time.gmtime()) + ".md")
    with open(p, "w") as f:
        f.write(text)
    print(text)
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
