#!/usr/bin/env python3
"""Turn repeated evidence into rules, skills, or scripts.

  promote.py --scan                 # candidates with evidence counts (no writes)
  promote.py --apply <candidate>    # write the proposal

Rule of three: nothing is promoted on fewer than 3 observations (or one security incident).
"""
from __future__ import annotations
import argparse, json, os, sys
from collections import Counter
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib"))
from common import ROOT, LEDGER, APPROVALS, read_json  # noqa: E402

THRESHOLD = 3

def scan() -> list[dict]:
    if not os.path.exists(LEDGER):
        return []
    gate_fail: Counter = Counter()
    corrections: Counter = Counter()
    oversize: Counter = Counter()
    with open(LEDGER) as f:
        for line in f:
            try:
                r = json.loads(line)
            except Exception:
                continue
            if r.get("pass") is False and r.get("gate"):
                gate_fail[(r.get("gate"), r.get("task"))] += 1
            if r.get("event") == "correction":
                corrections[str(r.get("note"))[:120]] += 1
            if r.get("event") == "contract_breach" or r.get("reason") == "no_json_object":
                oversize[str(r.get("agent"))] += 1

    cands = []
    for (gate, task), n in gate_fail.items():
        if n >= THRESHOLD:
            cands.append({"kind": "script", "target": f"scripts/gates/{gate}.sh",
                          "evidence": n, "why": f"gate '{gate}' failed {n}x on {task} — flaky or misconfigured",
                          "action": "quarantine + ticket, never retry blindly"})
    for note, n in corrections.items():
        if n >= THRESHOLD:
            cands.append({"kind": "rule", "target": ".claude/rules/",
                          "evidence": n, "why": f"correction repeated {n}x: {note}",
                          "action": "encode as a path-scoped rule, prefer a script over prose"})
    for agent, n in oversize.items():
        if n >= THRESHOLD:
            cands.append({"kind": "skill", "target": f".claude/agents/{agent}.md",
                          "evidence": n, "why": f"'{agent}' breached its output contract {n}x",
                          "action": "tighten the contract or split the agent"})
    return sorted(cands, key=lambda c: -c["evidence"])

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scan", action="store_true")
    ap.add_argument("--apply", default="")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    cands = scan()
    if a.json:
        print(json.dumps(cands, indent=2))
    else:
        if not cands:
            print(f"no candidates at threshold {THRESHOLD} — nothing to promote")
            return 0
        for c in cands:
            print(f"[{c['evidence']}x] {c['kind']:<7} {c['target']}\n       {c['why']}\n       -> {c['action']}\n")
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
