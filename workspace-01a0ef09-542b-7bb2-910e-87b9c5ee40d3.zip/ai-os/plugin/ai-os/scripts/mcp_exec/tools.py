#!/usr/bin/env python3
"""Tool search over the MCP registry — find a tool WITHOUT loading its schema.

Implements the discovery half of Anthropic's "code execution with MCP" pattern:
expose a large API as code on a filesystem behind two generic tools (search, exec)
instead of one context entry per endpoint.

  tools.py search "github create issue"
  tools.py list --server github
  tools.py refresh          # rebuild os/registry/tools.json from .mcp.json

Cost: ~200 tokens for a search round trip instead of 15k-140k for full schemas.
"""
from __future__ import annotations
import argparse, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import ROOT  # noqa: E402

REGISTRY = os.path.join(ROOT, "os", "registry", "tools.json")
MCP = os.path.join(ROOT, ".mcp.json")

def load() -> dict:
    return json.load(open(REGISTRY)) if os.path.exists(REGISTRY) else {"servers": {}, "tools": []}

def refresh() -> dict:
    servers = {}
    if os.path.exists(MCP):
        try:
            servers = json.load(open(MCP)).get("mcpServers", {})
        except Exception:
            servers = {}
    reg = {"servers": {}, "tools": []}
    for name, cfg in servers.items():
        declared = cfg.get("_tools", [])  # optional: hand-declared tool summaries
        reg["servers"][name] = {
            "transport": cfg.get("type", cfg.get("transport", "stdio")),
            "alwaysLoad": bool(cfg.get("alwaysLoad", False)),
            "tool_count": len(declared),
        }
        for t in declared:
            reg["tools"].append({"server": name, **t})
    os.makedirs(os.path.dirname(REGISTRY), exist_ok=True)
    json.dump(reg, open(REGISTRY, "w"), indent=2)
    return reg

def score(tool: dict, terms: list[str]) -> int:
    blob = json.dumps(tool).lower()
    return sum(1 for t in terms if t in blob)

def search(query: str, limit: int = 5) -> list[dict]:
    reg = load()
    terms = [t.lower() for t in re.split(r"\W+", query) if len(t) > 2]
    hits = reg.get("tools", [])
    ranked = sorted(((score(t, terms), t) for t in hits), key=lambda x: -x[0])
    out = []
    for s, t in ranked[:limit]:
        if s == 0:
            continue
        out.append({
            "server": t.get("server"),
            "name": t.get("name"),
            "signature": t.get("signature", "?"),
            "summary": (t.get("summary", "") or "")[:120],
            "load_with": f"scripts/mcp_exec/exec.py --use {t.get('server')}.{t.get('name')}",
        })
    return out

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["search", "list", "refresh"])
    ap.add_argument("query", nargs="*", default=[])
    ap.add_argument("--server", default="")
    ap.add_argument("--limit", type=int, default=5)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    if a.action == "refresh":
        reg = refresh()
        print(json.dumps({"servers": len(reg["servers"]), "tools": len(reg["tools"])}, indent=2))
        return 0
    if a.action == "list":
        reg = load()
        items = [t for t in reg.get("tools", []) if not a.server or t.get("server") == a.server]
        print(json.dumps(items, indent=2) if a.json else
              "\n".join(f"{t['server']}.{t['name']} — {t.get('summary','')}" for t in items))
        return 0

    hits = search(" ".join(a.query), a.limit)
    if a.json:
        print(json.dumps(hits, indent=2))
    else:
        if not hits:
            print("no tools matched. Refresh the registry: scripts/mcp_exec/tools.py refresh")
            return 1
        for h in hits:
            print(f"{h['server']}.{h['name']}{h['signature']}\n    {h['summary']}\n    {h['load_with']}")
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
