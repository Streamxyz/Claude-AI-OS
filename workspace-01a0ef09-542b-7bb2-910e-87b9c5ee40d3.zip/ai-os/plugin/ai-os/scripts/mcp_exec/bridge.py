#!/usr/bin/env python3
"""Expose configured MCP servers to sandbox code as importable modules.

Sandbox programs do:
    from mcp_github import create_issue
    result = create_issue(owner="acme", repo="app", title="…")

The bridge resolves `mcp_<server>` against .mcp.json and forwards calls over the
configured transport, so the model never loads a single tool schema into context.

This file is the seam: implement `_call()` against your MCP client of choice
(official SDK, or the same client Claude Code uses). Keep it stdio-only.
"""
from __future__ import annotations
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common import ROOT  # noqa: E402

def servers() -> dict:
    try:
        with open(os.path.join(ROOT, ".mcp.json")) as f:
            return json.load(f).get("mcpServers", {})
    except Exception:
        return {}

def _call(server: str, tool: str, args: dict):
    """Perform one MCP tool call. Replace with your client transport."""
    raise NotImplementedError(
        f"wire {server}.{tool} to your MCP client (see docs/mcp-exec.md). "
        "Until then, bulk operations should use a dedicated script in scripts/.")

class _ServerProxy:
    def __init__(self, name: str):
        self._name = name
    def __getattr__(self, tool: str):
        def fn(**kwargs):
            return _call(self._name, tool, kwargs)
        return fn

class _Finder:
    def find_module(self, fullname, path=None):  # legacy API
        return None
    def find_spec(self, fullname, path=None, target=None):
        if fullname.startswith("mcp_"):
            import importlib.util
            server = fullname[4:]
            if server in servers():
                spec = importlib.util.spec_from_loader(fullname, loader=None)
                return spec
        return None

def install() -> None:
    sys.meta_path.append(_Finder())
    for name in servers():
        sys.modules[f"mcp_{name}"] = _ServerProxy(name)

if __name__ == "__main__":
    print(json.dumps(list(servers()), indent=2))
