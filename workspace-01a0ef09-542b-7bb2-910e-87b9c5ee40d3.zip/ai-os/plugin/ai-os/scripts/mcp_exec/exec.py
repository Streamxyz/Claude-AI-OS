#!/usr/bin/env python3
"""Execute code against MCP servers so intermediate results never enter context.

This is the execution half of the pattern. Instead of N tool schemas in the prompt,
the model writes a short program; only what the program *returns* is printed.

  exec.py script.py                 # run; print only the value of `result`
  exec.py - <<'PY' ... PY           # run a program from stdin
  exec.py script.py --raw           # print full stdout (use only for small output)

Contract for the script: assign the value you want back to a module-level `result`
(or call `aios_return(value)`). Everything else stays in the sandbox.
"""
from __future__ import annotations
import argparse, io, json, os, subprocess, sys, tempfile, textwrap
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

MAX_RETURN_CHARS = int(os.environ.get("AIOS_EXEC_RETURN_CHARS", "4000"))

PRELUDE = textwrap.dedent('''
    # --- AI OS sandbox prelude -------------------------------------------------
    import json as _json, os as _os
    _RETURNED = {"value": None}
    def aios_return(value):
        """Send exactly this back to the model. Everything else stays here."""
        _RETURNED["value"] = value
    def aios_log(*a):
        import sys as _s; print(*a, file=_s.stderr)
    # MCP servers are importable as modules:  from mcp_<server> import <tool>
    # (wired by scripts/mcp_exec/bridge.py; see docs/mcp-exec.md)
    # ---------------------------------------------------------------------------
''')

EPILOGUE = textwrap.dedent('''

    # --- AI OS sandbox epilogue ------------------------------------------------
    import json as _json
    _v = globals().get("result", _RETURNED["value"])
    try:
        _out = _json.dumps(_v, default=str)
    except Exception:
        _out = repr(_v)
    print("__AIOS_RETURN__" + _out)
''')

def run_code(code: str, timeout: int, raw: bool) -> tuple[int, str, str]:
    src = PRELUDE + "\n" + code + "\n" + EPILOGUE
    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as f:
        f.write(src)
        path = f.name
    try:
        p = subprocess.run([sys.executable, path], capture_output=True, text=True, timeout=timeout,
                           cwd=os.environ.get("CLAUDE_PROJECT_DIR") or os.getcwd())
    except subprocess.TimeoutExpired:
        return 124, "", f"exec timed out after {timeout}s"
    finally:
        os.unlink(path)

    stdout = p.stdout or ""
    marker = "__AIOS_RETURN__"
    if not raw and marker in stdout:
        payload = stdout.split(marker, 1)[1]
        return p.returncode, payload[:MAX_RETURN_CHARS], p.stderr or ""
    return p.returncode, stdout[:MAX_RETURN_CHARS], p.stderr or ""

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("script", nargs="?", default="")
    ap.add_argument("--timeout", type=int, default=120)
    ap.add_argument("--raw", action="store_true")
    a = ap.parse_args()

    if a.script and os.path.exists(a.script):
        code = open(a.script).read()
    elif a.script == "-":
        code = sys.stdin.read()
    else:
        print("usage: exec.py <script.py|-> [--raw] [--timeout N]", file=sys.stderr)
        return 2

    rc, out, err = run_code(code, a.timeout, a.raw)
    if out:
        print(out)
    if err and rc != 0:
        print(err[-2000:], file=sys.stderr)
    return rc
if __name__ == "__main__":
    raise SystemExit(main())
