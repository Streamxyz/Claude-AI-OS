#!/usr/bin/env python3
"""Thin entry point — delegates to scripts/lib/contract.py.

Kept at scripts/ so skills, agents, and docs can reference one stable path.
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib"))
from contract import main  # noqa: E402
if __name__ == "__main__":
    raise SystemExit(main())
