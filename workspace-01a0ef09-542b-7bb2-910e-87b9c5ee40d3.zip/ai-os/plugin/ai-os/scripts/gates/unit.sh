#!/usr/bin/env bash
set -uo pipefail
cd "${CLAUDE_PROJECT_DIR:-$(pwd)}"
ran=0; rc=0
[ -f package.json ] && { npm test --silent || rc=1; ran=1; }
[ -f pyproject.toml ] && { python3 -m pytest -q 2>/dev/null || rc=1; ran=1; }
for d in products/*/; do
  [ -f "$d/package.json" ] && { (cd "$d" && npm test --silent) || rc=1; ran=1; }
  [ -f "$d/pyproject.toml" ] && { (cd "$d" && python3 -m pytest -q 2>/dev/null) || rc=1; ran=1; }
done
[ "$ran" -eq 0 ] && { echo "no test runner configured — skipping"; exit 0; }
exit $rc
