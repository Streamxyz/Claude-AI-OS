#!/usr/bin/env bash
set -uo pipefail
cd "${CLAUDE_PROJECT_DIR:-$(pwd)}"
ran=0; rc=0
[ -f package.json ] && grep -q '"build"' package.json && { npm run build || rc=1; ran=1; }
for d in products/*/; do
  [ -f "$d/package.json" ] && grep -q '"build"' "$d/package.json" && { (cd "$d" && npm run build) || rc=1; ran=1; }
done
[ "$ran" -eq 0 ] && { echo "no build script — skipping"; exit 0; }
exit $rc
