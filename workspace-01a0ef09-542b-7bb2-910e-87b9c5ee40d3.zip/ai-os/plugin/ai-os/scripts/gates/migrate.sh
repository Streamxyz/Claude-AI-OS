#!/usr/bin/env bash
# Migration gate. --dry-run is the default; --up/--down require an approval item.
set -uo pipefail
cd "${CLAUDE_PROJECT_DIR:-$(pwd)}"
MODE="${1:---dry-run}"
case "$MODE" in
  --dry-run) echo "dry-run: no migration executed by default"; 
             [ -f prisma/schema.prisma ] && { npx --no-install prisma validate && npx --no-install prisma migrate diff --from-schema-datasource prisma/schema.prisma --to-schema-datamodel prisma/schema.prisma --script >/dev/null && echo "schema valid"; } || true
             exit 0 ;;
  --up|--down) echo "AI OS: live migrations require an approval item (OPERATIONS.md §2)"; exit 1 ;;
  *) echo "usage: migrate.sh [--dry-run|--up|--down]"; exit 2 ;;
esac
