#!/usr/bin/env bash
# Type gate. Exits 0 when no project is detected yet (bootstrap-friendly).
set -uo pipefail
cd "${CLAUDE_PROJECT_DIR:-$(pwd)}"
ran=0; rc=0
for d in products/*/; do
  [ -f "$d/tsconfig.json" ] && { (cd "$d" && npx --no-install tsc --noEmit) || rc=1; ran=1; }
  [ -f "$d/pyproject.toml" ] && { (cd "$d" && python3 -m mypy . 2>/dev/null) || true; ran=1; }
done
[ -f tsconfig.json ] && { npx --no-install tsc --noEmit || rc=1; ran=1; }
[ -f pyproject.toml ] && { python3 -m mypy . 2>/dev/null || true; ran=1; }
[ "$ran" -eq 0 ] && { echo "no typed project detected — skipping"; exit 0; }
exit $rc
