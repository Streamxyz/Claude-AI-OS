#!/usr/bin/env bash
set -uo pipefail
cd "${CLAUDE_PROJECT_DIR:-$(pwd)}"
ran=0; rc=0
[ -f package.json ] && { npx --no-install eslint . || rc=1; ran=1; }
[ -f pyproject.toml ] && { (python3 -m ruff check . 2>/dev/null) || true; ran=1; }
for d in products/*/; do
  [ -f "$d/package.json" ] && { (cd "$d" && npx --no-install eslint .) || rc=1; ran=1; }
done
[ "$ran" -eq 0 ] && { echo "no linter configured — skipping"; exit 0; }
exit $rc
