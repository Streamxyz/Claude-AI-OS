#!/usr/bin/env bash
# Security gate: secret scan + dependency audit. Advisory tools are best-effort.
# Scans TRACKED files only (git ls-files) and excludes its own pattern list.
set -uo pipefail
cd "${CLAUDE_PROJECT_DIR:-$(pwd)}"
rc=0
echo "== secret scan =="
if command -v gitleaks >/dev/null 2>&1; then
  gitleaks detect --no-git -v || rc=1
else
  PATTERN='(AKIA[0-9A-Z]{12,}|sk-ant-[A-Za-z0-9_-]{10,}|ghp_[A-Za-z0-9]{20,}|xox[baprs]-[A-Za-z0-9-]{10,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)'
  if [ -d .git ]; then mapfile -t FILES < <(git ls-files); else
    mapfile -t FILES < <(find . -type f -not -path './.git/*' -not -path './node_modules/*' -not -path './state/*') ; fi
  HITS=""
  for f in "${FILES[@]}"; do
    [ "$f" = "scripts/gates/sec.sh" ] && continue
    case "$f" in docs/*|.claude/hooks/*|evals/*) continue ;; esac
    [ -f "$f" ] || continue
    if grep -IqE "$PATTERN" "$f" 2>/dev/null; then HITS+="$f"$'\n'; fi
  done
  if [ -n "$HITS" ]; then
    echo "FAIL: possible secret material found in:"; printf '%s' "$HITS" | head -20; rc=1
  else echo "ok (${#FILES[@]} files scanned)"; fi
fi
echo "== dependency audit =="
[ -f package.json ] && { npm audit --omit=dev --silent || true; }
[ -f pyproject.toml ] && { python3 -m pip_audit -q 2>/dev/null || true; }
exit $rc
