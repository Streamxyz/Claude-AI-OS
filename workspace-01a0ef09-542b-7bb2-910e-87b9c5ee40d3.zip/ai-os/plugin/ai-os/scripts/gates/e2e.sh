#!/usr/bin/env bash
# Browser-level proof. Requires a running app: bin/aios run --serve first.
set -uo pipefail
cd "${CLAUDE_PROJECT_DIR:-$(pwd)}"
ran=0; rc=0
[ -f playwright.config.ts ] && { npx --no-install playwright test || rc=1; ran=1; }
for d in products/*/; do
  [ -f "$d/playwright.config.ts" ] && { (cd "$d" && npx --no-install playwright test) || rc=1; ran=1; }
done
[ "$ran" -eq 0 ] && { echo "no e2e configuration — skipping (see skills/e2e-test)"; exit 0; }
exit $rc
