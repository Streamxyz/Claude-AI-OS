#!/usr/bin/env python3
"""Cost and token telemetry with the Pareto question: what is the cheapest
configuration that still passes?

  cost_report.py --since 7d --by model,agent,tier
  cost_report.py --task T-142
  cost_report.py --since 1d --quiet
"""
from __future__ import annotations
import argparse, json, os, sys, time
from collections import defaultdict
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib"))
from common import LEDGER  # noqa: E402

def since_ts(s: str) -> str:
    if not s:
        return ""
    unit = s[-1]
    try:
        n = int(s[:-1])
    except ValueError:
        return ""
    delta = {"h": 3600, "d": 86400, "w": 604800}.get(unit, 86400) * n
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - delta))

def rows(since: str = "", task: str = ""):
    if not os.path.exists(LEDGER):
        return []
    floor = since_ts(since)
    out = []
    with open(LEDGER) as f:
        for line in f:
            try:
                r = json.loads(line)
            except Exception:
                continue
            if floor and str(r.get("ts", "")) < floor:
                continue
            if task and r.get("task") != task:
                continue
            out.append(r)
    return out

def group(rows_, keys: list[str]):
    acc: dict[tuple, dict] = defaultdict(lambda: {"n": 0, "in": 0, "out": 0, "cache": 0, "usd": 0.0})
    for r in rows_:
        k = tuple(str(r.get(x, "?")) for x in keys)
        a = acc[k]
        a["n"] += 1
        a["in"] += int(r.get("tokens_in") or 0)
        a["out"] += int(r.get("tokens_out") or 0)
        a["cache"] += int(r.get("cache_read") or 0)
        a["usd"] += float(r.get("cost_usd") or 0)
    return [dict(zip(keys, k), **v) for k, v in sorted(acc.items(), key=lambda x: -x[1]["usd"])]

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--since", default="7d")
    ap.add_argument("--by", default="model")
    ap.add_argument("--task", default="")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    rs = rows(a.since, a.task)
    total_in = sum(int(r.get("tokens_in") or 0) for r in rs)
    total_cache = sum(int(r.get("cache_read") or 0) for r in rs)
    total_usd = round(sum(float(r.get("cost_usd") or 0) for r in rs), 4)
    report = {"rows": len(rs), "tokens_in": total_in, "cache_read": total_cache,
              "cache_hit_pct": round(100 * total_cache / max(1, total_in), 1),
              "total_usd": total_usd,
              "by_" + a.by.replace(",", "_"): group(rs, a.by.split(","))}

    if a.json:
        print(json.dumps(report, indent=2)); return 0
    if a.quiet:
        return 0
    print(f"rows={report['rows']}  in={total_in:,}  cache_hit={report['cache_hit_pct']}%  ${total_usd:,.2f}")
    key = "by_" + a.by.replace(",", "_")
    for r in report[key][:15]:
        label = " | ".join(str(r.get(k, "?")) for k in a.by.split(","))
        print(f"  {label:<48} n={r['n']:<5} in={r['in']:>10,}  ${r['usd']:>8.3f}")
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
