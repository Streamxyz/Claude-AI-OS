#!/usr/bin/env python3
"""The gate runner — one command, one verdict, evidence on disk.

  gate.py list
  gate.py run unit --task T-142
  gate.py run typecheck,lint,unit,build --task T-142 --json
  gate.py run all --task T-142

A gate is a script in scripts/gates/ that exits 0/1 and writes stdout to
state/traces/<task>/<gate>.log. The conversation gets the verdict, never the log.
"""
from __future__ import annotations
import argparse, json, os, shlex, subprocess, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib"))
from common import HOME, ROOT, TRACES, TASKS, ensure_dirs, locate, read_json, now  # noqa: E402

GATES_DIR = locate("scripts/gates")  # install dir, unless the project overrides a gate
DEFAULT_GATES = ["typecheck", "lint", "unit", "build"]

def available() -> list[str]:
    if not os.path.isdir(GATES_DIR):
        return []
    return sorted(f.rsplit(".", 1)[0] for f in os.listdir(GATES_DIR)
                  if f.endswith((".sh", ".py")) and not f.startswith("_"))

def run_one(gate: str, task: str, timeout: int = 900) -> dict:
    ensure_dirs()
    trace_dir = os.path.join(TRACES, task or "adhoc")
    os.makedirs(trace_dir, exist_ok=True)
    log_path = os.path.join(trace_dir, f"{gate}.log")

    for ext in (".sh", ".py"):
        script = os.path.join(GATES_DIR, gate + ext)
        if os.path.exists(script):
            cmd = ["bash", script] if ext == ".sh" else [sys.executable, script]
            break
    else:
        return {"gate": gate, "pass": False, "error": "gate not found",
                "evidence": None, "duration_ms": 0}

    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
        out = (p.stdout or "") + (("\n[stderr]\n" + p.stderr) if p.stderr else "")
        ok = p.returncode == 0
    except subprocess.TimeoutExpired:
        out, ok = f"gate timed out after {timeout}s", False
    dur = int((time.time() - t0) * 1000)

    with open(log_path, "w") as f:
        f.write(out)

    return {"gate": gate, "pass": ok, "duration_ms": dur,
            "evidence": os.path.relpath(log_path, ROOT),
            "tail": "\n".join(out.splitlines()[-15:])}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["run", "list"])
    ap.add_argument("gates", nargs="?", default=",".join(DEFAULT_GATES))
    ap.add_argument("--task", default=os.environ.get("AIOS_TASK_ID", ""))
    ap.add_argument("--timeout", type=int, default=900)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    if a.action == "list":
        print(json.dumps(available()) if a.json else "\n".join(available()))
        return 0

    wanted = available() if a.gates in ("all", "") else [g.strip() for g in a.gates.split(",") if g.strip()]
    results = [run_one(g, a.task, a.timeout) for g in wanted]
    verdict = {"task": a.task, "ts": now(), "pass": all(r["pass"] for r in results),
               "gates": results}

    if a.task:
        tp = os.path.join(TASKS, f"{a.task}.json")
        task = read_json(tp, {})
        if task:
            task["gate_results"] = {r["gate"]: r for r in results}
            task["status"] = "GATE_PASS" if verdict["pass"] else "GATE_FAIL"
            with open(tp, "w") as f:
                json.dump(task, f, indent=2)

    if a.json:
        print(json.dumps(verdict, indent=2))
    elif not a.quiet:
        for r in results:
            print(f"{'PASS' if r['pass'] else 'FAIL'}  {r['gate']:<10} {r['duration_ms']:>6}ms  {r['evidence']}")
        print(f"\nverdict: {'PASS' if verdict['pass'] else 'FAIL'}")

    return 0 if verdict["pass"] else 1
if __name__ == "__main__":
    raise SystemExit(main())
