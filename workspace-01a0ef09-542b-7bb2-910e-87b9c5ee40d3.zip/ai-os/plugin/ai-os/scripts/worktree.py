#!/usr/bin/env python3
"""Task worktrees — one isolated checkout per worker so parallel agents never collide.

  worktree.py new T-142            # worktrees/T-142 on branch task/T-142
  worktree.py list
  worktree.py clean T-142          # only when the task is merged and gates are green
"""
from __future__ import annotations
import argparse, json, os, subprocess, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib"))
from common import ROOT, run  # noqa: E402

WT_DIR = os.path.join(ROOT, "worktrees")

def git(*args: str) -> tuple[int, str]:
    return run(["git", *args])

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["new", "list", "clean"])
    ap.add_argument("task", nargs="?")
    ap.add_argument("--base", default="main")
    a = ap.parse_args()

    if a.action == "list":
        rc, out = git("worktree", "list")
        print(out)
        return rc

    if not a.task:
        print("task id required", file=sys.stderr)
        return 2

    os.makedirs(WT_DIR, exist_ok=True)
    path = os.path.join(WT_DIR, a.task)
    branch = f"task/{a.task}"

    if a.action == "new":
        if os.path.exists(path):
            print(json.dumps({"worktree": path, "branch": branch, "status": "exists"}))
            return 0
        # fall back to HEAD when the requested base ref does not exist yet
        base = a.base
        rc0, _ = git("rev-parse", "--verify", base)
        if rc0 != 0:
            rc1, _ = git("rev-parse", "--verify", "HEAD")
            if rc1 != 0:
                print(json.dumps({"worktree": path, "branch": branch, "status": "failed",
                                  "output": "no valid base ref and no commits yet — create an initial commit first"}))
                return 1
            base = "HEAD"
        rc, out = git("worktree", "add", "-b", branch, path, base)
        print(json.dumps({"worktree": path, "branch": branch,
                          "status": "created" if rc == 0 else "failed", "output": out[-400:]}))
        return rc

    if a.action == "clean":
        rc, out = git("worktree", "remove", path, "--force")
        print(json.dumps({"worktree": path, "removed": rc == 0, "output": out[-300:]}))
        return rc
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
