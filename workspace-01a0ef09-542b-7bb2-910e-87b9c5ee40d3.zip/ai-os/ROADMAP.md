# Roadmap — maturity ladder

Ship levels in order. Each level is independently useful and pays for the next.

---

## L0 — Bootstrap *(day 1)*
**Goal:** a repo Claude Code can operate safely.
- [ ] `CLAUDE.md` ≤ 150 lines + `.claude/rules/` for the top 3 conventions
- [ ] `settings.json`: permissions, `permissions.deny` list, model, effort
- [ ] 4 hooks: `SessionStart` digest, `PreToolUse:Bash` guard, `PostToolUse:Bash` truncation, `Stop` gate
- [ ] `scripts/gates/{typecheck,lint,test,build}.sh` + `scripts/gate.py`
- [ ] `state/` skeleton + `state/ledger.jsonl`
- [ ] `bin/aios boot|doctor`

**Exit:** `bin/aios doctor` passes; a tier-S task runs end to end unattended.

## L1 — Capability *(week 1)*
**Goal:** stop re-explaining; start reusing.
- [ ] 6 system skills: `aios-orchestrate`, `aios-spec`, `aios-plan`, `aios-implement`, `aios-verify`, `aios-review`
- [ ] 4 typed agents: `explorer`, `planner`, `implementer`, `verifier`
- [ ] JSON contracts + `SubagentStop` enforcement
- [ ] `scripts/index.py` → `state/index/repo.md`; `FileChanged` reindex
- [ ] `scripts/router.py` tier classification
- [ ] compaction protocol (`PreCompact`/`PostCompact`) + `state/primer.md`

**Exit:** tier-M tasks unattended; context stays under 55%; agent returns ≤ 2k tokens.

## L2 — Parallelism *(weeks 2–3)*
**Goal:** many workers, no collisions.
- [ ] `isolation: worktree` on every mutating agent; `scripts/worktree.py`
- [ ] file-ownership maps in every plan
- [ ] agent teams for tier-L (`CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`)
- [ ] 2 saved dynamic workflows: `aios-audit`, `aios-release`
- [ ] `scripts/contract.py` hardening; `resolver` agent for gate failures
- [ ] engineering skills: `api-endpoint`, `db-migration`, `ui-component`, `e2e-test`

**Exit:** a tier-L feature ships with 4 parallel workers and zero merge conflicts.

## L3 — Token economy *(month 1)*
**Goal:** the context bill stops being the constraint.
- [ ] `.mcp.json` driver set, all deferred; `alwaysLoad` audit
- [ ] `scripts/mcp_exec/` (search + exec) for all bulk operations
- [ ] `scripts/budget.py` thresholds wired to `PostToolBatch`
- [ ] `scripts/cost_report.py` + Pareto analysis; routing table tuned on real data
- [ ] prompt-caching hygiene: frozen prefix, `experimental.cacheTtl` on long-lived agents
- [ ] LSP plugin for symbol navigation

**Exit:** ≥ 70% cache hit rate; measured ≥ 60% token reduction vs L1 baseline on the same task set.

## L4 — Autonomy *(month 2)*
**Goal:** the human writes intent and reads digests.
- [ ] nightly routines (audit, deps, docs, cost, learn)
- [ ] `aios-incident` API-triggered routine
- [ ] escalation queue + SLA notifications
- [ ] `/goal` conditions for long tasks; Stop-hook DoD enforcement everywhere
- [ ] artifact digest; Remote Control / mobile steering
- [ ] eval harness in `evals/` — regression suite for agent behaviour

**Exit:** 20 consecutive unattended tasks; human interventions ≤ 0.2/task.

## L5 — Self-improvement *(quarter)*
**Goal:** the OS gets better while you sleep.
- [ ] `aios-learn` promotions: corrections → `.claude/rules/` PRs automatically
- [ ] skill-rot detector + auto-rewrite proposals
- [ ] eval-driven prompt/skill A-B testing
- [ ] cost-optimizer auto-tunes the routing table within guardrails
- [ ] skill marketplace export: ship the OS as a versioned plugin

**Exit:** measurable month-over-month drop in cost/task and interventions/task without human editing of prompts.

---

## Build order cheat-sheet

```
L0 control → L1 reuse → L2 parallelism → L3 economy → L4 autonomy → L5 learning
     ↑                                                                    │
     └──────────────── every level adds rules, never prose ───────────────┘
```

**Do not** start with L5. Learning on top of an uncontrolled loop just learns bad habits faster.
