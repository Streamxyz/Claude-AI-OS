# Intent specs — the only thing a human writes

Write **intent**, not instructions. The OS figures out the how; you own the what and the why.

```markdown
# T-142 — <title>
## Goal          (one sentence: what is true after this ships)
## Non-goals     (≥2 — these stop scope creep)
## Acceptance criteria  (numbered, testable by a command or a test)
## Constraints   (perf, compat, security)
## Done means    (gate list)
## Open questions
```

Scaffold: `bin/aios spec T-142`. Validate: `bin/aios spec T-142` (checks goal + criteria exist).

Good: "p95 < 200ms at 100 rps", "returns 429 with Retry-After when over limit".
Bad: "works well", "feels fast", "handles errors gracefully".
