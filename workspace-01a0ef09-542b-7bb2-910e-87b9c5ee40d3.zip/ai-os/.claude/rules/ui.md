---
name: ui-conventions
description: Frontend conventions for generated products
paths:
  - "products/*/src/components/**"
  - "products/*/app/**/*.tsx"
  - "products/*/src/**/*.svelte"
  - "products/*/src/**/*.vue"
---

# UI conventions

- Components are pure by default; data fetching lives in a route-level loader or a hook.
- Design tokens only — no raw hex values, no magic spacing numbers.
- Every interactive component ships: a test, an a11y label, and a loading + error + empty state.
- No `any`. No inline styles except computed values.
- Visual changes are verified with `/verify` against the running app plus a screenshot comparison — tests alone are not evidence.

## Verify
bin/aios verify --gate e2e && bin/aios verify --gate lint --scope ui
