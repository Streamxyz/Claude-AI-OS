---
name: agent-authoring
description: Rules for writing and editing subagent definitions
paths:
  - ".claude/agents/**"
  - "os/registry/contracts/**"
---

# Agent authoring

- `description` is **one line**, ≤ 25 words, starts with a verb, and states *when to delegate*. It costs context every session.
- Every agent declares `model`, `effort`, `tools` (least privilege), and — when it mutates files — `isolation: worktree`.
- Every agent ends with an explicit **Output contract** section: a JSON shape + a hard token cap (default 2000).
- Agents that must remember across sessions set `memory: project`.
- Never give an agent both `Write` and a broad `Bash` allowlist unless it owns files.
- Contract schemas live in `os/registry/contracts/<agent>.json` and are enforced by `hooks/contract.py`.

## Verify
python3 bin/aios plan --check-schemas && bin/aios doctor --agents
