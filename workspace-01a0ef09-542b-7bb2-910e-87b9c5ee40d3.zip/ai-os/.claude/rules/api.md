---
name: api-conventions
description: HTTP API conventions for generated products
paths:
  - "products/*/src/api/**"
  - "products/*/app/api/**"
  - "products/*/server/**"
---

# API conventions

- Handlers are thin: validate → call a service → return. No business logic in the transport layer.
- Every route: typed request/response schema, explicit error codes, one integration test, one contract test.
- Response envelope: `{ "data": T | null, "error": { "code", "message" } | null }`. Never throw raw stack traces.
- Auth: middleware, never per-handler. Every new route declares its permission in one line at the top.
- Rate limits and idempotency keys on anything mutating.
- No new dependency without a note in `state/notes/dependencies.md`.

## Verify
bin/aios verify --gate unit --scope api
