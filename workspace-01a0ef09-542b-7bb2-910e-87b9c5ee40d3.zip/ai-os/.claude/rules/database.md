---
name: database-migrations
description: Schema change and migration safety
paths:
  - "**/migrations/**"
  - "**/schema.prisma"
  - "**/*.sql"
  - "**/alembic/**"
---

# Migrations

Protected area. Changes here escalate to `state/approvals/pending.json`.

- Every migration is **backward compatible** for one release: expand → migrate → contract.
- Never `DROP COLUMN`/`DROP TABLE` in the same PR that stops writing to it.
- Long operations are batched; no table-level exclusive locks on hot tables without a maintenance window.
- Every migration has a tested rollback command in its header comment.
- Large backfills run as background jobs, never inside a migration transaction.

## Verify
bin/aios verify --gate migrate,test
