---
name: state-discipline
description: Rules for reading and writing OS runtime state
paths:
  - "state/**"
  - "specs/**"
---

# State discipline

- `state/tasks/<id>.json` is the only record of a task. Never keep task state in a transcript.
- `state/ledger.jsonl` is **append-only**. Query with `bin/aios ledger query`, never rewrite.
- `state/notes/<topic>.md` are structured notes: `## Status`, `## Decisions`, `## Open`, `## Evidence paths`.
- `state/index/*.md` are compact maps. Regenerate with `bin/aios index`; never hand-edit.
- `state/primer.md` is the re-entry context after compaction. Keep it ≤ 60 lines.
- `state/approvals/pending.json` is the human queue: `id, reason, question, options[], recommended, evidence[], cost_so_far_usd`.

**Ledger-first rule:** before solving anything, `bin/aios ledger query --similar "<task>"`. Reuse before recompute.

## Verify
bin/aios ledger validate
