---
name: hook-authoring
description: Rules for hooks and settings.json policy
paths:
  - ".claude/hooks/**"
  - ".claude/settings.json"
  - ".claude/settings.local.json"
---

# Hooks & policy

- **If a rule matters, it is a hook.** CLAUDE.md is guidance; hooks are law and run inside subagents too.
- Every hook script: `set -euo pipefail`, exits fast (< 1s unless it is a gate), never writes to stdout unless the output is intentional context.
- `PreToolUse` denies with **exit code 2** and a short `reason` on stderr.
- Hooks must be idempotent and must never depend on the model's cooperation.
- Adding a `deny` permission or a guard requires a matching test in `evals/hooks/`.
- Never log secrets, env values, or full file contents into `state/ledger.jsonl`.

## Verify
bash -n .claude/hooks/*.sh && python3 -m py_compile .claude/hooks/*.py && bin/aios doctor --hooks
