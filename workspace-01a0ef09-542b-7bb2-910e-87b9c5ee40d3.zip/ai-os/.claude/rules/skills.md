---
name: skill-authoring
description: Rules for writing and editing skills
paths:
  - ".claude/skills/**"
---

# Skill authoring

Three-level progressive disclosure. Respect it or the OS pays for it on every turn.

- **L1 metadata** (`name` + `description`): always in context. Description starts with `Use when …` and names ≥ 1 negative case.
- **L2 `SKILL.md`**: ≤ 120 lines / one screen. Steps, boundaries, verify command.
- **L3 `references/`, `scripts/`, `templates/`**: read or executed by path only. Unbounded size, ~zero cost.

Rules:
1. Deterministic steps become scripts in the skill's `scripts/`, never prose instructions.
2. Skill ends with a `## Verify` section naming a command that exits 0/1.
3. No two skills share a trigger. Overlap is a routing bug — fix the descriptions.
4. Reference bundled files by explicit path (`references/foo.md`), never inline their content.
5. Use `${CLAUDE_SKILL_DIR}` for script paths so the skill works from any cwd.

## Verify
bin/aios doctor --skills
