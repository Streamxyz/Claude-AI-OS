---
name: infra-and-ci
description: Infrastructure, CI, and deployment safety
paths:
  - "infra/**"
  - ".github/**"
  - "**/Dockerfile*"
  - "**/docker-compose*"
  - "**/*.tf"
---

# Infra & CI

Protected area. Every change needs an approval item unless it is a CI-only, non-secret change.

- Infrastructure is declarative; no manual console changes. Drift is an incident.
- CI stages: `typecheck → lint → unit → build → e2e → security`. Later stages never run before earlier pass.
- Secrets are environment references only. Nothing secret is ever written to a file in this repo.
- Deploys are gated on a green pipeline and a recorded `bin/aios verify` run.
- Any change touching production data paths requires a rollback plan in the PR description.

## Verify
bin/aios verify --gate build,sec
