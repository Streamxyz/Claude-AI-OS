---
name: testing-standards
description: Test authoring and flake policy
paths:
  - "**/*.test.*"
  - "**/*.spec.*"
  - "**/tests/**"
- "scripts/gates/**"
---

# Testing

- Tests live next to source: `foo.ts` → `foo.test.ts`.
- Name tests by behaviour, not implementation: `it("rejects expired tokens")`.
- No `sleep()`. Deterministic clocks, seeded randomness, injected I/O.
- A flaky test is **quarantined and ticketed**, never retried blindly. Repeated flakes are a bug in the product or the test.
- Gate evidence goes to `state/traces/<task-id>/`; the chat gets the verdict line only.

## Verify
bin/aios verify --gate test
