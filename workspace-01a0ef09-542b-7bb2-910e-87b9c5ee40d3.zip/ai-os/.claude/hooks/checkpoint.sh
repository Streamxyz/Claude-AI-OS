#!/usr/bin/env bash
# PreCompact — persist structured notes and open tasks before the history is summarised.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0
python3 - "$AIOS_ROOT" <<'PY' 2>/dev/null || true
import json,os,sys,time
root=sys.argv[1]
notes=os.path.join(root,"state","notes")
os.makedirs(notes,exist_ok=True)
p=os.path.join(notes,"last-checkpoint.md")
tasks=sorted(os.listdir(os.path.join(root,"state","tasks")))[:20]
with open(p,"w") as f:
    f.write("# Last checkpoint\n\n")
    f.write(f"- ts: {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}\n")
    f.write(f"- open tasks: {', '.join(t.replace('.json','') for t in tasks) or 'none'}\n")
    f.write("- decisions and blockers: see state/notes/<topic>.md\n")
    f.write("- re-entry context: state/primer.md\n")
PY
exit 0
