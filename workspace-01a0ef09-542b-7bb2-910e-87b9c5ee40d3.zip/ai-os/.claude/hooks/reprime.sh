#!/usr/bin/env bash
# PostCompact — re-inject the primer so a compacted session loses nothing that mattered.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0
P="$AIOS_ROOT/state/primer.md"
[ -s "$P" ] || exit 0
BODY="$(head -60 "$P")"
[ -z "$BODY" ] && exit 0
python3 -c 'import json,sys;print(json.dumps({"hookSpecificOutput":{"additionalContext":sys.stdin.read()}}))' <<<"$BODY"
exit 0
