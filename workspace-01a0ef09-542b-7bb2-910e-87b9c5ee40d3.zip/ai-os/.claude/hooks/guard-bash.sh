#!/usr/bin/env bash
# PreToolUse:Bash — hard-deny destructive, secret-reading, and off-allowlist network commands.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0

CMD="$(python3 -c 'import json,sys
try:
    d=json.load(sys.stdin); print(d.get("tool_input",{}).get("command","") or "")
except Exception: print("")' 2>/dev/null)"
[ -z "$CMD" ] && exit 0

deny_match() { # pattern, reason
  if printf '%s' "$CMD" | grep -Eqi -- "$1"; then deny "$2"; fi
}

deny_match 'rm[[:space:]]+(-[a-z]*rf|-fr|-r[[:space:]]+-f)' 'AI OS: recursive force delete denied.'
deny_match 'rm[[:space:]]+-rf[[:space:]]+(/|\$|~|\.\.)' 'AI OS: deleting a root/home path is denied.'
deny_match 'git[[:space:]]+push[^|]*(--force|-f)([[:space:]]|$)' 'AI OS: force push denied. Use a branch + PR.'
deny_match 'git[[:space:]]+reset[[:space:]]+--hard' 'AI OS: hard reset denied (destructive).'
deny_match 'git[[:space:]]+clean[[:space:]]+-' 'AI OS: git clean denied (deletes untracked files).'
deny_match '(chmod[[:space:]]+777|:>|>\s*/dev/sd)' 'AI OS: unsafe permission/device write denied.'
deny_match '(curl|wget)[^|]*\|[[:space:]]*(sh|bash|zsh)' 'AI OS: piping remote content into a shell is denied.'
deny_match 'sudo[[:space:]]' 'AI OS: sudo denied.'
deny_match '(cat|head|tail|sed|awk|grep)[^|]*(\.env|id_rsa|\.pem|\.key|secrets/)' 'AI OS: reading secret material denied.'
deny_match '(kubectl|helm)[^|]*delete' 'AI OS: cluster delete denied — escalate instead.'
deny_match 'terraform[[:space:]]+destroy' 'AI OS: terraform destroy denied — escalate instead.'
deny_match '(DROP[[:space:]]+(TABLE|DATABASE)|TRUNCATE[[:space:]]+TABLE)' 'AI OS: destructive SQL denied.'
deny_match 'git[[:space:]]+commit[^|]*--no-verify' 'AI OS: bypassing hooks is denied.'
exit 0
