#!/usr/bin/env python3
"""UserPromptSubmit — classify the intent and inject the minimum re-entry context.

Emits JSON with hookSpecificOutput.additionalContext so the model gets a tier,
the task id, and the relevant index lines without reading anything else.
"""
import json, os, re, sys

ROOT = os.environ.get("CLAUDE_PROJECT_DIR") or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def read(path, limit=40):
    try:
        with open(path) as f:
            return [l.rstrip("\n") for l in f][:limit]
    except Exception:
        return []

def classify(prompt: str) -> str:
    """Same rules as scripts/router.py — keep the two in sync."""
    p = prompt.lower()
    tier = "M"
    if re.search(r"\b(every|all files|across the (repo|codebase)|repo-wide|audit|migrat\w+ all|whole)\b", p):
        tier = "XL"
    if re.search(r"\b(oauth|auth|authn|authz|payment|stripe|billing|pii|schema|migration|infra|deploy|security)\b", p):
        tier = max(tier, "L", key=lambda x: ["S", "M", "L", "XL"].index(x))
    if re.search(r"\b(feature|flow|system|integration|refactor|across|throughout|module|package)\b", p):
        tier = max(tier, "M", key=lambda x: ["S", "M", "L", "XL"].index(x))
    if (tier == "M" and len(p.split()) <= 10
            and re.search(r"\b(fix|rename|typo|bump|tweak|remove)\b", p)
            and not re.search(r"\b(across|throughout|module|package|directory|folder|every|all)\b", p)):
        tier = "S"
    return tier

try:
    payload = json.load(sys.stdin)
except Exception:
    payload = {}
prompt = (payload.get("prompt") or "").strip()
if not prompt:
    sys.exit(0)

tier = classify(prompt)
m = re.search(r"\bT-\d{1,5}\b", prompt)
task_id = m.group(0) if m else "T-new"

lines = [f"[aios] tier={tier} task={task_id}",
         "state: state/tasks/<id>.json · ledger: state/ledger.jsonl · index: state/index/repo.md"]
# Only preload the repo map when the prompt is actually about finding something in the code.
if re.search(r"\b(where|how|explore|find|repo|codebase|structure|which file)\b", prompt.lower()):
    idx = read(os.path.join(ROOT, "state/index/repo.md"), 12)
    if idx:
        lines.append("repo index (excerpt, 12 lines):")
        lines += ["  " + l for l in idx if l.strip()][:12]

print(json.dumps({"hookSpecificOutput": {"additionalContext": "\n".join(lines)}}))
