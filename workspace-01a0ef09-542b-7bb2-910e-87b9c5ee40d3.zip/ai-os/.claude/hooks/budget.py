#!/usr/bin/env python3
"""PostToolBatch — estimate context pressure and nudge compaction before quality drops.

Thresholds: warn at AIOS_BUDGET_WARN_PCT (default 60), force at AIOS_BUDGET_FORCE_PCT (80).
Never blocks; prints at most one short line.
"""
import json, os, sys

ROOT = os.environ.get("CLAUDE_PROJECT_DIR") or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
WARN = int(os.environ.get("AIOS_BUDGET_WARN_PCT", "60"))
FORCE = int(os.environ.get("AIOS_BUDGET_FORCE_PCT", "80"))

try:
    d = json.load(sys.stdin)
except Exception:
    sys.exit(0)

pct = None
for key in ("used_percentage", "context_used_percentage", "context_percentage"):
    if isinstance(d, dict) and key in d:
        pct = d[key]
        break
cw = d.get("context_window") if isinstance(d, dict) else None
if pct is None and isinstance(cw, dict):
    pct = cw.get("used_percentage")

if pct is None:
    sys.exit(0)

try:
    pct = float(pct)
except Exception:
    sys.exit(0)

if pct >= FORCE:
    print(json.dumps({"hookSpecificOutput": {"additionalContext":
        f"[aios] context {pct:.0f}% — run /aios-context now: checkpoint state, then /compact. Do not continue."}}))
elif pct >= WARN:
    print(json.dumps({"hookSpecificOutput": {"additionalContext":
        f"[aios] context {pct:.0f}% — checkpoint to state/notes and state/tasks, then continue or /aios-context."}}))
