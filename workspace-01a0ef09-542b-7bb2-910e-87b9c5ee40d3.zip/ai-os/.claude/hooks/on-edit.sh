#!/usr/bin/env bash
# PostToolUse:Write|Edit — format if a formatter exists, then ledger the edit.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0

P="$(python3 -c 'import json,sys
try:
    d=json.load(sys.stdin); ti=d.get("tool_input",{})
    print(ti.get("file_path") or ti.get("path") or ti.get("notebook_path") or "")
except Exception: print("")' 2>/dev/null)"
[ -z "$P" ] || [ ! -f "$P" ] && exit 0

case "$P" in
  *.ts|*.tsx|*.js|*.jsx|*.json|*.css|*.md) quiet command -v npx && quiet npx --no-install prettier --write "$P" ;;
  *.py)                                    quiet command -v ruff && quiet ruff format "$P" ;;
  *.go)                                    quiet command -v gofmt && quiet gofmt -w "$P" ;;
esac

python3 - "$AIOS_LEDGER" "$P" <<'PY' 2>/dev/null || true
import json,os,sys,time
ledger,path=sys.argv[1],sys.argv[2]
row={"ts":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"event":"edit","file":os.path.relpath(path,os.path.dirname(os.path.dirname(ledger)))}
try:
    with open(ledger,"a") as f: f.write(json.dumps(row)+"\n")
except Exception: pass
PY
exit 0
