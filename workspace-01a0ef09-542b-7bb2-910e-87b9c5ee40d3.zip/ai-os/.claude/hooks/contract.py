#!/usr/bin/env python3
"""SubagentStop — enforce the output contract on every agent return.

This is the single biggest context firewall in AI OS: specialists return a bounded,
validated JSON object instead of a narrative dump of their whole window.
"""
import json, os, re, sys

ROOT = os.environ.get("CLAUDE_PROJECT_DIR") or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CONTRACTS = os.path.join(ROOT, "os", "registry", "contracts")
MAX_TOKENS = int(os.environ.get("AIOS_MAX_AGENT_RETURN_TOKENS", "2000"))
STATE_FILE = os.path.join(ROOT, "state", ".contract_blocks")

def approx_tokens(text: str) -> int:
    return max(1, len(text) // 4)

try:
    d = json.load(sys.stdin)
except Exception:
    sys.exit(0)

agent = (d.get("agent_type") or d.get("agent") or "").strip()
out = d.get("result") or d.get("output") or d.get("message") or ""
if not isinstance(out, str):
    out = json.dumps(out)

# Extract the first JSON object in the return.
m = re.search(r"\{.*\}", out, re.S)
blob = m.group(0) if m else ""

if not blob:
    # Prose-only return: reject (non-blocking for the user, but logged + surfaced).
    try:
        with open(STATE_FILE, "a") as f:
            f.write(json.dumps({"ts": __import__("time").time(), "agent": agent, "reason": "no_json_object"}) + "\n")
    except Exception:
        pass
    print(json.dumps({"hookSpecificOutput": {"additionalContext":
        f"[aios] {agent or 'agent'} returned prose, not JSON. Re-answer using ONLY its output contract "
        f"(≤ {MAX_TOKENS} tokens, no prose, no markdown fences)."}}))
    sys.exit(0)

try:
    parsed = json.loads(blob)
except Exception as e:
    print(json.dumps({"hookSpecificOutput": {"additionalContext":
        f"[aios] {agent or 'agent'} returned malformed JSON ({e}). Re-answer with a single valid JSON object."}}))
    sys.exit(0)

n = approx_tokens(blob)
if n > MAX_TOKENS:
    print(json.dumps({"hookSpecificOutput": {"additionalContext":
        f"[aios] {agent or 'agent'} return ≈{n} tokens > {MAX_TOKENS}. Compress: drop narration, keep keys, "
        "truncate long strings to evidence paths."}}))

# Schema check when a contract exists for this agent.
schema_path = os.path.join(CONTRACTS, f"{agent}.json")
if os.path.exists(schema_path):
    try:
        with open(schema_path) as f:
            schema = json.load(f)
        for key in schema.get("required", []):
            if key not in parsed:
                print(json.dumps({"hookSpecificOutput": {"additionalContext":
                    f"[aios] {agent} return missing required key '{key}'. Re-answer with the full contract."}}))
                break
    except Exception:
        pass
sys.exit(0)
