#!/usr/bin/env bash
# FileChanged — rebuild compact indexes when the shape of the project changes.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0
[ -f "$AIOS_HOME/scripts/index.py" ] || exit 0
python3 "$AIOS_HOME/scripts/index.py" --all --quiet 2>/dev/null || true
exit 0
