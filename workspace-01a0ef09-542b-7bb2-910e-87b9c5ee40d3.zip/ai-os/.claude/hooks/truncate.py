#!/usr/bin/env python3
"""PostToolUse:Bash — cap how much command output can reach the model.

Keeps head + tail, records the full output to state/traces/, and prints a short
notice so the model can fetch more deliberately (in slices, not in bulk).
"""
import json, os, sys, time

ROOT = os.environ.get("CLAUDE_PROJECT_DIR") or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
MAX_LINES = int(os.environ.get("AIOS_BASH_OUTPUT_MAX_LINES", "200"))
MAX_BYTES = int(os.environ.get("AIOS_BASH_OUTPUT_MAX_BYTES", "8192"))

# Claude Code already caps inline output (bashOutputMaxChars). This hook ensures
# the *stored* form is bounded too and that long output is retrievable by path.
try:
    d = json.load(sys.stdin)
except Exception:
    sys.exit(0)

res = d.get("tool_result") or d.get("result") or {}
out = res.get("stdout") or res.get("output") or ""
if isinstance(out, list):
    out = "\n".join(out)

lines = out.splitlines()
if len(lines) <= MAX_LINES and len(out.encode("utf-8", "ignore")) <= MAX_BYTES:
    sys.exit(0)

os.makedirs(os.path.join(ROOT, "state", "traces"), exist_ok=True)
path = os.path.join(ROOT, "state", "traces", f"bash-{int(time.time())}.log")
try:
    with open(path, "w") as f:
        f.write(out)
except Exception:
    path = "(unwritable)"

trimmed = {
    "truncated": True,
    "shown_lines": MAX_LINES,
    "total_lines": len(lines),
    "full_output_path": path,
    "hint": "Read slices with offset/limit, or grep the file. Never cat a log into context.",
}
print(json.dumps(trimmed))
