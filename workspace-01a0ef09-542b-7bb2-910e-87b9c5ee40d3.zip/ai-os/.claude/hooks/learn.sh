#!/usr/bin/env bash
# SessionEnd — cost report + promotion proposals. Never blocks.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0
[ -x "$AIOS_BIN" ] && "$AIOS_BIN" learn --dry-run --quiet 2>/dev/null || true
[ -f "$AIOS_HOME/scripts/cost_report.py" ] && python3 "$AIOS_HOME/scripts/cost_report.py" --since 1d --quiet 2>/dev/null || true
exit 0
