#!/usr/bin/env bash
# SessionStart — ensure dirs, verify toolchain, print a compact boot digest.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0

mkdir -p "$AIOS_ROOT"/state/{tasks,notes,approvals,index,traces} "$AIOS_ROOT"/specs/intent 2>/dev/null

DIGEST="$(
  {
    echo "AI OS  $(date -u +%F)"
    # open tasks
    OT=$(ls "$AIOS_ROOT"/state/tasks/*.json 2>/dev/null | wc -l | tr -d ' ')
    echo "tasks: $OT open"
    # pending approvals
    PA=$(python3 - "$AIOS_ROOT/state/approvals/pending.json" <<'PY' 2>/dev/null
import json,sys
try:
    print(len(json.load(open(sys.argv[1]))))
except Exception:
    print(0)
PY
)
    echo "approvals: $PA pending"
    # spend today
    ST=$(python3 - "$AIOS_LEDGER" <<'PY' 2>/dev/null
import json,sys,datetime
total=0.0
try:
    today=datetime.date.today().isoformat()
    for line in open(sys.argv[1]):
        try:
            r=json.loads(line)
        except Exception:
            continue
        if str(r.get("ts","")).startswith(today):
            total+=float(r.get("cost_usd") or 0)
except Exception:
    pass
print(f"${total:,.2f}")
PY
)
    echo "spend today: \$$ST"
    # stale index warning
    if [ ! -s "$AIOS_ROOT/state/index/repo.md" ]; then
      echo "WARN: state/index/repo.md missing — run: python3 scripts/index.py --all"
    fi
  } 2>/dev/null
)"
[ -n "$DIGEST" ] && emit_context "$DIGEST"
exit 0
