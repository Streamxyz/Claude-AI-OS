#!/usr/bin/env bash
# Stop — the Definition-of-Done gate. Blocks the turn from ending while a gate is red.
# Capped by AIOS_GATE_MAX_BLOCKS so a stuck task escalates instead of looping forever.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0

TID="${AIOS_TASK_ID:-}"
[ -z "$TID" ] && TID="$(ls -t "$AIOS_ROOT"/state/tasks/*.json 2>/dev/null | head -1 | xargs -r basename | sed 's/\.json//')"
[ -z "$TID" ] && exit 0
[ -x "$AIOS_HOME/bin/aios" ] || exit 0

VERDICT="$("$AIOS_BIN" verify "$TID" --quiet 2>/dev/null)"
case "$VERDICT" in
  *'"pass":true'*|*'"pass": true'*) exit 0 ;;
esac

COUNT_FILE="/tmp/aios_stop_blocks_${TID}"
N=$(cat "$COUNT_FILE" 2>/dev/null || echo 0); N=$((N+1))
echo "$N" > "$COUNT_FILE"
MAX="${AIOS_GATE_MAX_BLOCKS:-3}"
if [ "$N" -ge "$MAX" ]; then
  rm -f "$COUNT_FILE"
  python3 - "$AIOS_ROOT" "$TID" "$VERDICT" <<'PY' 2>/dev/null || true
import json,os,sys,time
root,tid,verdict=sys.argv[1],sys.argv[2],sys.argv[3]
p=os.path.join(root,"state","approvals","pending.json")
os.makedirs(os.path.dirname(p),exist_ok=True)
try: items=json.load(open(p))
except Exception: items=[]
items.append({"id":tid,"reason":"gate_failure_3x","question":f"Gates still red after {3} blocks.",
  "options":["investigate-more","change-approach","abandon"],"evidence":[f"state/traces/{tid}/"],
  "recommended":"investigate-more","blocked_since":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()) })
json.dump(items,open(p,"w"),indent=2)
PY
  exit 0   # stop blocking; the human queue now owns it
fi

printf '{"decision":"block","reason":"AI OS: DoD gates not green for %s. Run: bin/aios verify %s — then re-answer. (block %s/%s)"}\n' \
  "$TID" "$TID" "$N" "$MAX"
exit 2
