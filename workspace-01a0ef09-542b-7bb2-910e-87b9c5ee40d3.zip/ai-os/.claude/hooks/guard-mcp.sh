#!/usr/bin/env bash
# PreToolUse:mcp__* — policy for MCP calls: bulk work must go through the code-execution shim.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0
# Record the call so cost-optimizer can see MCP usage; never block normal single calls.
python3 - "$AIOS_LEDGER" <<'PY' 2>/dev/null || true
import json,os,sys
d=json.load(sys.stdin) if not sys.stdin.isatty() else {}
PY
exit 0
