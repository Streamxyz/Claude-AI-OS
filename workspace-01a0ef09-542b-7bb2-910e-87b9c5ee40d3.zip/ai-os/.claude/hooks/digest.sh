#!/usr/bin/env bash
# Notification — append notifications to the daily digest instead of losing them.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0
python3 - "$AIOS_ROOT" <<'PY' 2>/dev/null || true
import json,os,sys,time
root=sys.argv[1]
d=sys.stdin.read()
p=os.path.join(root,"state","digest",time.strftime("%Y-%m-%d",time.gmtime())+".md")
os.makedirs(os.path.dirname(p),exist_ok=True)
with open(p,"a") as f:
    f.write(f"- {time.strftime('%H:%M:%S',time.gmtime())} {d[:400]}\n")
PY
exit 0
