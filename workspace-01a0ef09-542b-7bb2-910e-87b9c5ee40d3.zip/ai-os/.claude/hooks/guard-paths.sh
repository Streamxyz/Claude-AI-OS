#!/usr/bin/env bash
# PreToolUse:Write|Edit — protect secrets, migrations, infra, and CI from unapproved edits.
source "$(dirname "$0")/_common.sh" 2>/dev/null || exit 0

P="$(python3 -c 'import json,sys
try:
    d=json.load(sys.stdin); ti=d.get("tool_input",{})
    print(ti.get("file_path") or ti.get("path") or ti.get("notebook_path") or "")
except Exception: print("")' 2>/dev/null)"
[ -z "$P" ] && exit 0

case "$P" in
  */.env|*/.env.*|*/secrets/*|*.pem|*.key|*/id_rsa*) deny "AI OS: writes to secret material are denied." ;;
  */migrations/*|*schema.prisma|*/alembic/*)         deny "AI OS: schema/migration edits require an approval item (see OPERATIONS.md §2)." ;;
  */infra/*|*.tf|*terraform*|*/Dockerfile*|*/k8s/*)  deny "AI OS: infrastructure edits require an approval item." ;;
  */.github/workflows/*)                             deny "AI OS: CI workflow edits require an approval item." ;;
esac
exit 0
