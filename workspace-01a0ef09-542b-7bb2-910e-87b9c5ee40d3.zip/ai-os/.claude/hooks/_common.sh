# Shared helpers for AI OS hooks. Sourced, never executed directly.
# Contract: a hook must be fast, idempotent, and must never break the session.
set -uo pipefail

AIOS_ROOT="${CLAUDE_PROJECT_DIR:-$(pwd)}"           # the project being operated on
export AIOS_ROOT
# Where AI OS itself is installed (plugin dir or repo checkout). Never write state here.
AIOS_HOME="${CLAUDE_PLUGIN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[1]:-$0}")/.." && pwd)}"
export AIOS_HOME
AIOS_LEDGER="${AIOS_ROOT}/state/ledger.jsonl"
AIOS_TRACE_DIR="${AIOS_ROOT}/state/traces"
AIOS_BIN="${AIOS_HOME}/bin/aios"

# best-effort: run a command, never let a failure escape
quiet() { "$@" >/dev/null 2>&1 || true; }

# emit additional context for UserPromptSubmit / SessionStart style hooks
emit_context() {
  printf '{"hookSpecificOutput":{"additionalContext":%s}}\n' "$(python3 -c 'import json,sys;print(json.dumps(sys.stdin.read()))' 2>/dev/null <<<"$1" || echo '""')"
}

# deny a PreToolUse call
deny() {
  printf '{"decision":"block","reason":%s}\n' \
    "$(printf '%s' "$1" | python3 -c 'import json,sys;print(json.dumps(sys.stdin.read()))' 2>/dev/null || echo '"blocked by AI OS policy"')" 
  exit 2
}

now_iso() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }
