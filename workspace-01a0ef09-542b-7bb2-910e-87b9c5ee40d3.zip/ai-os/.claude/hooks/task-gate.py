#!/usr/bin/env python3
"""TaskCompleted — refuse to mark a task done unless its gates passed.

Exit 2 blocks the completion; the model must run the gates (or fix them) first.
"""
import json, os, sys

ROOT = os.environ.get("CLAUDE_PROJECT_DIR") or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TASKS = os.path.join(ROOT, "state", "tasks")

try:
    d = json.load(sys.stdin)
except Exception:
    sys.exit(0)

subject = str(d.get("subject") or d.get("task") or d.get("description") or "")
tid = None
for tok in subject.replace("/", " ").replace(":", " ").split():
    if tok.startswith("T-") and tok[2:].isdigit():
        tid = tok
        break

if not tid:
    sys.exit(0)

path = os.path.join(TASKS, f"{tid}.json")
if not os.path.exists(path):
    sys.exit(0)

try:
    with open(path) as f:
        task = json.load(f)
except Exception:
    sys.exit(0)

gates = task.get("gates") or []
results = task.get("gate_results") or {}
missing = [g for g in gates if not results.get(g, {}).get("pass")]
if missing:
    print(json.dumps({"decision": "block", "reason":
        f"AI OS: task {tid} cannot be completed — gates not green: {', '.join(missing)}. "
        f"Run: bin/aios verify {tid}"}))
    sys.exit(2)
sys.exit(0)
