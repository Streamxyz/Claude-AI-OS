# Saved dynamic workflows

A workflow is a **JavaScript script** that fans out many subagents; the runtime executes it in the
background while the session stays responsive. The plan lives in the script, so intermediates live
in script variables instead of a context window. Requires Claude Code ≥ 2.1.154 (`enableWorkflows: true`).

Manage with `/workflows` — `p` pause · `x` stop · `r` restart · `s` save the run's script as a command.

| Workflow | Phases | Use |
|---|---|---|
| `aios-audit` | fan-out → verify (adversarial cross-check) → synthesize | repo-wide audit: security, deps, dead code, docs drift |
| `aios-release` | preflight → changelog → tag → smoke | release cut |
| `aios-migration` | inventories → batches → verify per batch → report | mechanical repo-wide changes |

## Authoring rules
- Every phase must be independently verifiable; the verify phase must use **different** agents than
  the producing phase.
- Unverifiable findings are reported as `unknown`, never dropped and never marked safe.
- Cap total agents and per-agent turns; a runaway workflow is a budget incident.
- Output is a report + draft PRs. Workflows never push to `main`.
