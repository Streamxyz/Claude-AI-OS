#!/usr/bin/env bash
# Boot check — the skill never reimplements the doctor.
set -uo pipefail
exec "${CLAUDE_PROJECT_DIR:-$(cd "$(dirname "$0")/../../.." && pwd)}/bin/aios" doctor --all
