---
name: aios-boot
description: Validate and initialize the AI OS installation — layout, toolchain, hooks, permissions, budgets, indexes. Use when a repo was just cloned, after editing .claude/settings.json, or when the OS behaves unexpectedly.
allowed-tools: Bash, Read, Glob, Grep
---

# AI OS boot

Bring the OS from "files on disk" to "safe to run".

## Steps
1. Run `bin/aios doctor --all`. It checks: directory skeleton, hook syntax, hook wiring in
   `settings.json`, skill frontmatter, agent descriptions budget, contract schemas, ledger integrity,
   sandbox availability, MCP server reachability.
2. Fix every `FAIL`. `WARN` items are advisory but logged to `state/ledger.jsonl`.
3. Rebuild indexes: `bin/aios boot` → `state/index/{repo,skills,tools}.md`.
4. Print the boot digest to the human (≤ 25 lines): open tasks, pending approvals, spend today,
   top-3 risks from `state/notes/`.

## Rules
- Never skip a `FAIL` to get work done. A failing boot means the kernel is unenforced.
- If `settings.json` changed, `AI OS` must be restarted for permissions to reload — say so.

## Verify
bin/aios doctor --all | tail -20   # expect 0 FAIL
