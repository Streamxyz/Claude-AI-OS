---
name: aios-learn
description: Harvest corrections, gate failures, and recurring patterns into rule and skill improvement proposals. Use at SessionEnd and nightly; never left in chat.
allowed-tools: Bash, Read, Write, Edit, Grep, Glob
---

# Learn

A correction repeated three times must become a rule or a script — never a fourth explanation.

## Steps
1. Scan `state/ledger.jsonl` for: repeated gate failures by gate, escalations by reason,
   contract breaches by agent, and corrections the human typed more than once.
2. Classify each recurring item: **convention** → `.claude/rules/<topic>.md` with `paths:`;
   **procedure** → new or updated skill; **determinism** → new script in `scripts/`;
   **one-off** → ignore.
3. Open a PR with the proposal. Never silently edit `CLAUDE.md`; it must stay ≤ 150 lines.
4. Record the promotion in `state/notes/learnings.md` with the evidence count.

## Rules
- No rule is added without ≥ 3 pieces of evidence or one security incident.
- Prefer a script over a rule: code is deterministic, prose is a suggestion.
- Skill-rot signal: a skill patched more than twice a month gets rewritten, not patched again.

## Verify
bin/aios learn --dry-run
