---
name: aios-context
description: Reclaim context — checkpoint state to disk, compact, and re-inject the primer. Use when PostToolBatch reports >60% context, when output quality drops, or between unrelated tasks.
allowed-tools: Bash, Read, Write, Edit
---

# Context management

```bash
bin/aios context          # checkpoint → /compact → re-prime
bin/aios context --check  # report only, no compaction
```

## Protocol
1. **Checkpoint**: open tasks, decisions, blockers, and evidence paths → `state/notes/<topic>.md`
   and `state/tasks/<id>.json`. Never leave a decision only in the transcript.
2. **Compact**: `/compact` (auto-compact is already on at `autoCompactWindow: 400000`).
3. **Re-prime**: `PostCompact` hook re-injects `state/primer.md` (≤ 60 lines).
4. **Resume**: read the task record, not the summary in your head.

## Rules
- Do not push through a window above 80%. Quality degrades before the window is full.
- One task per session. Unrelated work gets a new session — mixing tasks is the main cause of
  context rot.
- Never edit `CLAUDE.md`, `settings.json`, or tool definitions mid-run: it invalidates the prompt
  cache and shifts behaviour.

## Verify
bin/aios context --check
