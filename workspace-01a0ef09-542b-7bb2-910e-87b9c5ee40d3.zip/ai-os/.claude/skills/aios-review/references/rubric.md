# Review rubric

| Severity | Meaning | Action |
|---|---|---|
| critical | data loss, security hole, unrecoverable state | block + approval + incident note |
| high | wrong behaviour in a reachable path, missing authz | block + approval |
| medium | wrong behaviour in an edge path, missing test | fix before merge |
| low | clarity, naming, minor duplication | fix or ticket |

Findings must carry `file:line`, impact, and a one-line fix. "Consider…" without a reason is noise.

## Falsification check
For every claim in the PR description, name the test or command that would fail if the claim were
false. A claim with no falsifier is not reviewed, it is believed.
