---
name: aios-review
description: Adversarial multi-agent review — correctness, security, and test-quality angles run in parallel and merged into one ranked finding list. Use before merge on tier M+.
argument-hint: "<task-id or PR>"
allowed-tools: Bash, Read, Grep, Glob, Agent
---

# Review

Fan out three `reviewer` agents with different angles, then merge. Each runs in its own context, so
the main session only ever sees the merged list.

```bash
bin/aios review <task-id>
```

## Angles
1. **Correctness** — logic, state machines, error paths, races.
2. **Security** — escalate to `security-auditor` (opus) when the diff touches auth/payments/PII.
3. **Test quality** — do the new tests actually fail when the behaviour is removed?

## Merge rules
- Dedupe by `file:line`. Rank `critical > high > medium > low`.
- Drop style nits — the formatter owns those.
- Any `high` blocks merge and writes an approval item.

## Rubric
See `references/rubric.md`.

## Verify
bin/aios review <task-id> | jq '.findings | length, map(.severity)'
