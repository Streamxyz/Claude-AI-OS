---
name: aios-audit
description: Repo-wide multi-agent audit via dynamic workflow — security, dead code, dependencies, docs drift, each cross-checked by independent verifier agents. Use nightly or before a release.
argument-hint: "[--scope security,deps,deadcode,docs]"
allowed-tools: Bash, Read, Grep, Glob, Agent
---

# Audit (dynamic workflow)

For work that outgrows a handful of subagents, the plan lives in a **script**, not in a context
window. Claude writes it; the runtime fans out up to 16 concurrent agents (1,000 per run);
intermediates stay in script variables.

```bash
bin/aios audit --scope security,deps,deadcode,docs
```

## Phases
1. **fan-out** — one agent per file batch per scope, haiku/sonnet, read-only.
2. **verify** — independent agents try to refute each finding; only survivors are reported.
3. **synthesize** — one ranked report; per-scope PRs are drafted, never merged.
4. **escalate** — anything `high` becomes an approval item.

Saved workflows live in `.claude/workflows/`. Press `s` in `/workflows` to save a run as a reusable
command. Requires Claude Code ≥ 2.1.154 (`enableWorkflows: true`, already set).

## Rules
- Audit output is a **report + draft PRs**, never direct commits to `main`.
- Every finding carries `file:line` and a reproduction command.
- Unverifiable findings are reported as `unknown`, never as `safe`.

## Verify
bin/aios audit --scope security | jq '.findings | map(select(.verified == false)) | length'
