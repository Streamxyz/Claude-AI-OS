#!/usr/bin/env bash
# Deploy wrapper. Requires: green pipeline, approval item, tested rollback.
set -uo pipefail
ENV="${1:-}"; cd "${CLAUDE_PROJECT_DIR:-$(pwd)}"
[ -z "$ENV" ] && { echo "usage: deploy.sh <env>"; exit 2; }
echo "preflight: gates"
bin/aios verify --gate build || { echo "abort: build failed"; exit 1; }
echo "preflight: migration dry-run"
bin/aios verify --gate migrate >/dev/null || { echo "abort: migration dry-run failed"; exit 1; }
APPR="state/approvals/pending.json"
if [ -f "$APPR" ] && grep -q "\"deploy" "$APPR" 2>/dev/null; then echo "abort: unresolved deploy approval"; exit 1; fi
echo "TODO: wire this to your declarative deploy (terraform/helm/fly/vercel)."
echo "Never deploy from a laptop, and never deploy main by hand."
exit 0
