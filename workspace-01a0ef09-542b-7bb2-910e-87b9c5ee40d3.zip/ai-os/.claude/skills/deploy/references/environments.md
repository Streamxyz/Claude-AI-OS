# Environments
| Env | Purpose | Data | Deploys | Gates |
|---|---|---|---|---|
| local | development | seeded fixtures | manual | typecheck, unit |
| preview | per-PR review | synthetic | automatic on PR | + build, e2e |
| staging | release candidate | anonymised prod-like | automatic on main | + security, smoke |
| production | live | real | manual approval + progressive flags | + rollback tested |

Rules: production is never the first place a migration runs. Every env is created by the same
declarative definition — no snowflakes.
