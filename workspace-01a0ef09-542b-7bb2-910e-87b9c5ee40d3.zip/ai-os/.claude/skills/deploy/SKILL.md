---
name: deploy
description: Use when deploying an environment, promoting a build, or changing deployment configuration. Never for local dev servers.
allowed-tools: Bash, Read, Grep
---

# Deploy

## Pre-flight (all required)
- [ ] green pipeline on the exact commit being deployed
- [ ] `bin/aios verify --gate migrate` (dry-run) if the release contains migrations
- [ ] rollback command identified and tested in a scratch environment
- [ ] feature flags for user-visible changes are **off** until post-deploy smoke passes

## Steps
1. `scripts/deploy.sh <env>` in the skill dir — declarative, idempotent, never a manual console change.
2. Run migrations (batched, backward compatible — see `db-migration`).
3. Smoke: `bin/aios verify --gate e2e` against the live environment.
4. Enable flags progressively (internal → 5% → 100%) with a metric watched at each step.
5. Write `state/notes/releases/<version>.md`: what, when, who, rollback, observed metrics.

## Rules
- A failed smoke test means **rollback**, not patch-forward (unless rollback risks data).
- Never deploy from a laptop. Never deploy `main` by hand.

## Verify
bin/aios verify --gate e2e
