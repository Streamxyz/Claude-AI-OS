---
name: db-migration
description: Use when changing a database schema, adding or editing a migration, backfilling data, or editing an ORM schema file. Do not use for query optimisation alone.
allowed-tools: Read, Write, Edit, Bash, Grep, Glob
---

# Database migration

Protected area — every migration writes an item to `state/approvals/pending.json`.

## Safety sequence (expand → migrate → contract)
1. **Expand**: add nullable column / new table / new index. Deploy. Old code still works.
2. **Migrate**: dual-write, then backfill in batches as a background job (never in a transaction).
3. **Contract**: remove the old path in a **later** release, once nothing reads it.

## Rules
- No `DROP COLUMN`/`DROP TABLE` in the same PR that stops writing to it.
- No table rewrite or exclusive lock on a hot table without a maintenance window.
- Every migration carries a **tested rollback command** in its header comment.
- Add indexes concurrently; verify with `EXPLAIN` before and after.
- Backfills: batched, idempotent, resumable, rate-limited, observable.

## Steps
1. Write the migration with `scripts/scaffold.sh <name>` in the skill dir.
2. `bin/aios verify --gate migrate` — dry-run. Live `--up`/`--down` require an approval item.
3. Update the ORM schema and any generated types in the same commit.
4. Note the change in `state/notes/schema.md` (what, why, rollback).

## Verify
bin/aios verify --gate migrate,test
