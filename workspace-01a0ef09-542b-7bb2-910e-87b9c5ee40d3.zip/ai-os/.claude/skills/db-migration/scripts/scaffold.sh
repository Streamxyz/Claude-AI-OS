#!/usr/bin/env bash
# Create a timestamped migration with a tested-rollback header.
set -euo pipefail
NAME="${1:-change}"
DIR="${2:-prisma/migrations}"
TS="$(date -u +%Y%m%d%H%M%S)"
mkdir -p "$DIR/${TS}_${NAME}"
cat > "$DIR/${TS}_${NAME}/migration.sql" <<SQL
-- migration: ${NAME}
-- created:   $(date -u +%Y-%m-%dT%H:%M:%SZ)
-- expand → migrate → contract. Backward compatible for one release.
-- rollback: -- TODO: exact command, tested in a scratch environment
-- safety:   -- TODO: lock impact, batch size, backfill strategy

-- UP
-- TODO

-- DOWN
-- TODO
SQL
echo "created $DIR/${TS}_${NAME}/migration.sql"
echo "next: fill UP + DOWN, then: bin/aios verify --gate migrate"
