---
name: aios-cost
description: Report token and dollar spend by task, agent, model, and tier, plus the top three concrete optimizations. Use nightly, after large runs, or when spend spikes.
argument-hint: "[--since 1d|7d] [--by model,agent,tier] [<task-id>]"
allowed-tools: Bash, Read
---

# Cost

```bash
bin/aios cost --since 7d --by model,agent,tier
bin/aios cost T-142
```

## What to look at, in order
1. **Routing** — is an expensive model doing cheap work? (opus on classify, on bulk edits)
2. **Cache hit rate** — target ≥ 70%. Low means churn in the stable prefix.
3. **Rework** — repeated gate runs with identical inputs; tasks redoing ledgered work.
4. **Contract breaches** — agents returning more than 2000 tokens.
5. **Tier inflation** — S work executed as M.

## Rules
- Never propose removing a gate, a verifier, or a security check to save money.
- Every suggestion names the change and its measured saving.

## Verify
scripts/cost_report.py --since 7d | jq '.total_usd, .cache_hit_pct'
