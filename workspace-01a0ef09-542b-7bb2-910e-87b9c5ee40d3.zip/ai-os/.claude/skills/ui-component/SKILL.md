---
name: ui-component
description: Use when building or changing a UI component, page, or design-system primitive. Do not use for styling-only tweaks that a formatter or token change covers.
allowed-tools: Read, Write, Edit, Bash, Grep, Glob
---

# UI component

1. Scaffold: `python3 ${CLAUDE_SKILL_DIR}/scripts/scaffold.py <Name>` → component + test + story.
2. States: **default, loading, error, empty, disabled** — all five, or the component is unfinished.
3. Tokens only. No raw hex, no magic spacing, no one-off font sizes (`references/design-tokens.md`).
4. Accessibility: semantic element first, label on every control, visible focus, keyboard path,
   `aria-*` only when semantics are insufficient.
5. Data: pure component + route-level loader or hook. No fetching inside presentational components.
6. Tests: render, interact, assert on accessible roles; one test per state.

## Rules
- No `any`. No inline styles except genuinely computed values.
- Composition over configuration: no boolean prop explosions.
- Visual changes are proven with `/verify` against the **running app** plus a screenshot diff.

## Verify
bin/aios verify --gate lint,unit,e2e
