#!/usr/bin/env python3
"""Scaffold a UI component with all five states and a test.

  scaffold.py DataTable [--dir src/components]
"""
import argparse, os

ROOT = os.environ.get("CLAUDE_PROJECT_DIR") or os.getcwd()

TSX = '''type {Name}Props = {{
  /** data to render */
  // TODO
}};

/**
 * {Name}
 * States: default · loading · error · empty · disabled — all five, or it is unfinished.
 */
export function {Name}(props: {Name}Props) {{
  return (
    <div data-testid="{name}">
      {{/* TODO: implement the five states */}}
    </div>
  );
}}
'''

TEST = '''import {{ render, screen }} from "@testing-library/react";
import {{ {Name} }} from "./{Name}";

describe("{Name}", () => {{
  it("renders the default state", () => {{
    render(<{Name} />);
    expect(screen.getByTestId("{name}")).toBeTruthy();
  }});
  it("renders loading", () => {{ /* TODO */ }});
  it("renders error", () => {{ /* TODO */ }});
  it("renders empty", () => {{ /* TODO */ }});
  it("is disabled when disabled", () => {{ /* TODO */ }});
}});
'''

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("name")
    ap.add_argument("--dir", default="src/components")
    a = ap.parse_args()
    Name = a.name[:1].upper() + a.name[1:]
    name = "".join(["-" + c.lower() if c.isupper() else c for c in a.name]).lstrip("-")
    out = os.path.join(ROOT, a.dir)
    os.makedirs(out, exist_ok=True)
    for fn, tpl in ((f"{Name}.tsx", TSX), (f"{Name}.test.tsx", TEST)):
        p = os.path.join(out, fn)
        if os.path.exists(p):
            print(f"skip (exists): {p}"); continue
        open(p, "w").write(tpl.format(Name=Name, name=name))
        print(f"created: {os.path.relpath(p, ROOT)}")
    print("next: implement the five states with design tokens, then: bin/aios verify --gate e2e")
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
