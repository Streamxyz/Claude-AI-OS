# Design tokens (rules, not values — read the product's token file for values)
- Colour: semantic tokens only (`surface`, `text-muted`, `danger`). Never `brand-blue-500` in a component.
- Space: 4px scale via spacing tokens. No `margin: 13px`.
- Type: type-scale tokens. No raw `font-size`.
- Radius/shadow/elevation/z-index: tokens. Ad-hoc z-index is a bug.
- Motion: duration/easing tokens; respect `prefers-reduced-motion`.
- Breakpoints: named tokens; mobile-first.
- Dark mode: tokens switch, components do not branch on theme.
