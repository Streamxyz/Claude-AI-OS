#!/usr/bin/env python3
"""Find documentation that references symbols changed since a git ref.

  docs_drift.py --since HEAD~1
  docs_drift.py --since <tag> --docs docs
"""
import argparse, os, re, subprocess, sys

ROOT = os.environ.get("CLAUDE_PROJECT_DIR") or os.getcwd()
SYMBOL = re.compile(r"\b(?:def|class|function|export (?:async )?function|export const)\s+([A-Za-z_]\w*)")
IDENT = re.compile(r"\b([A-Za-z_]\w{4,})\b")

def changed_symbols(ref: str) -> set[str]:
    try:
        diff = subprocess.run(["git", "diff", "--unified=0", ref], cwd=ROOT,
                              capture_output=True, text=True, timeout=60).stdout
    except Exception:
        return set()
    syms = set()
    for line in diff.splitlines():
        if line.startswith(("+++", "---")):
            continue
        if line.startswith(("+", "-")):
            syms.update(SYMBOL.findall(line))
    return {s for s in syms if len(s) > 3}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--since", default="HEAD~1")
    ap.add_argument("--docs", default="docs")
    a = ap.parse_args()

    syms = changed_symbols(a.since)
    if not syms:
        print("no symbol changes detected in the diff — nothing to check")
        return 0

    hits = []
    docs_root = os.path.join(ROOT, a.docs)
    for dirpath, dirnames, files in os.walk(docs_root):
        for fn in files:
            if not fn.endswith((".md", ".mdx")):
                continue
            p = os.path.join(dirpath, fn)
            try:
                text = open(p, encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
            found = sorted({s for s in syms if s in text})
            if found:
                hits.append({"doc": os.path.relpath(p, ROOT), "symbols": found})

    print(f"changed symbols: {', '.join(sorted(syms))}\n")
    if not hits:
        print("no docs reference the changed symbols")
        return 0
    for h in hits:
        print(f"{h['doc']}: {', '.join(h['symbols'])}")
    print(f"\n{len(hits)} doc(s) may be stale — update them in the same PR")
    return 1
if __name__ == "__main__":
    raise SystemExit(main())
