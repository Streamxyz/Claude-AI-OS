---
name: docs-sync
description: Use when a public API, CLI flag, config key, or schema changed and documentation may now be wrong. Also for the nightly docs-drift routine.
allowed-tools: Read, Write, Edit, Bash, Grep, Glob
---

# Docs sync

Stale docs are a defect with a longer half-life than a bug.

## Steps
1. `python3 ${CLAUDE_SKILL_DIR}/scripts/docs_drift.py --since <ref>` → list of docs referencing changed
   symbols, plus symbols with no docs at all.
2. Update the affected documents in the same PR as the code change, when the change is user-visible.
3. For internal behaviour changes: update `state/notes/<topic>.md` — not the public docs.
4. Never document intended behaviour that the code does not have; fix the code or file a task.

## Rules
- One source of truth. Generated docs are generated; hand-written docs are hand-written; never both.
- Code examples in docs must compile/run — the drift script checks them.
- Changelog entries come from task records, never from memory.

## Verify
python3 ${CLAUDE_SKILL_DIR}/scripts/docs_drift.py --since HEAD~1
