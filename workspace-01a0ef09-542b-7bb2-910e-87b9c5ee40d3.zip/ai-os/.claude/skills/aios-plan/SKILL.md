---
name: aios-plan
description: Produce an implementation plan with slices, file-ownership map, and per-slice gates. Use for tier M and above, and whenever more than one agent will touch code.
argument-hint: "<task-id>"
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, Agent
---

# Plan

Output: `state/tasks/<id>.json` with `slices[]`, each with an **exclusive file-ownership list**.

## Steps
1. Read the spec and `state/index/repo.md` (or call `explorer` for unfamiliar areas).
2. Decompose into slices of 15–60 minutes that are independently verifiable.
3. Assign ownership: every file in the change set belongs to exactly one slice.
4. Name gates per slice + the DoD gate set for the task.
5. Name the riskiest assumption and the cheapest way to disprove it.

## Rules
- A step you cannot verify is not a step.
- Sort slices so the riskiest assumption is disproven **first**, not last.
- Reuse before build: check `state/notes/` and `state/ledger.jsonl` for a solved equivalent.

## Verify
bin/aios plan <task-id>   # ownership is disjoint
