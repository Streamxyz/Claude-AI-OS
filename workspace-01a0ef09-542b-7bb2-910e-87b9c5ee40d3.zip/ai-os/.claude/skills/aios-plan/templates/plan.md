# Plan — T-000

## Slices
| # | Goal | Owner | Files | Gates | Depends on |
|---|------|-------|-------|-------|-----------|
| 1 | …    | implementer | src/api/x.ts | typecheck,unit | — |

## DoD gates
typecheck, lint, unit, build

## Riskiest assumption
<assumption> — disprove by: <cheapest command>

## Rejected
- <option>: <one-line reason>
