# Naming
- Metrics: `<domain>_<subject>_<unit>` → `http_request_duration_seconds`, `queue_jobs_total`.
  Counters end `_total`; histograms end in their unit (`_seconds`, `_bytes`).
- Labels: low cardinality only — `route` (templated, not `/users/123`), `method`, `status_class`, `env`.
- Logs: `ts level service trace_id span_id msg` + structured fields (`user_id`, `route`, `duration_ms`).
- Traces: span names are `<METHOD> <route-template>`; attributes are snake_case.
- Alerts: `<service>-<symptom>-<threshold>` → `checkout-error-rate-high`.
- Dashboards: one per service, RED at the top, dependencies below.
