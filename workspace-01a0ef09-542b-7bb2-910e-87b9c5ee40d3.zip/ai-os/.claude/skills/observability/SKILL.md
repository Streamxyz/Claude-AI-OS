---
name: observability
description: Use when adding metrics, logs, traces, or alerts, or when a change cannot be verified in production without telemetry.
allowed-tools: Read, Write, Edit, Bash, Grep
---

# Observability

If you cannot see it fail, you cannot operate it.

## Rules
- Metrics: RED (rate, errors, duration) for every service; USE for resources. Naming in
  `references/naming.md`. No unbounded label cardinality (never a user id as a label value).
- Logs: structured, levelled, with a correlation id. Never log secrets, tokens, or full payloads
  containing PII.
- Traces: span per inbound request and per outbound call; propagate context; sample with tail
  sampling for errors.
- Alerts: symptom-based (user impact), not cause-based (cpu high). Every alert has a runbook link.
- Dashboards follow the change: a new endpoint ships with its RED panel.

## Steps
1. Instrument the new path (metric + span + structured log with correlation id).
2. Add or update the alert only if there is user impact and a known action.
3. Verify by triggering the failure path in a scratch environment and confirming the signal appears.

## Verify
bin/aios verify --gate unit
