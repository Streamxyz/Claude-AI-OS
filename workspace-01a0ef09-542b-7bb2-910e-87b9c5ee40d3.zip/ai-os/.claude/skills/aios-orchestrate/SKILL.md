---
name: aios-orchestrate
description: Run the full AI OS pipeline on an intent — spec, plan, dispatch, implement, verify, learn. Use when the user gives a feature, bug, or refactor to deliver end to end.
argument-hint: "<task-id or intent file>"
allowed-tools: Bash, Read, Write, Edit, Glob, Grep, Agent
---

# Orchestrate

One command turns intent into a merged, gate-green, ledgered change.

```bash
bin/aios run <task-id>            # tier decides execution
bin/aios run <task-id> --team     # force agent team (tier L)
bin/aios run <task-id> --swarm    # force dynamic workflow (tier XL)
```

## Pipeline
| Phase | Owner | Artifact |
|---|---|---|
| 1 classify | `classifier` (haiku) | `state/tasks/<id>.json` tier + gates |
| 2 spec | `aios-spec` | `specs/intent/<id>.md` |
| 3 recon | `explorer` (haiku, own context) | file map |
| 4 plan | `planner` (opus) | slices + **file-ownership map** |
| 5 implement | `implementer` (sonnet, worktree) | commits per slice |
| 6 test | `testsmith` | tests + gate evidence |
| 7 review | `reviewer` (+ `security-auditor` if high risk) | findings JSON |
| 8 verify | `verifier` (haiku) — tries to refute | pass/fail + refutations |
| 9 merge | orchestrator | PR + ledger row |
| 10 learn | `scribe` + `cost-optimizer` | notes, index, cost entry |

## Rules
- Tier S skips phases 3–4. Tier XL replaces 5–6 with a dynamic workflow (see `references/tiers.md`).
- Every phase writes to `state/tasks/<id>.json`. If a phase produces no artifact, it did not happen.
- Three consecutive gate failures → escalate via `state/approvals/pending.json`; pick up other work.
- Never let two agents own one file. Ownership conflicts are plan defects, resolved by the planner.

## Verify
bin/aios verify <task-id> && bin/aios cost <task-id>
