# Tier playbook

## S — one file, known fix
implementer(sonnet, medium) → gates `typecheck,unit` → verifier. No plan. Target < 25k tokens.

## M — 2–5 files, clear scope
planner(opus, high) → implementer → testsmith → gates `typecheck,lint,unit,build` → verifier.
Target < 120k tokens.

## L — feature slice, cross-cut
planner → **agent team**: api-contract, backend, frontend, tests — each with exclusive file
ownership and its own worktree → gates `+e2e` → reviewer + security-auditor → verifier.
Target < 600k tokens.

## XL — repo-wide, research, migration
Claude writes a **dynamic workflow** script (`.claude/workflows/`): phases fan out to dozens of
workers; a verify phase has independent agents cross-check findings; a synthesize phase returns one
report. Intermediates live in script variables, not context. Requires Claude Code ≥ 2.1.154.
Target: budget-capped, escalate at 1.5×.

## Escalation ladder
gate_fail×3 · budget ×1.5 · protected path · ambiguity ≥ 2 valid designs · payment/auth/PII/schema
→ write `state/approvals/pending.json`, notify, continue with other tasks.
