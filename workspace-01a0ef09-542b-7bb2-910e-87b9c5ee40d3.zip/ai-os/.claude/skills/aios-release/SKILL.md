---
name: aios-release
description: Cut a release — version bump, changelog from merged task records, tag, migration dry-run, and rollback note. Use when merging to main or shipping an environment.
argument-hint: "[patch|minor|major]"
allowed-tools: Bash, Read, Write, Edit, Grep
---

# Release

## Pre-flight (all must pass)
- [ ] `bin/aios verify` green on the release commit
- [ ] `bin/aios verify --gate migrate` (dry-run) if the release contains schema changes
- [ ] `security-auditor` returned `pass` for this release's diff
- [ ] no open `high` findings; no pending approvals blocking
- [ ] rollback command written and tested in a scratch environment

## Steps
1. Changelog from merged `state/tasks/*.json` (`templates/changelog.md`).
2. Version bump, tag, changelog commit — one commit, no code changes.
3. Deploy through the pipeline; never by hand.
4. Post-deploy smoke: run `aios-verify --gate e2e` against the live environment.
5. Ledger the release; write `state/notes/releases/<version>.md`.

## Rules
- A release with a failed smoke test is rolled back, not patched forward, unless data is at risk.
- Every release names its rollback command.

## Verify
bin/aios verify --gate migrate && bin/aios verify --all-gates
