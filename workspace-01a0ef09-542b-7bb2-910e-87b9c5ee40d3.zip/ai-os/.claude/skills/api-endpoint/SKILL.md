---
name: api-endpoint
description: Use when adding or changing an HTTP endpoint, route handler, RPC method, or webhook receiver. Do not use for client-side data fetching or internal function signatures.
allowed-tools: Read, Write, Edit, Bash, Grep, Glob
---

# API endpoint

1. Scaffold: `python3 ${CLAUDE_SKILL_DIR}/scripts/scaffold.py <method> <path>` → handler + schema + tests.
2. Handler shape: validate (zod/pydantic) → authorize (middleware, never inline) → service → envelope.
3. Response envelope: `{ "data": T | null, "error": { "code", "message" } | null }`.
4. Errors: explicit status codes. Never leak stack traces or driver errors to the client.
5. Mutations: idempotency key + rate limit. Reads: cache headers + ETag where cheap.
6. Tests: happy path, validation failure, unauthorized, forbidden, not-found, conflict, rate-limited.
7. Contract style: see `references/contract-style.md`.

## Rules
- One route file per resource; handlers ≤ 40 lines; business logic lives in a service.
- New route ⇒ one line declaring its permission, at the top of the file.
- Never add a dependency to solve a validation or serialization problem — the stack already has one.

## Verify
bin/aios verify --gate typecheck,unit
