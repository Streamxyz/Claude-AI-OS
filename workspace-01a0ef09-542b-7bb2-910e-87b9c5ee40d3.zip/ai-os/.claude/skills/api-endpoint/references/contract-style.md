# Contract style
- Paths: plural nouns, kebab-case, no verbs (`/workspaces/:id/invitations`).
- Methods: GET (read), POST (create/action), PUT (replace), PATCH (partial), DELETE (remove).
- Query params for filtering/sorting/pagination: `?limit&cursor&sort=-created_at`. Cursor, not offset.
- Status codes: 200 ok · 201 created (+ Location) · 202 accepted · 204 no content ·
  400 validation · 401 unauthenticated · 403 unauthorized · 404 not found · 409 conflict ·
  422 semantic · 429 rate limited · 5xx server (never intentional).
- Error codes are stable strings (`rate_limit_exceeded`), messages are for humans and may change.
- Versioning: URL prefix only when breaking; prefer additive changes.
- Every webhook: signature verification, idempotent processing, ≤ 5s ack then async work.
