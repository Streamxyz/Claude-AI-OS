#!/usr/bin/env python3
"""Scaffold an API endpoint: handler + schema + test. Deterministic, no prose needed.

  scaffold.py GET /workspaces/:id        # TypeScript (detected by tsconfig/package.json)
  scaffold.py POST /workspaces --lang py # force Python (FastAPI)
"""
import argparse, os, re, sys

ROOT = os.environ.get("CLAUDE_PROJECT_DIR") or os.getcwd()

TS_HANDLER = '''import { z } from "zod";

export const {name}Schema = z.object({{
  // TODO: request shape
}});

export type {Name}Request = z.infer<typeof {name}Schema>;

/** {METHOD} {path} — permission: TODO */
export async function {name}Handler(req: Request): Promise<Response> {{
  const parsed = {name}Schema.safeParse(await req.json().catch(() => ({{}})));
  if (!parsed.success) {{
    return Response.json({{ data: null, error: {{ code: "validation_failed", message: parsed.error.message }} }}, {{ status: 400 }});
  }}
  // TODO: call the service layer
  return Response.json({{ data: {{}}, error: null }});
}}
'''

PY_HANDLER = '''from pydantic import BaseModel


class {Name}Request(BaseModel):
    # TODO: request shape
    pass


# {METHOD} {path} — permission: TODO
async def {name}_handler(payload: {Name}Request):
    # TODO: call the service layer
    return {{"data": {{}}, "error": None}}
'''

TS_TEST = '''import {{ describe, it, expect }} from "vitest";
import {{ {name}Handler }} from "./{name}";

describe("{METHOD} {path}", () => {{
  it("returns 200 on a valid request", async () => {{
    const res = await {name}Handler(new Request("http://x", {{ method: "{METHOD}" }}));
    expect(res.status).toBeLessThan(500);
  }});
  it("returns 400 on an invalid request", async () => {{ /* TODO */ }});
  it("returns 401 without auth", async () => {{ /* TODO */ }});
  it("returns 403 for the wrong tenant", async () => {{ /* TODO */ }});
}});
'''

PY_TEST = '''import pytest
from .{name} import {name}_handler


@pytest.mark.asyncio
async def test_{name}_ok():
    assert await {name}_handler(None) is not None
'''

def slug(path: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", path.lower()).strip("-") or "endpoint"

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("method")
    ap.add_argument("path")
    ap.add_argument("--lang", default="")
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    lang = a.lang or ("ts" if (os.path.exists(os.path.join(ROOT, "tsconfig.json"))
                              or os.path.exists(os.path.join(ROOT, "package.json"))) else "py")
    name = slug(a.path)
    Name = "".join(p.capitalize() for p in name.split("-"))
    ctx = {"name": name, "Name": Name, "METHOD": a.method.upper(), "path": a.path}
    out_dir = a.out or os.path.join(ROOT, "src", "api")
    os.makedirs(out_dir, exist_ok=True)

    if lang == "ts":
        files = {f"{name}.ts": TS_HANDLER, f"{name}.test.ts": TS_TEST}
    else:
        files = {f"{name}.py": PY_HANDLER, f"test_{name}.py": PY_TEST}

    for fn, tpl in files.items():
        p = os.path.join(out_dir, fn)
        if os.path.exists(p):
            print(f"skip (exists): {p}")
            continue
        with open(p, "w") as f:
            f.write(tpl.format(**ctx))
        print(f"created: {os.path.relpath(p, ROOT)}")
    print("next: fill the request schema, wire the route, run: bin/aios verify --gate unit")
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
