# Patch contract

A reviewable diff:

- One concern per commit; commits tell the story in order.
- No formatting-only hunts mixed with behaviour changes.
- Tests for the new behaviour in the same commit as the behaviour.
- Deleted code is deleted, not commented out.
- Public API changes are accompanied by a docs update (`docs-sync` skill) in the same PR.
- Every new error path maps to a real error code; no generic `catch {}` swallowing.
- Feature-flagged when the change is user-visible and reversible.
