---
name: aios-implement
description: Implement one approved slice inside a worktree, running gates after every meaningful change. Use when a plan slice exists and ownership is assigned.
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---

# Implement

## Loop
```
read slice → change ≤ 1 concern → run slice gates → commit → next concern
```

## Rules
- Implement **only** the slice. No drive-by refactors, no new deps, no schema or infra changes.
- Run gates after every meaningful change, not at the end. A red gate is cheaper to fix now.
- Never edit outside the ownership list. Request ownership instead.
- No `// TODO`. Unfinished work becomes a task in `state/tasks/`.
- Two identical gate failures → stop, hand to `resolver`, do not thrash.
- Commit message: `<type>(<scope>): <what> — T-<id> slice <n>`.

## Patch hygiene
See `references/patch-contract.md` for the diff shape reviewers expect.

## Verify
bin/aios verify --gate typecheck,lint,unit
