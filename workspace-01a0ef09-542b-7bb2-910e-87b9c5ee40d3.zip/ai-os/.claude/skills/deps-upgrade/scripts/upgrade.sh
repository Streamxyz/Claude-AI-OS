#!/usr/bin/env bash
# Dependency upgrade. patch=auto, minor=review, major=approval item.
set -uo pipefail
TYPE="${1:---patch}"; PKG="${2:-}"
cd "${CLAUDE_PROJECT_DIR:-$(pwd)}"
case "$TYPE" in
  --major) echo "AI OS: major upgrades require an approval item (OPERATIONS.md §2). Aborting."; exit 1 ;;
esac
if [ -f pnpm-lock.yaml ]; then PM=(pnpm); elif [ -f package.json ]; then PM=(npm); else PM=(); fi
if [ ${#PM[@]} -gt 0 ]; then
  if [ -n "$PKG" ]; then "${PM[@]}" update "$PKG" || exit 1; else "${PM[@]}" update || exit 1; fi
fi
[ -f pyproject.toml ] && { python3 -m pip install --upgrade pip >/dev/null 2>&1; \
  command -v uv >/dev/null && uv lock --upgrade || true; }
echo "upgraded ($TYPE${PKG:+ $PKG}). Review the lockfile diff line by line, then run all gates."
