---
name: deps-upgrade
description: Use when bumping dependencies, resolving vulnerabilities, or reviewing a lockfile change. Do not use for adding a new dependency (that needs an architecture note).
allowed-tools: Bash, Read, Edit, Grep, Glob
---

# Dependency upgrades

## Rules
- **Patch**: auto-merge when the pipeline is green (nightly routine).
- **Minor**: auto-PR + review of the changelog for behaviour changes.
- **Major**: never automatic. One PR per major, with a migration note and an approval item.
- Security advisory: patch or minor first; if only a major fixes it, escalate with options.
- No new dependency without a written reason in `state/notes/dependencies.md` — the cheapest
  dependency is the one you did not add.

## Steps
1. `scripts/upgrade.sh --type patch|minor|major --package <name>`.
2. Read the changelog for breaking changes and deprecations actually used by this repo.
3. Run the **full** gate set, not just typecheck.
4. Lockfile diff reviewed line by line; transitive additions are the usual surprise.

## Verify
bin/aios verify --gate typecheck,unit,build,sec
