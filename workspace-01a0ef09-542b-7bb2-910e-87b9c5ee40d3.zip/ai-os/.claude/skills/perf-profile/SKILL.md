---
name: perf-profile
description: Use when something is slow, a latency or bundle-size budget is at risk, or before optimising. Measure first; never optimise on intuition.
allowed-tools: Bash, Read, Grep, Glob
---

# Performance

## Rules
1. **Measure before and after.** No change without two numbers.
2. Optimise the constraint, not the nearest suspicious code. Profile to find it.
3. Budgets: p95 latency, bundle size, query count, memory. Write the budget down first.
4. Prefer removing work (fewer requests, less data) over doing the same work faster.
5. Cache last, and only with an explicit invalidation rule.

## Steps
1. `scripts/profile.sh --target <url|command> --budget <ms>` → baseline report.
2. Identify the top contributor (DB query? N+1? bundle? serialization? network waterfalls?).
3. Fix one thing. Re-measure. Repeat until the budget is met.
4. Add a regression gate so the budget cannot silently regress.

## Verify
scripts/profile.sh --target <target> --budget <ms>
