#!/usr/bin/env bash
# Measure, don't guess: latency sampler + optional load tool. Prints before/after numbers.
set -uo pipefail
TARGET="${2:-http://localhost:3000}"; BUDGET_MS="${4:-200}"; N="${N:-30}"
cd "${CLAUDE_PROJECT_DIR:-$(pwd)}"
command -v curl >/dev/null || { echo "curl required"; exit 1; }
TIMES=()
for i in $(seq 1 "$N"); do
  T=$(curl -s -o /dev/null -w '%{time_total}' "$TARGET" 2>/dev/null) || continue
  TIMES+=("$(python3 -c "print(int(float('$T')*1000))")")
done
python3 - "$BUDGET_MS" "${TIMES[@]}" <<'PY'
import sys
budget=int(sys.argv[1]); xs=sorted(int(v) for v in sys.argv[2:])
if not xs: print("no samples"); raise SystemExit(1)
def pct(p): return xs[min(len(xs)-1, int(len(xs)*p))]
print(f"samples={len(xs)}  min={xs[0]}ms  p50={pct(.5)}ms  p95={pct(.95)}ms  max={xs[-1]}ms  budget={budget}ms")
print("verdict:", "PASS" if pct(.95) <= budget else f"FAIL — p95 {pct(.95)}ms over {budget}ms")
PY
