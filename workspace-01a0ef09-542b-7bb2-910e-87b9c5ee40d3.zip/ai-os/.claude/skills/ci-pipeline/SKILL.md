---
name: ci-pipeline
description: Use when creating or editing CI configuration, build stages, caching, or release automation. Do not use for changing what tests assert.
allowed-tools: Read, Write, Edit, Bash
---

# CI pipeline

Stage order is fixed — a later stage never runs before an earlier one passes:
`typecheck → lint → unit → build → e2e → security`.

## Rules
- Fail fast: cheapest stage first. Cache dependencies by lockfile hash.
- Every stage writes a machine-readable artifact to `state/traces/` equivalent (`artifacts/` in CI).
- No secret in the workflow file — environment references only.
- Nightly job: run `bin/aios audit --scope security,deps` on a schedule.
- Pipelines are code: reviewed, versioned, and never edited in the UI.

## Templates
`templates/pipeline.yml` (GitHub Actions) — copy, then trim. Do not start from a blank file.

## Verify
bin/aios verify --gate build && git diff --exit-code -- .github/workflows || echo "review diff"
