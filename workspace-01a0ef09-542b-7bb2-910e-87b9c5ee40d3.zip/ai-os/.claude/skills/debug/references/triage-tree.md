# Triage tree
- **Type error** → is the generated type stale? regenerate → is the schema wrong? fix schema, not the cast.
- **Test fails locally only** → env, seed data, timezone, clock, locale, package version drift.
- **Test fails in CI only** → parallel isolation, missing service, different Node/Python, cache, order.
- **Build fails, dev works** → tree-shaking, side effects, missing export, prod-only config, minifier.
- **Works on refresh, fails on navigation** → state hydration, client cache, effect cleanup.
- **Intermittent** → race, unawaited promise, shared mutable state, time dependence, connection pool.
- **Only under load** → N+1, missing index, lock contention, unbounded concurrency, queue backlog.
