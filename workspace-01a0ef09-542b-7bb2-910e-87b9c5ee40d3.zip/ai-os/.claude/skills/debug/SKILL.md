---
name: debug
description: Use when a test, build, or runtime failure needs a root cause. Do not use for speculative cleanups or when a gate failure is already understood.
allowed-tools: Bash, Read, Grep, Glob, Edit
---

# Debug

Fix the cause, not the symptom. Suppressing an error is not a fix.

## Method
1. Reproduce deterministically. If you cannot, the first task is to make it reproducible.
2. Read the **actual** error, in full, from the source — not a summary.
3. Bisect: `git bisect` for regressions; binary-search the input; halve the code path.
4. Form one hypothesis, test it, record the result. Do not shotgun changes.
5. Once fixed: add the regression test that fails without the fix, then note the root cause in
   `state/notes/debugging.md`.

## Rules
- Never add a retry, a `try/catch`, or a skip to make red go green.
- Two failed hypotheses ⇒ stop and escalate with the evidence; fresh eyes beat more thrashing.
- Three attempts on the same failure ⇒ hand to `resolver` / escalate (see `aios-orchestrate`).

## Triage tree
`references/triage-tree.md`.

## Verify
bin/aios verify --gate unit,typecheck
