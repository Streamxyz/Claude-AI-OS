---
name: aios-verify
description: Run the Definition-of-Done gate set and report a machine verdict with evidence paths. Use at the end of every task, and whenever a Stop hook blocks the turn.
argument-hint: "<task-id> [--gate typecheck,lint,unit,build,e2e,sec]"
allowed-tools: Bash, Read, Glob, Grep
---

# Verify

```bash
bin/aios verify <task-id>                 # gates from state/tasks/<id>.json
bin/aios verify <task-id> --gate e2e      # one gate
bin/aios gates                      # available gates
```

## Gates
`typecheck` · `lint` · `unit` · `build` · `e2e` · `sec` · `migrate:dry-run` — each a script in
Each gate is a script in the AI OS install (`scripts/gates/`), exits 0/1, and writes evidence to
`state/traces/<task-id>/`. Run them through `bin/aios verify` — never by path, so the command works
both from a repo checkout and from an installed plugin.

## Rules
- The conversation carries the **verdict line**, never the log. Logs stay on disk.
- A gate result is only valid if produced after the last commit; stale evidence is a `fail`.
- Unit tests alone are not evidence for a UI change — run `/verify` against the running app.
- Never weaken an assertion, skip a test, or edit a gate to get green.

## Verify
bin/aios verify <task-id> | jq '.pass'
