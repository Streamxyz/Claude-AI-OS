#!/usr/bin/env bash
# Thin wrapper so the skill never inlines gate logic.
# Resolves the AI OS install dir: plugin root, or the repo checkout.
set -euo pipefail
SELF="$(cd "$(dirname "$0")" && pwd)"
HOME_DIR="${CLAUDE_PLUGIN_ROOT:-$(cd "$SELF/../../.." && pwd)}"
exec "$HOME_DIR/scripts/gate.py" "$@"
