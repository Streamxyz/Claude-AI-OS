# Top web risk categories and the AI OS mitigation for each
1. **Broken access control** — authz middleware on every route; deny by default; ownership checks on
   every resource read/write; tests for the "wrong user" case on every endpoint.
2. **Cryptographic failures** — TLS everywhere; no custom crypto; secrets in env; rotate on exposure.
3. **Injection** — parameterised queries only; schema validation at boundaries; no string-built shell.
4. **Insecure design** — threat-model before implementation (this skill); rate limits by design.
5. **Security misconfiguration** — declarative infra; no default credentials; no debug in prod.
6. **Vulnerable components** — pinned lockfiles; nightly dependency audit; no unused deps.
7. **Auth failures** — MFA-ready; secure session rotation; no credentials in URLs; lockout policy.
8. **Data integrity** — signed webhooks; idempotency; verified artifacts; no unsigned deserialization.
9. **Logging failures** — structured audit logs for access and mutations; no secrets in logs.
10. **SSRF** — allow-list outbound hosts; no user-controlled fetch targets; block link-local metadata.
