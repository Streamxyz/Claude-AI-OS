---
name: security-review
description: Use when a change touches authentication, authorization, payments, PII, untrusted input, secrets, or a new dependency. Also use for release-time audits.
allowed-tools: Read, Grep, Glob, Bash, Agent
---

# Security review

Default posture: **escalate**. A `high` finding blocks merge and writes an approval item.

## Checklist
- Authz on every new path (not just authn); IDOR via guessable ids; horizontal privilege escalation.
- Injection: SQL, shell, template, deserialization, prototype pollution, path traversal.
- Secrets: env-only, never logged, never in a URL, never in a response body.
- Input: allow-list schema at every boundary; reject, do not sanitize-then-trust.
- Mutations: rate limit, idempotency key, replay protection.
- Data: PII minimization, retention, encryption in transit and at rest, audit log for access.
- Supply chain: new dependencies, lockfile diffs, install scripts, pinned versions.

## Rules
- Rate each finding: severity + likelihood + one-line exploit path.
- Cannot rule it out ⇒ report as `unknown`, never as `safe`.
- Never weaken a control to ship faster; escalate instead.

## Reference
`references/owasp-top.md` for the current top categories and their AI-OS-specific mitigations.

## Verify
bin/aios verify --gate sec
