# Selector priority
1. `getByRole('button', { name: /save/i })` — survives refactors, verifies accessibility.
2. `getByLabelText('Email')` — for form controls.
3. `getByText(/welcome back/i)` — for content assertions.
4. `getByTestId('checkout-total')` — last resort, when there is no semantic handle.

Never: `.css-class > div:nth-child(2)`, XPath, or positional selectors. They break on every refactor
and hide accessibility regressions.

## Waiting
`await expect(locator).toBeVisible()` · `waitForResponse` for a specific request ·
`waitForLoadState('networkidle')` only for pages with no long-polling (it never settles otherwise).
