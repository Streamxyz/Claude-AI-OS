---
name: e2e-test
description: Use when writing or fixing browser-level tests, or when a change must be proven against the running application rather than mocks.
allowed-tools: Read, Write, Edit, Bash, Grep, Glob
---

# E2E tests

Prove the user's path works in a real browser. Unit tests prove code; e2e proves the product.

## Rules
- Test **user journeys**, not components. One journey per file.
- Selectors: accessible roles and labels first, `data-testid` second. Never CSS or XPath
  (`references/selectors.md`).
- No `sleep()`. Wait on state: element, network idle, or a deterministic signal.
- Every test is independent: fresh state, seeded fixtures, no shared mutable data.
- Cover: happy path, validation error, permission denied, and the "back button" case.

## Steps
1. Write the journey against the running app (`bin/aios run --serve` first).
2. Run `bin/aios verify --gate e2e`; evidence goes to `state/traces/<task-id>/e2e.log`.
3. Confirm the test **fails when the feature is removed** — otherwise it proves nothing.

## Verify
bin/aios verify --gate e2e
