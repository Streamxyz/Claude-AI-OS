---
name: aios-incident
description: Triage an alert or incident — correlate the stack trace with recent commits, draft a fix in a worktree, and open a PR with a root-cause note. Use from a routine API trigger or when on-call.
argument-hint: "<alert-id or log excerpt>"
allowed-tools: Bash, Read, Grep, Glob, Agent
---

# Incident

Triggered by a routine (API trigger from monitoring) or by a human. Human reviews a **PR**, not a fire.

## Steps
1. **Scope** (`explorer`, haiku): first bad commit via `git log -S` / bisect on the failing symbol;
   blast radius; is it data-affecting?
2. **Mitigate first** — feature flag off or rollback, before root-causing. Stop the bleeding.
3. **Fix** (`implementer`, worktree): minimal change + a regression test that fails without it.
4. **Refute** (`verifier`): reproduce the alert condition, confirm the fix, confirm the test fails
   when reverted.
5. **Report**: PR + root-cause note in `state/notes/incidents/<id>.md` + timeline.

## Escalation
Payments, auth, or data-integrity incidents escalate at step 1 — do not attempt a fix unsupervised.
Confidence < 0.7 → escalate with findings instead of opening a PR.

## Triage tree
See `references/triage.md`.

## Verify
bin/aios verify <incident-task-id> --gate unit,e2e
