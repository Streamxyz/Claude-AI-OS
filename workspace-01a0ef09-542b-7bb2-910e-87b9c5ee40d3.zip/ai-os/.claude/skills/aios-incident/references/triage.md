# Triage tree

```
alert fires
├─ data-affecting? ─────────────► escalate + mitigate (flag off / rollback)
├─ new in last deploy? ──yes───► bisect → revert candidate → PR
│                    └──no─────► environmental: deps, config, quota, provider status
├─ reproducible locally? ──no──► add observability, escalate with unknowns
└─ error rate shape
   ├─ step change   → deploy or config
   ├─ slow ramp     → leak, quota, capacity
   └─ periodic      → cron, batch job, clock/timezone
```

Always answer: when did it start, what changed, who is affected, how do we stop it, how do we know
it stopped.
