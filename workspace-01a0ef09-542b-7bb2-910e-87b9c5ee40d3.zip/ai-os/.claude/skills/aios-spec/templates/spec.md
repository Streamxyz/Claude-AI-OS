# T-000 — <title>

## Goal
<one sentence: what is true after this ships>

## Non-goals
- <explicitly out of scope>
- <explicitly out of scope>

## Acceptance criteria
1. <observable, testable>
2. <observable, testable>

## Constraints
- perf: <budget>
- compat: <what must not break>
- security: <auth/pii considerations>

## Done means
gates: typecheck, lint, unit, build

## Open questions
- <blocking?> <question> → owner

## Options (if ≥ 2 materially different designs)
- A: … (pro/con, one line each)
- B: …
