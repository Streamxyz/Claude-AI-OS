---
name: aios-spec
description: Turn a vague intent into a testable spec with acceptance criteria and non-goals. Use when a request is ambiguous, when the user says "you decide", or before any tier M+ plan.
argument-hint: "<task-id>"
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---

# Spec

The human writes intent in `specs/intent/<id>.md`. You turn it into something falsifiable.

## Steps
1. Copy `templates/spec.md` to `specs/intent/<id>.md` if it does not exist.
2. Fill: **Goal** (one sentence) · **Non-goals** (≥ 2) · **Acceptance criteria** (testable, numbered)
   · **Constraints** (perf, compat, security) · **Done means** (gate list) · **Open questions**.
3. Every acceptance criterion must be checkable by a command or a test. "Works well" is not a criterion.
4. Ambiguity rule: if two designs are materially different, write **both** under `## Options` and
   raise an approval item. Do not silently pick.

## Rules
- Never invent requirements the user did not imply. Mark inferences as `Assumption:`.
- Non-goals are load-bearing: they stop scope creep during implementation.

## Verify
bin/aios spec <task-id> --check   # every criterion maps to a gate or test
