# Routing

`scripts/router.py` classifies every intent into a tier; the tier decides model, effort,
parallelism, and gate depth. Deterministic heuristics first — a guess that is *explainable*
(signals reported) is better than a silent one.

| Tier | Trigger | Model | Effort | Parallelism | Gates | Plan? |
|---|---|---|---|---|---|---|
| S | single-file fix | sonnet 5.5 | medium | 1 | typecheck, unit | no |
| M | 2–5 files | sonnet 5.5 | medium | 2 | +lint, build | yes |
| L | feature slice / risky domain | opus 5.5 | high | 4 (agent team) | +e2e | yes |
| XL | repo-wide / migration | opus 5.5 + workflow | high | 16 (dynamic workflow) | +sec | yes |

Escalate when: 3 gate failures · budget ×1.5 · protected path · ≥2 valid designs ·
payments/auth/PII/schema/infra.

## Model economics (per MTok)
Haiku 4.5 $1/$5 · Sonnet 5.5 $2/$10 · Opus 5.5 $4/$20 · Fable 5.1 $10/$50.
Effort is a first-class lever: `low` on Haiku for classification beats `high` on Opus.
