# Invariants

Break one of these and the OS degrades into an expensive chatbot with write access.

1. **`CLAUDE.md` ≤ 150 lines.** Growth is redirected to `.claude/rules/`, a skill, or `docs/`.
2. **No agent returns prose.** Every return is a validated JSON contract ≤ 2000 tokens.
3. **No raw command output > 200 lines** enters context (`bashOutputMaxChars: 8000` + truncate hook).
4. **No task state lives only in a transcript.** `state/tasks/<id>.json` is the record.
5. **No merge without a green gate** and evidence on disk under `state/traces/`.
6. **No skill without a `Verify` command; no rule without a hook or a test.**
7. **Every token spend is ledgered.** Nightly cost report is not optional.
8. **A correction repeated three times becomes a rule or a script** — never a fourth explanation.
9. **Hooks fire inside subagents too.** Delegation cannot bypass policy.
10. **The verifier is not the builder.** A fresh model grades the work.

## Derived budgets (see TOKEN-ECONOMY.md)
`CLAUDE.md+rules ≤ 6k` · `skill metadata ≤ 8k` · `agent descriptions ≤ 15k` (official warn) ·
`hot tool defs ≤ 4k` · `working set ≤ 60k` · `reserve ≥ 40%`.
