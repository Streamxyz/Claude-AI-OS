# Kernel

The kernel is the smallest set of things that must be true for the OS to be safe and cheap.
It is not code — it is **policy plus the scripts that enforce it**.

## Components
| Component | File | Enforced by |
|---|---|---|
| Constitution | `../../CLAUDE.md` | loaded every session (≤150 lines) |
| Path-scoped rules | `../../.claude/rules/*.md` | loaded on path match |
| Settings & permissions | `../../.claude/settings.json` | Claude Code runtime |
| Policy-as-code | `../../.claude/hooks/*` | hook events (exit 2 = denied) |
| Routing table | `../registry/routing.json` | `scripts/router.py` |
| Output contracts | `../registry/contracts/*.json` | `.claude/hooks/contract.py` |
| Invariants | `invariants.md` | `bin/aios doctor` + review |

## The kernel loop
```
prompt → UserPromptSubmit(route) → PreToolUse(guard) → tool → PostToolUse(truncate) →
PostToolUseBatch(budget) → … → Stop(gate) → SessionEnd(learn)
```
Every arrow is a place where tokens or authority can be taken away. That is the point.
