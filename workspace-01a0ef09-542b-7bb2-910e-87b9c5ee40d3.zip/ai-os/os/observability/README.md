# Observability

What you cannot measure you cannot make cheaper, safer, or faster.

| Signal | Source | Cadence |
|---|---|---|
| tokens in/out/cache, cost | `state/ledger.jsonl` | every event |
| gate verdicts + duration | `state/traces/<task>/<gate>.log` | every gate |
| contract breaches | `state/.contract_blocks` | every SubagentStop |
| approvals + SLA | `state/approvals/pending.json` | on escalation |
| cost Pareto | `scripts/cost_report.py` | nightly routine |
| human digest | `scripts/digest.py` | daily (artifact) |

## Weekly review (OPERATIONS.md §9)
first-pass gate rate · interventions per task · cost per tier-M task · cache hit rate ·
compactions per task · escalation resolution time · skill-rot count.
