# Bus

Inter-process communication for agents that must not share a context window.

| Channel | File | Use |
|---|---|---|
| Event log | `state/ledger.jsonl` | append-only: events, tokens, cost, gate verdicts |
| Task records | `state/tasks/<id>.json` | the unit of work; status machine |
| Mailbox | `state/bus/<agent>.jsonl` | agent-to-agent messages (one JSON object per line) |
| Approvals | `state/approvals/pending.json` | the human queue |
| Digest | `state/digest/<date>.md` | daily human summary |

## Rules
- Append-only. Never rewrite history; correct by appending.
- Messages are ≤ 200 tokens and carry a pointer, never a payload.
- Cross-session messaging (`/tasks`, cross-session messaging) is for sessions a human runs;
  agents inside one run report to their parent instead.
- Anything that needs a human lands in `state/approvals/pending.json` — the session keeps working.
