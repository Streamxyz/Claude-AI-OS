# Sandbox

Two sandboxes, one goal: nothing dangerous and nothing bulky reaches the model.

## 1. Bash sandbox (`settings.json → sandbox`)
OS-level isolation for shell commands: filesystem allow-lists, network domain allow-list,
`autoAllowBashIfSandboxed` so sandboxed commands stop prompting. `git` and `docker` run outside.

## 2. Code-execution sandbox (`scripts/mcp_exec/`)
Implements Anthropic's *code execution with MCP*: MCP tools are presented as code on a
filesystem behind two generic tools.

```
tools.py search "<query>"    → trimmed signatures          (~200 tokens)
exec.py  script.py           → runs code; only `result` prints
```
Intermediate results stay in the process. Anthropic's reference demo collapsed ~150k tokens
to ~2k; community reproductions report 95%+ on bulk operations.

**Rule:** any MCP interaction touching > 20 objects or > 5 KB of payload goes through `exec.py`.
