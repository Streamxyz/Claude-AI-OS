# Operations Manual

How AI OS runs unattended, when it stops to ask, and what you do at 9am.

---

## 1. Autonomy ladder

Autonomy is granted **per tier**, and control is never relaxed. The two are independent axes.

| Level | Name | Behaviour | Default for |
|---|---|---|---|
| **A0** | Supervised | every tool call confirmed | new repos, first week |
| **A1** | Edit-approved | edits auto, shell confirmed | unfamiliar codebases |
| **A2** | Gate-gated | unattended until a gate blocks | tier S / M |
| **A3** | Autonomous | unattended; escalation queue instead of blocking | tier L (**default**) |
| **A4** | Scheduled | routines run unattended on triggers | nightly maintenance, XL audits |

Promotion rule: a tier moves up one level after **20 consecutive tasks** with zero human corrections and ≥ 95% first-pass gate rate. Demotion is immediate on any safety incident.

Permission modes used: `default` (A0–A1), `acceptEdits` (A2–A3 inside worktrees), `bypassPermissions` **only** inside the CI sandbox container, never on a developer machine.

---

## 2. Escalation triggers

The session does **not** stall waiting for you. It parks the blocker in `state/approvals/pending.json`, notifies, and continues with other tasks.

| Trigger | Automatic action |
|---|---|
| 3rd consecutive gate failure on one task | park task, attach evidence, spawn `resolver` once, then escalate |
| Per-task token ceiling exceeded (tier default × 1.5) | pause task, escalate with spend breakdown |
| Protected path touched (`.env`, `migrations/`, `infra/`, `.github/`) | hard deny via hook + escalate |
| Destructive shell (`rm -rf`, `git push --force`, `DROP`, `TRUNCATE`, `kubectl delete`) | hard deny via hook (exit 2) |
| Ambiguity: ≥ 2 materially different valid designs | record both in the spec, escalate |
| Schema migration, payment/auth/PII change | escalate regardless of green gates |
| Secret or credential detected in a write | block write, rotate-flag, escalate |
| Budget: daily spend > ceiling | stop dispatch, escalate, keep reporting |

`state/approvals/pending.json` shape:

```json
[{
  "id": "T-142",
  "reason": "gate_failure_3x",
  "question": "Gate e2e fails on checkout flow; fix is either revert-flaky-test or change-selector. Which?",
  "options": ["revert-flaky-test", "change-selector", "investigate-more"],
  "evidence": ["state/traces/T-142/gate-e2e.log"],
  "blocked_since": "2026-09-29T08:14:00Z",
  "recommended": "change-selector",
  "cost_so_far_usd": 1.87
}]
```

Escalations always carry **evidence paths, options, a recommendation, and the cost so far** — so answering takes seconds, not a debugging session.

---

## 3. The human's three surfaces

1. **`specs/intent/T-*.md`** — you write intent. Template: *Goal · Non-goals · Acceptance criteria · Constraints · Done means*. Nothing else.
2. **`state/approvals/pending.json`** — the queue. Drain it, don't read transcripts.
3. **Daily digest** (artifact, 8am routine) — shipped / blocked / spend / proposals. Two minutes.

Everything else is machine-internal. If you find yourself reading a transcript, the OS is missing a script — file it as a task.

---

## 4. Nightly routine (unattended, cloud)

| Time | Routine | Does |
|---|---|---|
| 02:00 | `aios-audit` | dynamic workflow: security, dead code, deps, docs drift → draft PRs |
| 03:00 | `deps-upgrade` | patch bumps, gates green → PR; major bumps → escalate |
| 04:00 | `docs-sync` | open PRs for docs that reference changed APIs |
| 05:00 | `cost-optimizer` | Pareto report: cost vs pass rate per model/effort config |
| 06:00 | `aios-learn` | promote repeated corrections → `.claude/rules/` PR |
| 08:00 | `digest.py` | human digest artifact |

Routines run on Anthropic cloud infrastructure (schedule / API / GitHub triggers) so they run with the laptop closed. Scope each routine to the minimum repositories, environment, and connectors.

---

## 5. Incident path

```
Alert → routine API trigger → aios-incident
  ├─ explorer: correlate stack trace with recent commits (own context)
  ├─ implementer: draft fix in a worktree
  ├─ verifier: try to refute the fix
  └─ output: draft PR + root-cause note + escalation if confidence < 0.7
```

Human reviews a PR, not a fire. Threshold: any incident touching payments, auth, or data integrity escalates immediately at `explorer` stage.

---

## 6. Quality gates (the Definition of Done)

A task is done when **all** of these are true on disk:

- [ ] `state/tasks/<id>.json` → `status: MERGED`
- [ ] every gate in the task's `gates[]` is green with evidence in `state/traces/<id>/`
- [ ] verifier agent returned `pass: true` with ≥ 1 genuine refutation attempt
- [ ] `scripts/contract.py` accepted every agent return
- [ ] ledger row written with tokens + cost
- [ ] no protected path touched without approval
- [ ] for user-visible changes: `/verify` ran against the *running app*, not just tests

The `Stop` hook enforces this. It can block the turn from ending until the gate set passes, with a cap on consecutive blocks so a stuck task escalates instead of looping forever.

---

## 7. Runbook: common failures

| Symptom | First check | Fix |
|---|---|---|
| Context warnings, sloppy output | `/context` | `/aios-context` (checkpoint → compact → re-prime) |
| Agent returns rejected | `state/traces/<id>/contract-*.json` | contract too small for the job → widen schema in `os/registry/contracts/` |
| Gate flaps | `state/ledger.jsonl \| grep gate` | flaky test → quarantine + task; do not retry blindly |
| Costs spiking | `bin/aios cost --since 1d --by model` | routing table: is Opus doing Haiku's job? |
| Skill not activating | `/skills`, description wording | rewrite description as `Use when …`; consider a CLAUDE.md trigger line |
| Hooks not firing | `claude --debug` | frontmatter/JSON validity; `hooks/hooks.json` merge rules |
| Worktree collisions | file-ownership map in the plan | split ownership; never let two agents own one file |
| Parallel sessions clobbering | `git worktree list` | every session and worker gets its own worktree |

---

## 8. Security posture

- `permissions.deny` for: `Bash(rm -rf*)`, `Bash(git push --force*)`, `Bash(curl*|sh)`, `Bash(chmod 777*)`, `Read(.env*)`, `Read(**/secrets/**)`, `Write(.env*)`, `Bash(kubectl delete*)`, `Bash(DROP*)`, `Bash(TRUNCATE*)`.
- `PreToolUse` hooks are the enforcement layer; CLAUDE.md is only advice. Hooks fire inside subagents too, so delegation cannot bypass policy.
- MCP servers are pinned, reviewed, and treated as untrusted input (prompt-injection surface).
- Secrets exist only in env; `.worktreeinclude` copies local env into worktrees without committing them.
- Plugins are supply-chain dependencies: pinned, reviewed, version-locked.

---

## 9. Health metrics (review weekly)

| Metric | Target | Source |
|---|---|---|
| First-pass gate rate | ≥ 90% | ledger |
| Human interventions per task | ≤ 0.2 | approvals log |
| Cost per tier-M task | trending down | `cost_report.py` |
| Cache hit rate | ≥ 70% | ledger |
| Compactions per task | ≤ 1 | ledger |
| Escalations resolved < 10 min | ≥ 80% | approvals timestamps |
| Skill-rot (skills patched > 2×/month) | 0 | `promote.py` |
