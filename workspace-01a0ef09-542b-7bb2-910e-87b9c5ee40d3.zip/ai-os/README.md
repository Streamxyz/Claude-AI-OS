# AI OS

**A Claude Code–based operating system for autonomous full-stack engineering.**
Human writes intent. Claude plans, implements, verifies, and learns. Hooks hold the line.

```
specs/intent/T-142.md  ──►  bin/aios run T-142  ──►  shipped, gate-green, ledgered
```

---

## 60-second quickstart

```bash
# 1. Install the OS into any repo (or start here)
git clone <this-repo> ai-os && cd ai-os

# 2. Boot: validate layout, toolchain, hooks, permissions
./bin/aios boot

# 3. Health check (hooks wired? skills valid? indexes fresh?)
./bin/aios doctor

# 4. Write the ONLY file a human writes — an intent, not instructions
$EDITOR specs/intent/T-142.md

# 5. Run it. Walk away.
./bin/aios run T-142          # tier S/M: single session
./bin/aios run T-142 --team   # tier L:   agent team + worktrees
./bin/aios run T-142 --swarm  # tier XL:  dynamic workflow

# 5b. Or install it as a plugin into any repo instead of cloning
python3 scripts/build-plugin.py      # → plugin/ai-os
claude plugin marketplace add ./plugin
claude plugin install ai-os@ai-os
aios adopt                           # scaffolds state/, specs/, products/, permissions
# 6. Come back to evidence, not vibes
./bin/aios verify T-142       # gate verdicts
./bin/aios cost --since 1d    # spend per task / model / agent
cat state/approvals/pending.json   # the only things needing you
```

---

## What you actually get

| Capability | Mechanism |
|---|---|
| Full-stack delivery (FE, BE, DB, infra, CI/CD) | typed agents + engineering skills + worktree isolation |
| Autonomous long runs | dynamic workflows, routines, `/goal`, Stop-hook gates |
| Parallel work without collisions | `isolation: worktree` + file-ownership maps |
| Hard control | `PreToolUse` hooks + `permissions.deny` (model cannot talk its way past) |
| 10–100× context savings | deferred MCP schemas, code-execution-with-MCP, output truncation, JSON contracts |
| Zero-amnesia sessions | `state/` as source of truth + compaction protocol + primer re-injection |
| Verifiable output | gates + adversarial verifier agents + evidence on disk |
| Compounding quality | nightly cost/eval report → automatic rule & skill promotion |

---

## The mental model

| You say | OS does |
|---|---|
| "Add rate limiting to the API" | classify → plan → own files → implement in worktree → gates → verifier → merge → ledger → learn |
| "Is it done?" | reads `state/tasks/T-142.json`, not the chat |
| "Why did it cost $4?" | `bin/aios cost T-142` → per-agent, per-model, cache-hit breakdown |
| "Don't ever touch migrations" | `hooks/guard-paths.sh` — enforced, not requested |

---

## Directory map (one line each)

| Path | Load policy | Role |
|---|---|---|
| `CLAUDE.md` | always | constitution, ≤150 lines |
| `.claude/settings.json` | enforced | permissions, model, hooks |
| `.claude/rules/` | on path match | scoped conventions |
| `.claude/skills/` | metadata always, body on match | capability packages |
| `.claude/agents/` | description always, prompt on spawn | typed workers |
| `.claude/hooks/` | event-driven | policy-as-code |
| `bin/`, `scripts/` | on call | deterministic syscalls |
| `state/` | on demand | tasks, notes, ledger, approvals, indexes |
| `specs/intent/` | human-written | the input |
| `products/` | on demand | delivered applications |
| `docs/` | **never auto-loaded** | long-form references |
| `plugin/` | **generated** | installable marketplace build (`plugin/ai-os`) |

---

## Autonomy in one table

| Tier | Scope | Human involvement | Gates |
|---|---|---|---|
| **S** | one file, known fix | none | typecheck + unit |
| **M** | 1–5 files | none | + lint, build |
| **L** | feature slice | plan approval | + e2e, review |
| **XL** | repo-wide | plan approval + budget cap | + workflow cross-check, security |

Escalation (3 gate failures · budget overrun · protected path · ambiguity) → `state/approvals/pending.json`. The session keeps working on other tasks instead of stalling.

---

## Verify the install

```bash
bin/aios doctor --all     # 9 checks: layout, hooks, syntax, skills, agents, contracts, ledger, indexes
python3 evals/run.py      # behaviour evals: routing 8/8, destructive-command guards 12/12
```

`doctor` exits non-zero on any FAIL — wire it into CI. `evals/run.py` is the regression suite for
agent behaviour: routing, hook guards, contracts, gates.

## Read next

- [`ARCHITECTURE.md`](ARCHITECTURE.md) — layers, pipeline, skills, agents, hooks, invariants
- [`diagrams/architecture.svg`](diagrams/architecture.svg) — the whole system on one page
- [`TOKEN-ECONOMY.md`](TOKEN-ECONOMY.md) — the budget model and every saving mechanic
- [`OPERATIONS.md`](OPERATIONS.md) — autonomy ladder, escalation, on-call, nightly routines
- [`ROADMAP.md`](ROADMAP.md) — maturity ladder and what to build first
- [`docs/plugin.md`](docs/plugin.md) — packaging AI OS as an installable plugin

## Requirements

Claude Code ≥ `2.1.281` (dynamic workflows need ≥ `2.1.154`; `omitClaudeMd` ≥ `2.1.271`).
Python 3.11+, Node 20+, git 2.40+, `jq`. Optional: `uv`, Docker (sandbox), Playwright (e2e).

> Enable dynamic workflows: `/config` → *Dynamic workflows* (Pro) or on by default for paid/API/Bedrock/Vertex/Foundry plans.
> Enable agent teams (experimental): `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` in `settings.json → env`.
