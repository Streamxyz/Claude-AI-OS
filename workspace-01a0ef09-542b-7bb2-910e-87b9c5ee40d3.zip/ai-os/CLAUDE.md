# CLAUDE.md — AI OS constitution

You are operating **AI OS**: a repository-shaped control plane for autonomous full-stack engineering.
Read this file every session. It is deliberately short — **everything procedural lives in a skill, a rule, or a script.**

## Prime directives

1. **State on disk beats state in chat.** If it isn't in `state/`, it doesn't exist.
2. **Evidence beats assertion.** Never report success without a command, its exit code, and output on disk.
3. **Deterministic beats generative.** If a script can do it, call the script. Do not re-derive.
4. **Smallest high-signal context.** Read the index before the tree; read the skill before the docs.
5. **Hooks are law, CLAUDE.md is advice.** Both are non-negotiable, but only hooks are enforced.

## Non-negotiable rules

- Never read, print, or `cat` more than 200 lines of any file or command output. Use `scripts/*` or offsets.
- Never paste a command's full output into a response. Summarize; point at `state/traces/`.
- Never touch protected paths: `.env*`, `**/secrets/**`, `migrations/`, `infra/`, `.github/workflows/` without an approval item.
- Never commit to `main`, force-push, or run destructive commands (hooks deny these; do not try to route around them).
- Never return unstructured prose from a subagent. Every return is a validated JSON contract.
- Never re-solve a solved problem. Query `state/ledger.jsonl` and `state/notes/` **first**.

## Commands (syscalls — prefer these over ad-hoc shell)

```bash
bin/aios boot                 # validate OS, build indexes, print digest
bin/aios doctor               # hooks, skills, permissions, budgets health
bin/aios spec T-142           # intent -> spec
bin/aios plan T-142           # spec -> plan + file-ownership map
bin/aios run T-142 [--team|--swarm]
bin/aios verify T-142         # run the DoD gate set
bin/aios cost --since 1d      # spend by task / agent / model
bin/aios learn                # promote repeated corrections into rules
bin/aios context              # checkpoint -> compact -> re-prime
bin/aios wt new T-142         # task worktree
```

## Routing (automatic on every prompt — see `scripts/router.py`)

| Tier | Signal | Model / effort | Execution |
|---|---|---|---|
| S | 1 file, known fix | sonnet / medium | single implementer |
| M | 2–5 files, clear scope | opus plan → sonnet build | planner + implementer |
| L | feature slice, cross-cut | opus plan → sonnet team | agent team, worktrees |
| XL | repo-wide, research, migration | script plan | dynamic workflow |

## Where things live

| Need | Read |
|---|---|
| Repo map | `state/index/repo.md` (not the file tree) |
| Skills & tools | `state/index/skills.md`, `state/index/tools.md` |
| Current work | `state/tasks/<id>.json` |
| Prior decisions | `state/notes/<topic>.md` |
| History & spend | `state/ledger.jsonl` |
| Things needing a human | `state/approvals/pending.json` |
| Re-entry after compaction | `state/primer.md` |
| Deep references | `docs/` (never auto-loaded) |

## Session protocol

1. `bin/aios boot` (SessionStart hook does it) → read the digest.
2. Classify the intent to a tier. **Record it** in `state/tasks/<id>.json` before writing code.
3. Plan before implementing for tiers M+. Produce a **file-ownership map**; no two agents own one file.
4. Implement in a worktree. Run gates after every meaningful change.
5. Verify: `bin/aios verify <id>`, then a verifier agent tries to refute the result.
6. Ledger everything (`scripts/ledger.py append`).
7. At `PostToolBatch` warnings: run `bin/aios context` — do not push through a full window.

## Done means

Gates green with evidence · verifier passed · contract-valid returns · ledger row written · no protected path touched · `/verify` run against the running app for user-visible changes.

The `Stop` hook enforces this. See [`OPERATIONS.md`](OPERATIONS.md) §6.

## Anti-patterns (banned)

Giant `CLAUDE.md` · walking the file tree to "understand" · narrative agent returns · raw logs in context ·
`alwaysLoad` on big MCP servers · Opus for classification · Haiku for architecture ·
editing this file mid-run (cache invalidation + behaviour drift).
